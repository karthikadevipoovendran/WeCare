package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MADocReviewPageLocators {

	@FindBy(xpath="//h5")
	public List<WebElement> docHeader;	
	public By byDocAnim = By.xpath("//mat-tab-body/div[@style='transform: none;']");
	
	@FindBy(xpath="//textarea")
	public WebElement docRevTxtArea;
	
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	
}
