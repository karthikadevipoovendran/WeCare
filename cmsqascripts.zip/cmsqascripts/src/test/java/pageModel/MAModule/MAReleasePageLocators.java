package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAReleasePageLocators {

	
	@FindBy(xpath="//h5")
	public WebElement releaseHeader;
	public By byReleaseAnim = By.xpath("//mat-tab-body/div[@style='transform: none;']");
	
	@FindBy(xpath="//div[@class='mat-tab-label mat-ripple ng-star-inserted']")
	public List<WebElement> tabs_ClientInfo;
	
	@FindBy(xpath="//h5[contains(text(),'Releases')]")
	public WebElement text_Releases;
	
	@FindBy(xpath="//h5[contains(text(),'Current Reasonable Accommodations')]")
	public WebElement text_RA;
	
	@FindBy(xpath="//span[contains(text(),'Yes')]")
	public List<WebElement> text_Yes;
	public By bytext_Yes = By.xpath("//span[contains(text(),'Yes')]");

	
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary ng-star-inserted']//span[contains(text(),'Handwritten')]")
	public WebElement button_Handwritten;
		
	@FindBy(xpath="//div[@ng-reflect-name='CONSENTS']//input")
	public List<WebElement> hIPAAConsent;
	@FindBy(xpath="//div[@ng-reflect-name='CONSENTS']//div[@class='mat-radio-label-content']")
	public List<WebElement> hIPAAConsentTxt;
	
	@FindBy(xpath="//div[@class='buttons-row']/button[contains(@class,'mat-raised-button')]")
	public List<WebElement> signOptionBtn;
	@FindBy(xpath="//div[@class='ng-star-inserted']/button[contains(@class,'mat-raised-button')]")
	public WebElement verifyBtn;
	@FindBy(xpath="//input[@formcontrolname='SIGNATURE']")
	public WebElement signTxtField;
	@FindBy(xpath="//div[@class='ng-star-inserted']//button[contains(@class,'mat-raised-button')]")
	public WebElement signBtn;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='PROCEED']//input")
	public List<WebElement> signConsentBtn;
	@FindBy(xpath="//app-signature-required//button[contains(@class,'mat-raised-button')]")
	public List<WebElement> signSubmitBtn;
	
	@FindBy(xpath="//div[@class='modal-content']//button")
	public WebElement fTCModalBtn;
	
	@FindBy(xpath="//input[@formcontrolname='CONTACT_NAME']")
	public WebElement treatmentProvider;
	@FindBy(xpath="//input[@formcontrolname='ADDRESS']")
	public WebElement addr;
	@FindBy(xpath="//input[@formcontrolname='CITY']")
	public WebElement city;
	@FindBy(xpath="//input[@formcontrolname='ZIP_CODE']")
	public WebElement zip;
	@FindBy(xpath="//input[@formcontrolname='CONTACT_NUMBER']")
	public WebElement contactNum;
	@FindBy(xpath="//input[@formcontrolname='FAX_NUMBER']")
	public WebElement faxNum;
	
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_MEDICAL_DOC_HELP']/mat-radio-button//input")
	public List<WebElement> medDocProviderRadioBtn;
	@FindBy(xpath="//button[starts-with(@class,'actionBtn')]")
	public WebElement provideInfoAddBtn;
//	@FindBy(xpath="//input[@type='text' and starts-with(@class,'form-control')]")
//	public List<WebElement> provideDetailsInput;
	@FindBy(xpath="//select")
	public List<WebElement> provDetDrpDwn;
	@FindBy(xpath="//textarea")
	public WebElement docComments;
	@FindBy(xpath="//div[@class='nav-footer']/button[contains(@class,'mat-raised')]")
	public List<WebElement> newTreatProviderBtn;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	@FindBy(xpath="//div[@class=\"nav-footer\"]//button[@class='mat-raised-button mat-primary ng-star-inserted']")
	public WebElement button_TP_Save;
	
	
}
