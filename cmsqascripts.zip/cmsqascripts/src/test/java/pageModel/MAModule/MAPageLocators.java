package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAPageLocators {
	
	@FindBy(xpath="//h5")
	public WebElement myAssignmentHeader;
	@FindBy(xpath="//div[@col-id='ACTIVITY_LOOKUP']")
	public List<WebElement> appType;
	@FindBy(xpath="//div[@col-id='ACTIVITY_STATUS']")
	public List<WebElement> activityStatusTxt;
	public By byActivityStatusTxt = By.xpath("//div[@col-id='ACTIVITY_STATUS']");
	
	@FindBy(xpath="//button[@type='button' and @placement='right']")
	public List<WebElement> actionBtn;
	@FindBy(xpath="//div[@class='raCode']")
	public List<WebElement> shorterWaitCode;
	@FindBy(xpath="//mat-list-item")
	
	public List<WebElement> actionOptBtn;
	@FindBy(xpath="//mat-list-item/div")
	public List<WebElement> actionOptBtnTxt;
	@FindBy(xpath="//button[starts-with(@class,'mat-raised-button')]")
	public List<WebElement> assessmentConfBtn;
	


}
