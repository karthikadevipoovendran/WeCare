package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MACommonClinicalAssessPageLocators {
	
	@FindBy(xpath="//h5[@class='alert-heading']")
	public WebElement header;
	public By byHeader = By.xpath("//h5[@class='alert-heading']");
	
	@FindBy(xpath="//div[@class='w-100']")
	public List<WebElement> cAssessmentHeader;
	@FindBy(xpath="//div[starts-with(@class,'panel-heading')]")
	public List<WebElement> sideMenuBar;
	@FindBy(xpath="//mat-nav-list/a")
	public List<WebElement> sideMenuSubBar;
	@FindBy(xpath="//div[@class='mat-tab-labels']/div")
	public List<WebElement> cAssessmentTab;
	@FindBy(xpath="//button[contains(@class,'mat-raised-button')]")
	public List<WebElement> confBtn;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	@FindBy(xpath="//mat-icon[contains(@class,'chevron_left mat-icon')]")
	public WebElement arrow_left;
	@FindBy(xpath="//mat-icon[contains(@class,'chevron_right mat-icon')]")
	public WebElement arrow_right;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> buttons_PrevAndNext;
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']")
	public WebElement button_Submit;
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary ng-star-inserted']")
	public WebElement button_Save;
	@FindBy(xpath="//button[@class='mat-raised-button']")
	public WebElement button_Exit;
	
}
