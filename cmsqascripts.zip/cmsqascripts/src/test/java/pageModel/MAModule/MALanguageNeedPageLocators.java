package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MALanguageNeedPageLocators {

	@FindBy(xpath="//h5")
	public List<WebElement> langHeader;
	
	public By byLangAnim = By.xpath("//mat-tab-body/div[@style='transform: none;']");
			
	@FindBy(xpath="//app-form-action-buttons/button")
	public WebElement langAddBtn;
//	@FindBy(xpath="//button[starts-with(@class,'actionBtn')]")
//	public WebElement langAddBtn;
	@FindBy(xpath="//select")
	public List<WebElement> langDrpDwn;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_LANG_SPOKEN']/mat-radio-button//input")
	public List<WebElement> langSpokenBtn;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_LANG_SPOKEN']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> langSpokenBtnTxt;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_LANG_READ']/mat-radio-button//input")
	public List<WebElement> langReadBtn;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_LANG_READ']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> langReadBtnTxt;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_LANG_WRITTEN']/mat-radio-button//input")
	public List<WebElement> langWriteBtn;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_LANG_WRITTEN']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> langWriteBtnTxt;
	@FindBy(xpath="//mat-card//button")
	public List<WebElement> langInfoConfBtn;
	@FindBy(xpath="//mat-radio-button//input")
	public List<WebElement> transRadioBtn;
	@FindBy(xpath="//form//input[@type='text']")
	public List<WebElement> otherTxtInp;
	@FindBy(xpath="//div[@class='col-6']//textarea")
	public WebElement comments;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	@FindBy(xpath="//label[contains(text(),'English')]")
	public WebElement text_English;
	public By bytext_English = By.xpath("//label[contains(text(),'English')]");

}
