package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAPurposeOfVisitPageLocators {
	
	
	@FindBy(xpath="//h5")
	public WebElement povHeader;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	@FindBy(xpath="//textarea[@formcontrolname='PURPOSE_OF_VISIT']")
	public WebElement povReason;
	
}
