package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAReasonAccommoPageLocators {

	@FindBy(xpath="//h5[@class='alert-heading']")
	public WebElement header;
	public By byHeader = By.xpath("//h5[@class='alert-heading']");
	
	public By byReasonAnim = By.xpath("//mat-tab-body/div[@style='transform: none;']");
	
	@FindBy(xpath="//div[contains(@class, 'ng-trigger-translateTab')]")
	public List<WebElement> tabAnim;
	
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
}
