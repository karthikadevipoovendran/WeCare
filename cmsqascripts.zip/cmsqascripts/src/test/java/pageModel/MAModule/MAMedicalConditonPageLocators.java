package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAMedicalConditonPageLocators {
	
	
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	
	@FindBy(xpath="//input[@type = 'checkbox']")
	public List<WebElement> chkBox;
	@FindBy(xpath="//button[starts-with(@class,'actionBtn')]")
	public List<WebElement> addBtn;
	@FindBy(xpath="//input[@formcontrolname= 'DIAGNOSIS']")
	public WebElement condition;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_IMPACTS_ABILITY_TO_WORK']//input")
	public List<WebElement> impactsAbility;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_IMPACTS_ABILITY_TO_WORK']//div[@class='mat-radio-label-content']")
	public List<WebElement> impactsAbilityLabel;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_ABOVE_DURATION']//input")
	public List<WebElement> duration;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_ABOVE_DURATION']//div[@class='mat-radio-label-content']")
	public List<WebElement> durationLabel;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_STABLE']//input")
	public List<WebElement> stable;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_STABLE']//div[@class='mat-radio-label-content']")
	public List<WebElement> stableLabel;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_TREATED']//input")
	public List<WebElement> treated;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_TREATED']//div[@class='mat-radio-label-content']")
	public List<WebElement> treatedLabel;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_CURRENT']//input")
	public List<WebElement> current;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_CURRENT']//div[@class='mat-radio-label-content']")
	public List<WebElement> currentLabel;
	
	@FindBy(xpath="//div[@class = 'nav-footer']//button")
	public List<WebElement> medicCondiSaveBtn;

	@FindBy(xpath="//textarea[@formcontrolname = 'DIAGNOSIS_COMMENTS']")
	public WebElement impactAbilToWorkExp;

	@FindBy(xpath="//input[@formcontrolname = 'TREATING_CLINICIAN']")
	public WebElement treatingClinic;
	@FindBy(xpath="//input[@formcontrolname = 'ADDRESS']")
	public WebElement addr;
	@FindBy(xpath="//input[@formcontrolname = 'CITY']")
	public WebElement city;
	@FindBy(xpath="//input[@formcontrolname = 'ZIP_CODE']")
	public WebElement zip;
	@FindBy(xpath="//input[@formcontrolname='TREATING_DURATION']")
	public WebElement lengthOfTreat;
	
	@FindBy(xpath="//select[@formcontrolname = 'SELECTEDVALUE']")
	public List<WebElement> mhSelect;
	
	@FindBy(xpath="//input[@formcontrolname = 'SPECIALITY_OTHER']")
	public WebElement specOther;

	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'COMPLIANCE']//input")
	public List<WebElement> compliance;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'COMPLIANCE']//div[@class='mat-radio-label-content']")
	public List<WebElement> complianceLabel;
	@FindBy(xpath="//input[@formcontrolname = 'NONCOMPLIANCE_REASON']")
	public WebElement nonCompliReason;

	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_ANY_MEDICATIONS']//input")
	public List<WebElement> medication;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_ANY_MEDICATIONS']//div[@class='mat-radio-label-content']")
	public List<WebElement> medicationLabel;
	@FindBy(xpath="//input[contains(@class,'mat-chip-input')]")
	public WebElement medicEntry;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_COMPLIANT']//input")
	public List<WebElement> compInTakMedic;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_COMPLIANT']//div[@class='mat-radio-label-content']")
	public List<WebElement> compInMedicLabel;
	@FindBy(xpath="//textarea[@formcontrolname = 'COMPLIANCE_COMMENTS']")
	public WebElement compInMedicReason;

	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_ANY_HOSPITILIZATION']//input")
	public List<WebElement> historyOfHospital;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_ANY_HOSPITILIZATION']//div[@class='mat-radio-label-content']")
	public List<WebElement> historyOfHospitalLabel;
	@FindBy(xpath="//textarea[@formcontrolname = 'HOSP_COMMENTS']")
	public WebElement historyHospiComment;
	
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_HIV_TREATMENT']//input")
	public List<WebElement> hivMedicTreat;
	@FindBy(xpath="//mat-radio-group[@formcontrolname = 'IS_HIV_TREATMENT']//div[@class='mat-radio-label-content']")
	public List<WebElement> hivMedicTreatLabel;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_AIDS']//input")
	public List<WebElement> aids;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_AIDS']//div[@class='mat-radio-label-content']")
	public List<WebElement> aidsLabel;
	@FindBy(xpath="//textarea[@formcontrolname='HIV_EXPLAIN']")
	public WebElement hivReason;
	@FindBy(xpath="//mat-datepicker-toggle/button[@class='mat-icon-button']")
	public WebElement datePicker;
	@FindBy(xpath="//td[contains(@class,'mat-calendar-body-active')]")
	public WebElement activeDate;

}
