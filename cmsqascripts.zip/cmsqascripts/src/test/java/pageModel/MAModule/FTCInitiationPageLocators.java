package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FTCInitiationPageLocators {
	
	@FindBy(xpath="//input[@type='checkbox']")
	public WebElement fTCChkBox;
	@FindBy(xpath="//textarea[@formcontrolname='COMMENTS']")
	public WebElement comments;
	@FindBy(xpath="//mat-card-content//button[contains(@class,'mat-raised-button')]")
	public List<WebElement> ftcBtn;
	@FindBy(xpath="//div[@col-id='COMMENTS']")
	public List<WebElement> ftcRow;
	@FindBy(xpath="//button[contains(@class,'mat-raised-button')]")
	public List<WebElement> initFTCBtn;
	@FindBy(xpath="//div[@class='modal-content']//button")
	public List<WebElement> fTCConfBtn;
}
