package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAMedicalLimitationsPageLocators {
	
	@FindBy(xpath="//mat-ink-bar[@class='mat-ink-bar']")
	public WebElement linkbar_Blue;
	
	@FindBy(xpath="//label[contains(text(),'Exertional Limitations')]")
	public WebElement label_ExertionalLimitations;
	
	@FindBy(xpath="//label[@class='col-6']")
	public WebElement label_allOptions;
	
	@FindBy(xpath="//div[@class='mat-radio-label-content']")
	public List<WebElement> text_radiobutton_allOptions;
	
	@FindBy(xpath="//div[@class='mat-radio-outer-circle']")
	public List<WebElement> radiobutton_allOptions; 
	
	@FindBy(xpath="//label[contains(text(),'Non-exertional Limitations')]")
	public WebElement label_NonExertionalLimitations;
	
	@FindBy(xpath="//textarea[@formcontrolname='EXERTIONAL_EXPLAIN']")
	public WebElement textbox_ExertionalExplain;
	public By bytextbox_ExertionalExplain = By.xpath("//textarea[@formcontrolname='EXERTIONAL_EXPLAIN']");
	
	@FindBy(xpath="//textarea[@formcontrolname='NONEXERTIONAL_EXPLAIN']")
	public WebElement textbox_NonExertionalExplain;
	public By bytextbox_NonExertionalExplain = By.xpath("//textarea[@formcontrolname='NONEXERTIONAL_EXPLAIN']");
	
	
}