package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAPsychiatricLimitationsPageLocators {
	
	@FindBy(xpath="//mat-ink-bar[@class='mat-ink-bar']")
	public WebElement linkbar_Blue;
	
	@FindBy(xpath="//h5[contains(text(),'Non-exertional Psychiatric Limitations')]")
	public WebElement label_NonexertionalPsychiatricLimitations;
	
	@FindBy(xpath="//label[@class='col-8 card-sub-title']")
	public List<WebElement> label_subheaders;
	
	@FindBy(xpath="//label[@class='col-6']")
	public List<WebElement> label_allOptions;
	
	@FindBy(xpath="//div[@class='mat-radio-outer-circle']")
	public List<WebElement> radionbuttons_allOptions;
	
	@FindBy(xpath="//div[@class='mat-radio-label-content']")
	public List<WebElement> text_allOptions_radiobuttons;
	
	@FindBy(xpath="//textarea[@formcontrolname='NON_EXERTIONAL_NOTES']")
	public WebElement textarea_NON_EXERTIONAL_NOTES;
	public By byNON_EXERTIONAL_NOTES = By.xpath("//textarea[@formcontrolname='NON_EXERTIONAL_NOTES']");
	
}