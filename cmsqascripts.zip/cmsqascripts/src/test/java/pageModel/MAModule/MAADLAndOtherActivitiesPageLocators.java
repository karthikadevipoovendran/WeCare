package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAADLAndOtherActivitiesPageLocators {
	
	@FindBy(xpath="//mat-ink-bar[@class='mat-ink-bar']")
	public WebElement linkbar_Blue;
	
	@FindBy(xpath="//h5[contains(text(),'Activity of Daily Living')]")
	public WebElement header_Activity;
	
	@FindBy(xpath="//div[@class='mat-list-item-content mat-list-item-content-reverse']//div[@class='mat-list-text']")
	public List<WebElement> text_all_Checkbox;
	
	@FindBy(xpath="//mat-pseudo-checkbox[@class='mat-pseudo-checkbox']")
	public List<WebElement> all_Checkbox;
	
	@FindBy(xpath="//mat-pseudo-checkbox[@class='mat-pseudo-checkbox mat-pseudo-checkbox-disabled']")
	public List<WebElement> all_Checkbox_Disabled;
	
	@FindBy(xpath="//label[contains(text(),'Explain')]")
	public WebElement label_Explain;
	public By bylabel_Explain = By.xpath("//label[contains(text(),'Explain')]");
	
	@FindBy(xpath="//textarea[@formcontrolname='ADL_COMMENTS']")
	public WebElement textbox_Explain;
	public By bytextbox_Explain = By.xpath("//textarea[@formcontrolname='ADL_COMMENTS']");
	
	@FindBy(xpath="//label[contains(text(),'Other Activities')]")
	public WebElement label_OtherActivities;
	
	@FindBy(xpath="//textarea[@formcontrolname='WORK_ACT_COMMENTS']")
	public WebElement textbox_OtherActivities;
	public By bytextbox_OtherActivities = By.xpath("//textarea[@formcontrolname='WORK_ACT_COMMENTS']");
	
	@FindBy(xpath="//div[@class='mat-list-item-content mat-list-item-content-reverse']")
	public List<WebElement> rows_AllOptions;
	
	@FindBy(xpath="//div[@class='mat-list-item-content mat-list-item-content-reverse']//mat-pseudo-checkbox[@class='mat-pseudo-checkbox']")
	public List<WebElement> rows_AllCheckbox;
	
	@FindBy(xpath="mat-pseudo-checkbox[ng-reflect-state='checked']")
	public List<WebElement> checked_AllCheckboxes;
	public By bychecked_AllCheckboxes = By.xpath("mat-pseudo-checkbox[ng-reflect-state='checked']");
	
	@FindBy(xpath="mat-pseudo-checkbox[ng-reflect-state='unchecked']")
	public List<WebElement> unchecked_AllCheckboxes;
	
	@FindBy(xpath="//select[@formcontrolname='SELECTEDVALUE']")
	public WebElement dropdown_Travel;
	
	@FindBy(xpath="//input[@formcontrolname='TRAVEL_TYPE_OTHER']")
	public WebElement textbox_Other_Travel;
	public By bytextbox_Other_Travel = By.xpath("//input[@formcontrolname='TRAVEL_TYPE_OTHER']");
	
	@FindBy(xpath="//div[@class='col-4']//div[@class='mat-radio-outer-circle']")
	public WebElement radioButtons_Other_Travel;
	
}