package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
public class MAPageCommonLocators {
	
	
	@FindBy(xpath="//h5[contains(text(),'My Assignments')]")
	public WebElement myAssignments_headername;
	
	@FindBy(xpath="//div[contains(@col-id,'CLIENT_LN_FN')]")
	public List<WebElement> clientName_MyAssignments;
	
	@FindBy(xpath="//div[contains(@class,'ag-row-selected')]//mat-icon[@class='action-icon mat-icon notranslate material-icons mat-icon-no-color'][contains(text(),'more_vert')]")
	public WebElement actions;
	
	@FindBy(xpath="//div[contains(text(),'Open')]")
	public WebElement myAssignments_Open;
	
	@FindBy(xpath="//div[@class='modal-footer']/button[starts-with(@class,'mat-raised-button')]")
	public List<WebElement> myAssignments_Confirm;
	
	@FindBy(xpath="//div[contains(text(),'Client Assessment')]")
	public WebElement myAssignments_ClientAssessment;
	
	@FindBy(xpath="//div[contains(text(),'CASE OVERVIEW')]")
	public WebElement myAssignments_CaseOverview;
	
	@FindBy(xpath="//mat-icon[contains(@class,'action-icon mat-icon')]")
	public List<WebElement> list_actionicons;
	
	
}