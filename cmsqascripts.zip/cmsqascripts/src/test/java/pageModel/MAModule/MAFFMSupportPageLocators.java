package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAFFMSupportPageLocators {

	@FindBy(xpath="//h5")
	public WebElement fFMHeader;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='INSURANCE_ID']/mat-radio-button//input")
	public List<WebElement> healthInsuCov;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='INSURANCE_ID']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> healthInsuCovTxt;
	@FindBy(xpath="//input[@formcontrolname='INSURANCE_OTHER']")
	public WebElement otherInsuCov;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='INSURANCE_TYPE_ID']/mat-radio-button//input")
	public List<WebElement> medicaidType;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='INSURANCE_TYPE_ID']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> medicaidTypeTxt;
	@FindBy(xpath="//input[@formcontrolname='MNGCARE_PROGRAM_OTHER']")
	public WebElement otherManageCareProg;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_PENSION']/mat-radio-button//input")
	public List<WebElement> pension;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_PENSION']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> pensionTxt;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_COMPENSATION']/mat-radio-button//input")
	public List<WebElement> compensation;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_COMPENSATION']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> compensationTxt;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_HIVAIDS']/mat-radio-button//input")
	public List<WebElement> hivServicesAdmin;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_HIVAIDS']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> hivServicesAdminTxt;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_UNEMPBNFTS']/mat-radio-button//input")
	public List<WebElement> unEmployBenefits;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_UNEMPBNFTS']/mat-radio-button//div[@class='mat-radio-label-content']")
	public List<WebElement> unEmployBenefitsTxt;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_OTHER']/mat-radio-button//input")
	public List<WebElement> other;
	@FindBy(xpath="//input[@formcontrolname='OTHER_COMMENTS']")
	public WebElement otherComment;
	@FindBy(xpath="//mat-radio-group[@formcontrolname='IS_CASE_MGMNT_PROG_OTHER']/mat-radio-button//input")
	public List<WebElement> otherThanWeCare;
	@FindBy(xpath="//input[@formcontrolname='PROVIDER_NAME']")
	public WebElement provName;
	@FindBy(xpath="//input[@formcontrolname='CONTACT_PERSON']")
	public WebElement contPerson;
//	@FindBy(xpath="//form/div[@class='row'][11]/div/mat-radio-group/mat-radio-button")
//	public List<WebElement> suppWeCare;
	@FindBy(xpath="//select")
	public List<WebElement> supportDrpDwn;
	@FindBy(xpath="//form//input[@type='text']")
	public List<WebElement> expInput;
	@FindBy(xpath="//button[@type='button']")
	public WebElement ssiDateBtn;
	@FindBy(xpath="//td[contains(@class,'mat-calendar-body-active')]")
	public WebElement ssiDate;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	
}
