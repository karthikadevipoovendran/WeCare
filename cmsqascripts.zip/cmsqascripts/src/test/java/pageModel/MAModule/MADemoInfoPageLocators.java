package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MADemoInfoPageLocators {

	@FindBy(xpath="//h5")
	public WebElement demoHeader;
	@FindBy(xpath="//input[starts-with(@class,'form-control')]")
	public List<WebElement> demoInput;
	@FindBy(xpath="//input[@formcontrolname='ETHNICITY_OTHER']")
	public WebElement otherEthnicity;
	@FindBy(xpath="//input[@formcontrolname='ADDRESS']")
	public WebElement otherAddr;
	@FindBy(xpath="//input[@formcontrolname='CITY']")
	public WebElement otherCity;
	@FindBy(xpath="//input[@formcontrolname='ZIP_CODE']")
	public WebElement otherZip;
	@FindBy(xpath="//select")
	public List<WebElement> demoDrpDwn;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	
}
