package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAObservationAndClientPresentationPageLocators {
	
@FindBy(xpath="//div[contains(@class,'mat-tab-label mat-ripple ng-star-inserted')]")
public List<WebElement> tabs_AllTabs;

@FindBy(xpath="//div[contains(@class,'mat-tab-label mat-ripple ng-star-inserted')]//div[@class='mat-tab-label-content']")
public List<WebElement> label_AllTabs;

@FindBy(xpath="//mat-ink-bar[@class='mat-ink-bar']")
public WebElement linkbar_Blue;

@FindBy(xpath="//label[contains(text(),'Describe')]")
public WebElement label_Describe;

@FindBy(xpath="//textarea[@formcontrolname='PRESENTATIONAL_OBSERVATION']")
public WebElement textbox_Describe;
public By bytextbox_Describe = By.xpath("//textarea[@formcontrolname='PRESENTATIONAL_OBSERVATION']");
}