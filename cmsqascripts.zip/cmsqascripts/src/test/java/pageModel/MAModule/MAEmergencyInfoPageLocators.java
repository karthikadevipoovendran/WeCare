package pageModel.MAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MAEmergencyInfoPageLocators {

	

	@FindBy(xpath="//input[starts-with(@class,'form-control')]")
	public List<WebElement> emerInput;
//	@FindBy(xpath="//button[contains(@class,'actionBtn')]")
//	public WebElement addBtn;
	@FindBy(xpath="//app-form-action-buttons/button")
	public WebElement addBtn;
		
	@FindBy(xpath="//input[@formcontrolname='LAST_NAME']")
	public WebElement lName;
	@FindBy(xpath="//input[@formcontrolname='FIRST_NAME']")
	public WebElement fName;
	@FindBy(xpath="//input[@formcontrolname='ADDRESS']")
	public WebElement addr;
	@FindBy(xpath="//input[@formcontrolname='CITY']")
	public WebElement city;
	@FindBy(xpath="//form-control-validation[@ng-reflect-constol-name='PHONE']//input")
	public WebElement tele;
	@FindBy(xpath="//form-control-validation[@ng-reflect-constol-name='ZIP_CODE']//input")
	public WebElement zip;
	@FindBy(xpath="//form-control-validation[@ng-reflect-constol-name='CELL_PHONE']//input")
	public WebElement cell;
	@FindBy(xpath="//input[@formcontrolname='EMAIL']")
	public WebElement email;

	@FindBy(xpath="//select")
	public List<WebElement> emerDrpDwn;
	@FindBy(xpath="//mat-card//button")
	public List<WebElement>demoBtn;
	@FindBy(xpath="//div[@class='nav-footer']//button")
	public List<WebElement> emerInfoBtn;
	@FindBy(xpath="//button[@class='mat-button mat-primary']")
	public List<WebElement> navBtn;
	
	
}
