package pageModel;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LogInPageLocators {

	@FindBy(name="username")
	public WebElement userName;

	@FindBy(name="password")
	public WebElement passWord;

	@FindBy(xpath="//button[@type='submit']")
	public WebElement loginBtn;

	@FindBy(xpath="//button[contains(@type,'reset')]")
	public WebElement resetBtn;
	
}
