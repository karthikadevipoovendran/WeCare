package pageModel;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class VendorSiteLPageocators {
	
	
	@FindBy(xpath="//div[@class='optionList'][1]//button[contains(@class,'list-group-item')]")
	public List<WebElement> progBtn;
	@FindBy(xpath="//div[@class='optionList'][2]//button[contains(@class,'list-group-item')]")
	public List<WebElement> provBtn;
	@FindBy(xpath="//div[@class='optionList'][3]//button[contains(@class,'list-group-item')]")
	public List<WebElement> siteBtn;
	
	
	@FindBy(xpath="//button[starts-with(@class,'list-group-item')]")
	public List<WebElement> vendorSiteBtn;
	public By byVendorSiteBtn = By.xpath("//button[starts-with(@class,'list-group-item')]");
	
	
	

}
