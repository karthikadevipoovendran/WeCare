package pageModel;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LogOutPageLocators {

	
	@FindBy(xpath="//mat-icon[contains(text(),'more_vert')]")
	public List<WebElement> menuIcon;
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']")
	public List<WebElement> logOutBtn;
	@FindBy(xpath="//div[starts-with(@class,'toast-message')]")
	public WebElement logOutToastMsg;
	
}
