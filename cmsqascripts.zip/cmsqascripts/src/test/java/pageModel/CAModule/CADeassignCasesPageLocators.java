package pageModel.CAModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.List;

public class CADeassignCasesPageLocators {
	
	@FindBy(xpath="//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[@class='flex-child']")
	public List<WebElement> caseLoad_CMS_User;
	public By bycaseLoad_CMS_User = By.xpath("//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[@class='flex-child']");
	
	@FindBy(xpath="//div[contains(@class,'d-flex flex-row justify-content-start align-items-center table-row')]//mat-icon[@class='action-icon mat-icon notranslate material-icons mat-icon-no-color']")
	public List<WebElement> list_grid_actions;

	@FindBy(xpath="//h5[contains(text(),'De-Assign Case')]")
	public WebElement header_DeAssign;

	@FindBy(xpath="//button[contains(@class,'mat-raised-button')]")
	public List<WebElement> Deassign_buttons;
	public By byDeassign_buttons = By.xpath("//button[contains(@class,'mat-raised-button')]");

	@FindBy(xpath="//label[contains(text(),' User has no cases to De-Assign.')]")
	public WebElement text_NoCases_Deassign;

	@FindBy(xpath="//button[contains(@class,'mat-raised-button')]")
	public WebElement button_OK;	
	
	@FindBy(xpath="//div[contains(text(),'De-Assign')]")
	public WebElement deAssign;
	
	@FindBy(xpath="//label[contains(text(),'De-Assign this user?')]")
	public WebElement label_deassignCase;
	
	@FindBy(xpath="//button[contains(@class,'mat-raised-button mat-primary ng-star-inserted')]")
	public WebElement CA_all_buttons;
	
	@FindBy(xpath="//h3[@class='mat-subheader ng-star-inserted']")
	public WebElement header_Actions;

	@FindBy(xpath="//mat-icon[contains(text(),'assignment_return')]")
	public WebElement button_DeAssignAll;
}