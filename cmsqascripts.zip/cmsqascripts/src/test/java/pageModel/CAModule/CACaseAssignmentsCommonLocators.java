package pageModel.CAModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
public class CACaseAssignmentsCommonLocators {
	
	
	@FindBy(xpath = "//div[contains(text(), 'Case Assignments')] ")
	public WebElement caseAssignmentsPageHeader;
	
	@FindBy(xpath = "//div[@class='d-flex justify-content-between align-items-center w-100']")
	public List<WebElement> caseassignments_AllCategories;
	public By bycaseassignments_AllCategories = By.xpath("//div[@class='d-flex justify-content-between align-items-center w-100']");
	
	@FindBy(xpath="//span[@ref='eMenu']//span[@class='ag-icon ag-icon-menu']")
	public List<WebElement> Menu_Filter;
	
	@FindBy(xpath="//span[@class='ag-tab ag-tab-selected']")
	public WebElement filterTab;
	
	@FindBy(xpath="//strong[contains(text(),'No Activities')]")
	public WebElement text_noActivities;
	
	@FindBy(xpath="//label[@class='ag-set-filter-item']//span[@class='ag-icon ag-icon-checkbox-unchecked']")
	public List<WebElement> checkBox_FilterTab;
	
	@FindBy(xpath="//label[@class='ag-set-filter-item']//span[@class='ag-filter-value']")
	public List<WebElement> options_FilterTab;
	
	@FindBy(xpath="//span[@ref='lbRecordCount']")
	public WebElement count_FilteredRecords;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']//div[@class='mat-list-item-content']")
	public List<WebElement> CaseAsignments_SideMenu;
	
	@FindBy(xpath="//mat-nav-list/mat-list-item//div/span[1]")
	public List<WebElement> CaseAssignments_SideMenuText;
	
	@FindBy(xpath="//div[@ng-reflect-message='' and @class='raCode']")
	public List<WebElement> raCode;
	public By byraCode = By.xpath("//div[@ng-reflect-message='' and @class='raCode']");
	
	@FindBy(xpath="//div[@id='selectAll']//span[contains(@class,'ag-icon ag-icon-checkbox-checked')]")
	public WebElement checkbox_SelectAll_checked;
	
	@FindBy(xpath="//div[@class='ag-filter-checkbox']//span[contains(@class,'ag-icon ag-icon-checkbox-checked')]")
	public List<WebElement> checkbox_All_Filter_checked;
	
	@FindBy(xpath="//div[@class='ag-filter-checkbox']//span[contains(@class,'ag-icon ag-icon-checkbox-unchecked')]")
	public List<WebElement> checkbox_All_Filter_unchecked;
	
	@FindBy(xpath="//button[@ref='eApplyButton']")
	public WebElement button_Apply;
	
	@FindBy(xpath="//div[@id='selectAll']//span[contains(@class,'ag-icon ag-icon-checkbox-unchecked')]")
	public WebElement checkbox_SelectAll_unchecked;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[1]")
	public WebElement category1_ClinicalorReassessment;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[2]")
	public WebElement category2_RevieworMedical;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[3]")
	public WebElement category3_PsychiatricEvaluation;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[4]")
	public WebElement category4_WellnessServiceInitiation;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[5]")
	public WebElement category5_SSIServiceInitiation;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[6]")
	public WebElement category6_VRSServiceInitiation;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[7]")
	public WebElement category7_WellnessFollowUp;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[8]")
	public WebElement category8_ChildCareReturn;
	
	@FindBy(xpath="//span[contains(text(),'REFRESH')]")
	public WebElement button_Refresh;
	
	@FindBy(xpath="//mat-icon[@class='chevron_left mat-icon notranslate material-icons mat-icon-no-color']")
	public WebElement leftChevron;
	
	@FindBy(xpath="//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[2]")
	public List<WebElement> caseLoad;
	
	@FindBy(xpath="//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[3]")
	public List<WebElement> appointmentPerDay;
	
	@FindBy(xpath="//span[@class='ag-icon ag-icon-columns']")
	public WebElement Menu_Columns;

	@FindBy(xpath="//span[@class='ag-icon ag-icon-checkbox-checked']")
	public List<WebElement> checkbox_menu_columns;
	
	
	@FindBy(xpath="//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[@class='flex-child']")
	public List<WebElement> caseLoad_CMS_User;
	public By bycaseLoad_CMS_User = By.xpath("//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[@class='flex-child']");
	
//	@FindBy(xpath="//span[@class='ag-cell-value']")
//	public List<WebElement> CA_list_clientName;
	
	@FindBy(xpath="//div[@col-id='ACTIVITY_STATUS']")
	public List<WebElement> CA_column_Status;
	
	@FindBy(xpath="//div[@col-id='CLIENT_LN_FN']")
	public List<WebElement> CA_list_clientName;
	
	@FindBy(xpath="//button[@class='btn grid-custom-button']//mat-icon[contains(text(),'more_vert')]")
	public List<WebElement> list_actions;
	
	@FindBy(xpath="//app-assignment-dropdown-button[@class='ng-star-inserted']//button[@class='btn grid-custom-button']//mat-icon[contains(text(),'more_vert')]")
	public List<WebElement> list_actions_New;
	
	@FindBy(xpath="//span[@class='ag-selection-checkbox']//span[@class='ag-icon ag-icon-checkbox-unchecked']")
	public List<WebElement> all_CheckBox;
	
	@FindBy(xpath="//div[@class='mat-list-item-content'][contains(text(),'Assign')]")
	public WebElement assignButton;
	
	@FindBy(xpath="//div[@col-id='CMS_USER']")
	public List<WebElement> List_CMSUser;
	
	@FindBy(xpath="//div[contains(@col-id,'CLIENT_LN_FN')]")
	public List<WebElement> clientName;
	
	@FindBy(xpath="//div[@col-id='CHECKIN_DATETIME']")
	public List<WebElement> List_CheckIn_DateTime;
	
	@FindBy(xpath="//div[@col-id='ACTIVITY_LOOKUP']")
	public List<WebElement> List_AppointmentType;
	
	@FindBy(xpath="//div[@col-id='CASE_NUMBER']")
	public List<WebElement> caseAssignment_CaseNumber;
	
	@FindBy(xpath="//body//mat-list-item")
	public List<WebElement> caseAssignmentsCategories;

	@FindBy(xpath="//div[contains(@col-id,'CMS_USER')]")
	public List<WebElement> CA_column_CMSUser;
	
	@FindBy(xpath="//div[contains(text(),'De-Assign')]")
	public WebElement deAssign;
	
	@FindBy(xpath="//mat-icon[contains(text(),'assignment_turned_in')]")
	public WebElement icon_Assign;
	public By byicon_Assign = By.xpath("//mat-icon[contains(text(),'assignment_turned_in')]");
	
	@FindBy(xpath="//mat-icon[contains(text(),'assignment_returned')]")
	public WebElement icon_reAssign;
	public By byicon_reAssign = By.xpath("//mat-icon[contains(text(),'assignment_returned')]");

	@FindBy(xpath="//mat-icon[contains(text(),'assignment_return')]")
	public List<WebElement> icon_ReassignAndDesign_List;
	public By byicon_ReassignAndDesign_List = By.xpath("//mat-icon[contains(text(),'assignment_return')]");
	
	@FindBy(xpath="//mat-icon[contains(text(),'description')]")
	public WebElement icon_Appointment_Letter;
	public By byicon_Appointment_Letter = By.xpath("//mat-icon[contains(text(),'description')]");
	
	@FindBy(xpath="//mat-icon[contains(text(),'account_box')]")
	public WebElement icon_Client_Services_Screen;
	public By byicon_Client_Services_Screen = By.xpath("//mat-icon[contains(text(),'account_box')]");
	
	@FindBy(xpath="//div[contains(text(),'Re-Assign')]")
	public WebElement reAssign;
	
	@FindBy(xpath="//div[@class='case']")
	public WebElement case_FromTimeline;
	
	@FindBy(xpath="//div[@class='mat-select-arrow']")
	public WebElement dropdown_PageSize;
	
	@FindBy(xpath="//span[@class='mat-option-text']")
	public List<WebElement> dropdown_options;
	
	@FindBy(xpath="//div[contains(@class,'d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted')]")
	public List<WebElement> grid_rows;
	
	@FindBy(xpath="//div[@class='d-flex flex-row justify-content-start align-items-center table-row ng-star-inserted']//div[@ng-reflect-klass='cases']")
	public List<WebElement> timeline_Cases;
	
	@FindBy(xpath="//h3[@class='mat-subheader']")
	public List<WebElement> action_Headers;

	@FindBy(xpath="//div[contains(@class,'ag-row')]//div[contains(@col-id,'CLIENT_LN_FN')]")
	public List<WebElement> row_ClientName;
	
	@FindBy(xpath="//div[contains(@class,'ag-row')]//div[contains(@col-id,'APPOINTMENT_DATETIME')]")
	public List<WebElement> row_ApptDateTime;
	
	@FindBy(xpath="//span[@class='ag-header-select-all']//span[@class='ag-icon ag-icon-checkbox-unchecked']")
	public WebElement checkbox_SelectAll;
	public By bycheckbox_SelectAll = By.xpath("//span[@class='ag-header-select-all']//span[@class='ag-icon ag-icon-checkbox-unchecked']");
			
	@FindBy(xpath="//span[@class='ag-header-select-all']//span[@class='ag-icon ag-icon-checkbox-checked']")
	public WebElement checkbox_UnSelectAll;
	public By bycheckbox_UnSelectAll = By.xpath("//span[@class='ag-header-select-all']//span[@class='ag-icon ag-icon-checkbox-checked']");
	
			
}