package pageModel.CAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
public class CAAssignCasePageLocators {
	
	@FindBy(xpath="//div[@class='mat-list-item-content'][contains(text(),'Assign')]")
	public WebElement assignButton;

	@FindBy(xpath="//th[contains(text(),'Case Worker Name')]")
	public WebElement header_caseWorkerName;

	@FindBy(xpath="//td[contains(@class,'CMS_USER')]")
	public List<WebElement> caseWorkerNameToAssign;

	@FindBy(xpath="//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']//input[contains(@class,'checkbox')]")
	public List<WebElement> checkbox_caseWorkerAssign;

	@FindBy(xpath="//select[@ng-reflect-name='primaryCaseManager']")
	public WebElement boxPrimaryCaseManager;

	@FindBy(xpath="//span[contains(text(),'ASSIGN')]")
	public WebElement assignPopUp_AssignButton;
	
	@FindBy(xpath="//span[contains(text(),'CANCEL')]")
	public WebElement assignPopUp_CancelButton;
	
	@FindBy(xpath="//mat-icon[@class='chevron_left mat-icon notranslate material-icons mat-icon-no-color']")
	public WebElement leftChevron;
	
	@FindBy(xpath="//input[@ng-reflect-name='currentWorker']")
	public WebElement textbox_CurrentlyAssigned;
	
	@FindBy(xpath="//h5[contains(text(),'Case Details')]")
	public WebElement text_CaseDetails;
	
	@FindBy(xpath="//td[contains(@class,'cdk-column-Case-Number mat-column-Case-Number')]")
	public WebElement value_CaseNumber;
	
	@FindBy(xpath="//td[contains(@class,'cdk-column-Client-Name mat-column-Client-Name')]")
	public WebElement value_ClientName;
	
	@FindBy(xpath="//input[@formcontrolname='newWorker']")
	public WebElement textbox_AssignTo;
	
	@FindBy(xpath="//td[contains(@class,'cdk-column-CMS_USER mat-column-CMS_USER')]")
	public List<WebElement> assignModal_CaseWorkerName;
	
	@FindBy(xpath="//td[contains(@class,'cdk-column-TOTAL_CASES mat-column-TOTAL_CASES')]")
	public List<WebElement> assignModal_CaseLoad;
	
	@FindBy(xpath="//td[contains(@class,'cdk-column-TOTAL_CASES_TODAY mat-column-TOTAL_CASES_TODAY')]")
	public List<WebElement> assignModal_ApptPerDay;
	
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']")
	public WebElement button_Assign;
	
	@FindBy(xpath="//div[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']")
	public WebElement checkbox_CaseWorker;

	@FindBy(xpath="//button[@class='mr-2 mat-raised-button mat-primary ng-star-inserted']//span[contains(text(),'ASSIGN')]")
	public WebElement button_second_Assign;
}