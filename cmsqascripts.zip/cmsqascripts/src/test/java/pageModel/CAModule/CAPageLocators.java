package pageModel.CAModule;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class CAPageLocators {
	
	@FindBy(xpath="//button[@ref='eToggleButton']")
	public WebElement colFilter;
	@FindBy(xpath="//span[@ref='eLabel']")
	public List<WebElement> colFilterOpt;
	@FindBy(xpath="//button[@ref='eApplyButton']")
	public WebElement filterApplyBtn;
	
	@FindBy(xpath="//div[@col-id='ACTIVITY_STATUS']//span[@ref='eMenu']")
	public WebElement statFilter;
	@FindBy(xpath="//div[@class='ag-virtual-list-item']//div[@class='ag-filter-checkbox']/span")
	public List<WebElement> statListChkBox;
	@FindBy(xpath="//div[@class='ag-virtual-list-item']//div[@class='ag-filter-checkbox']//following-sibling::span")
	public List<WebElement> statChkBoxTxt;
	@FindBy(xpath="//span[@ref='eSummaryPanel']/span[@ref='lbRecordCount']")
	public WebElement recordCount;
	@FindBy(xpath="//div[@id='selectAll']/span")
	public WebElement selectAllChkBox;
	
	@FindBy(xpath="//div[@col-id='ACTIVITY_LOOKUP']")
	public List<WebElement> appointmentType;
	
	@FindBy(xpath="//div[contains(@class,'panelWidthZero')]")
	public List<WebElement> sideMenuBar;
	
	@FindBy(xpath="//mat-select")
	public WebElement dropDown;
	@FindBy(xpath="//mat-option")
	public List<WebElement> dropDownOpt;
	
	@FindBy(xpath="//input[@type='checkbox']")
	public WebElement allCasesChkBox;
	@FindBy(xpath="//mat-icon[contains(@class,'chevron_left')]")
	public WebElement chevLeftIcon;  
	@FindBy(xpath="//div[contains(@class,'selectedDate')]/span")
	public List<WebElement> selectedDate;
	@FindBy(xpath="//app-grid-date-selector/div")
	public WebElement dateGrid;
	
	@FindBy(xpath="//div[@class='scheduler border']")
	public WebElement scheBorder;
	
	@FindBy(xpath="//div[@class='raCode']/mat-icon[@style='color: red;']")
	public List<WebElement> raRedCode;
	@FindBy(xpath="//div[@class='raCode']/mat-icon[@style='color: rgb(226, 178, 42);']")
	public List<WebElement> raOrangeCode;
		
	@FindBy(xpath="//mat-nav-list/mat-list-item")
	public List<WebElement> sideMenu;
	@FindBy(xpath="//mat-nav-list/mat-list-item//div/span[@class='text-primary']")
	public List<WebElement> sideMenuPendCnt;
	@FindBy(xpath="//mat-nav-list/mat-list-item//div/span[1]")
	public List<WebElement> sideMenuTxt;
	
	@FindBy(xpath="//mat-nav-list[@class='mat-nav-list mat-list-base ng-star-inserted']/mat-list-item[1]")
	public WebElement clinicalorReassessment;
	@FindBy(xpath="//mat-icon[@class='chevron_left mat-icon notranslate material-icons mat-icon-no-color']")
	public WebElement leftChevron;
	
	@FindBy(xpath="//mat-icon[starts-with(@class,'error')]")
	public List<WebElement> errIcon;
	public By byErrIcon = By.xpath("//mat-icon[starts-with(@class,'error')]");
	
	@FindBy(xpath="//div[@ref='eCenterContainer']/div[@role='row']")
	public List<WebElement> caRow;
	
	@FindBy(xpath="//button[@placement='right']")
	public List<WebElement> actBtn;
	
	@FindBy(xpath="//div[@class='popover-body']//mat-list-item")
	public List<WebElement> actOpt;
	
	@FindBy(xpath="//div[@class='popover-body']//mat-list-item/div")
	public List<WebElement> actOptTxt;
	
	@FindBy(xpath="//div[@col-id='ACTIVITY_STATUS']")
	public List<WebElement> caStatusCol;
	@FindBy(xpath="//div[@col-id='APPOINTMENT_DATETIME']")
	public List<WebElement> caAptCol;
	@FindBy(xpath="//div[@col-id='CHECKIN_DATETIME']")
	public List<WebElement> chkInDateCol;
	
	@FindBy(xpath="//div[@col-id='CMS_USER']")
	public List<WebElement> caAssignToCol;
	
	
	
}
