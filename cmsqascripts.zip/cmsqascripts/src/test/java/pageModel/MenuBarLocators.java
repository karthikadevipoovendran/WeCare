package pageModel;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class MenuBarLocators {
	
	@FindBy(xpath="//button[@mat-icon-button]")
	public List<WebElement> menuBar;	

	@FindBy(xpath="//div[starts-with(@class,'d-flex')]//mat-list-item/div")
	public List<WebElement> menuOption;
	public By byMenuOption = By.xpath("//div[starts-with(@class,'d-flex')]//mat-list-item/div");

	
}
