package pageModel.CICOModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
public class CICOExitPackagePageLocators {
	
	/*text Exit package*/
	@FindBy(xpath="//div[contains(text(),'Exit Package')]")
	public WebElement text_Exit_package;
	
	/*Header Exit Package*/
	@FindBy(xpath= "//h5[contains(text(),'Exit Package')]")
	public WebElement header_Exit_Package;
	
	@FindBy(xpath="//div[contains(text(),' No documents found. ')]")
	public WebElement text_noDocuments;
	
	/*CheckBoxes in Exit Package*/
	@FindBy(xpath="//div[@class='mat-checkbox-inner-container']")
	public List<WebElement> checkbox_SSAorDR;
	
	/*Checkout button in exit package*/
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']")
	public WebElement exitPackage_CheckOutButton;
	
	@FindBy(xpath="//span[@class='tab-close ng-star-inserted']")
	public WebElement button_carfare_close;
	
	/*Header text Check In CheckOut*/
	@FindBy(xpath="//h5[contains(text(),'Check-In/Check-Out')]")
	public WebElement textCICO;

}