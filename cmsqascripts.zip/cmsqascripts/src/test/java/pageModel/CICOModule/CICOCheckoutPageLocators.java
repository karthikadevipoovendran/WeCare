package pageModel.CICOModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CICOCheckoutPageLocators {
	
	
	@FindBy(xpath="//div[@class='mat-list-item-content']//mat-icon[contains(text(),'event_available')]")
	public WebElement CICO_CheckOut;
	public By byCheckOut = By.xpath("//mat-icon[contains(text(),'event_available')]");
	
	/*Check-Out Option in Actions Tab*/
	@FindBy(xpath="//div[contains(text(),'Check-Out')]")
	public WebElement checkOut;
	public By bycheckOut = By.xpath("//div[contains(text(),'Check-Out')]");

	/*Car Fare History Header*/
	@FindBy(xpath="//h5[contains(text(),'Car Fare History')]")
	public WebElement header_CarFare_History;
	public By byHeader_Car_Fare_History = By.xpath("//h5[contains(text(),'Car Fare History')]");
	
	
}