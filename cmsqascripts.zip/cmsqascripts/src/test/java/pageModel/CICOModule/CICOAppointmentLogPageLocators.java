package pageModel.CICOModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CICOAppointmentLogPageLocators {
	
	
	@FindBy(xpath="//mat-icon[contains(@class,'more_vert')]")
	public WebElement dotMenuBtn;
	@FindBy(xpath="//button[@color='primary']")
	public WebElement logoutBtn;
	
	@FindBy(xpath="//ul/li")
	public List<WebElement> checkInTabs;
	@FindBy(xpath="//ul/li/a/span[2]/i")
	public List<WebElement> tabCloseBtn;
	@FindBy(xpath="//div[@id='cdk-describedby-message-container']")
	public WebElement msgContainer;
	public By byMsgContainer = By.xpath("//div[@id='cdk-describedby-message-container']");
	
	@FindBy(xpath="//div[@col-id='CLIENT_LN_FN']")
	public List<WebElement> checkPageClientName;
	@FindBy(xpath="//div[@class='ag-center-cols-clipper']//div[@role='row'][1]")
	public WebElement rowIndex;
	
	@FindBy(xpath="//mat-select")
	public WebElement dropDown;
	@FindBy(xpath="//mat-option")//,at//
	public List<WebElement> dropDownOpt;
	
	@FindBy(xpath="//input[@type='checkbox' and contains(@id,'mat-checkbox')]")
	public WebElement allApp;
	
	@FindBy(xpath="//button[@class='btn grid-custom-button ng-star-inserted']")
	public List<WebElement> checkInActionBtn;
	@FindBy(xpath="//mat-list-item")
	public List<WebElement> checkInActionOptionBtn;
	@FindBy(xpath="//div[@class='mat-list-item-content']")
	public List<WebElement> checkInActionOptionBtnText;

	@FindBy(xpath="//div[@col-id='APPOINTMENT_DATETIME']")
	public List<WebElement> appointmentDateCol;
	public By byAppointmentDateCol = By.xpath("//div[@col-id='APPOINTMENT_DATETIME']");
	
	@FindBy(xpath="//h5")
	public WebElement checkInAppointmentLogPageHeader;
	public By byCheckInAppointmentLogPageHeader = By.xpath("//h5");
	
	@FindBy(xpath="//div[@col-id='CMS_USER']")
	public List<WebElement> checkInAssignedToCol;
	@FindBy(xpath="//div[@col-id='CHECKOUT_DATETIME']")
	public List<WebElement> checkOutDateCol;

	@FindBy(xpath="//div[@col-id = 'CHECKIN_DATETIME']")
	public List<WebElement> checkInDateCol;
	public By byCheckInDateCol = By.xpath("//div[@col-id = 'CHECKIN_DATETIME']");

	@FindBy(xpath="//div[starts-with(@class,'toast-message')]")
	public List<WebElement> toastMsgs;

	@FindBy(xpath="//div[@col-id='0']")
	public List<WebElement> clientNameCol;

	@FindBy(xpath="//span[@ref='eMenu']")
	public List<WebElement> burgerMenu;
	@FindBy(xpath="//select[@id='filterType']")
	public WebElement filterDrpDwn;
	@FindBy(xpath="//input[@id='filterText']")
	public WebElement filterTxt;
	@FindBy(xpath="//div[@ref='tabHeader']/span")
	public WebElement arrowMenu;
	
	@FindBy(xpath="//div[@col-id='CASE_NUMBER']")
	public List<WebElement> caseNumCol;
	@FindBy(xpath="//div[@col-id='ACTIVITY_LOOKUP']")
	public List<WebElement> appointmentType;
	@FindBy(xpath="//div[@class='ag-virtual-list-container']//div[@class='ag-filter-checkbox']/span")
	public List<WebElement> drpDwnChkBox;
	@FindBy(xpath="//div[@class='ag-virtual-list-container']//span[@class='ag-filter-value']")
	public List<WebElement> drpDwnTxt;
	
	@FindBy(xpath="//span[@class='mat-checkbox-label']")
	public WebElement label_AllAppointments;
	
	@FindBy(xpath="//div[@class='mat-checkbox-inner-container']")
	public WebElement checkbox_AllAppointments;
	
	@FindBy(xpath="//input[@aria-checked='true']")
	public WebElement validate_CheckBox_AA;
	public By byvalidate_CheckBox_AA = By.xpath("//input[@aria-checked='true']");
	
			
	
	
}
