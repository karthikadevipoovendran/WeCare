package pageModel.CICOModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
public class CICOAppointmentsToSchedulePageLocators {
	
	
	/*Car Fare History Header*/
	@FindBy(xpath="//h5[contains(text(),'Car Fare History')]")
	public WebElement header_CarFare_History;
	public By byHeader_Car_Fare_History = By.xpath("//h5[contains(text(),'Car Fare History')]");
	
	@FindBy(xpath="//div[contains(text(),'Appointment')]")
	public WebElement text_AppointmentToSchedule;
	
	@FindBy(xpath="//div[@class='mat-checkbox-inner-container']")
	public WebElement checkbox_NoAppointments;
	
	@FindBy(xpath="//span[contains(text(),'No Appointments to be scheduled')]")
	public WebElement text_NoAppointments;
	
}