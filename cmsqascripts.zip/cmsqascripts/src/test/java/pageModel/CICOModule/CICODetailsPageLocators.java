package pageModel.CICOModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CICODetailsPageLocators {
	
	
	@FindBy(xpath="//mat-nav-list/mat-list-item[2]/div[@class='mat-list-item-content']")
	public WebElement sideMenu;
	@FindBy(xpath="//mat-card-title")
	public WebElement uplHeader;
	@FindBy(xpath="//input[@type='file']")
	public WebElement fileBtn;
	@FindBy(xpath="//h6")
	public WebElement uplSubHeader;
	@FindBy(xpath="//select[@name='SELECTEDVALUE']")
	public WebElement selectType;
	@FindBy(xpath="//documents-file-upload//button[contains(@class,'mat-raised-button')]")
	public List<WebElement> uploadBtn;
	@FindBy(xpath="//div[contains(@class,'toast-message')]")
	public List<WebElement> toastMsg;
	@FindBy(xpath="//li[contains(@class,'dynamic-tab')]")
	public List<WebElement> dynamicTabs;
	@FindBy(xpath="//li[contains(@class,'dynamic-tab')]//span/i")
	public List<WebElement> dynamicTabsClose;
	
	@FindBy(xpath="//input[starts-with(@class,'mat-radio-input')]")
	public List<WebElement> checkInRaRadioOptions;
	public By byCheckInRaRadioOptions = By.xpath("//input[starts-with(@class,'mat-radio-input')]");
	
	@FindBy(xpath="//div[starts-with(@class,'toast-message')]")
	public List<WebElement> errToastMsg;
	@FindBy(xpath="//form/h5")
	public WebElement checkInHeader;
	
	@FindBy(xpath="//mat-pseudo-checkbox[@class='mat-pseudo-checkbox']/following-sibling::div[@class='mat-list-text']")
	public List<WebElement> checkInRaCheckboxText;
	@FindBy(xpath="//mat-pseudo-checkbox[@class='mat-pseudo-checkbox']")
	public List<WebElement> checkInRaCheckbox;
	
	@FindBy(xpath="//select[@formcontrolname='SELECTEDVALUE']")
	public List<WebElement> checkInDocType;
	@FindBy(xpath="//input[@ng-reflect-name='TOTAL_PAGES_COUNT']")
	public List<WebElement> checkInDocPage;
	
	@FindBy(xpath="//button[@class='btn']")
	public List<WebElement> checkInDocBtn;
	@FindBy(xpath="//button[starts-with(@class,'mat-raised-button')]")
	public List<WebElement> checkInBtns;
	

	
	
}
