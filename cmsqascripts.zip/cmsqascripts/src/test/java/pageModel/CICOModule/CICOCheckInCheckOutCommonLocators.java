package pageModel.CICOModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
public class CICOCheckInCheckOutCommonLocators {
	

	@FindBy(xpath="//div[@id='cdk-describedby-message-container']")
	public WebElement msgContainer;
	public By byMsgContainer = By.xpath("//div[@id='cdk-describedby-message-container']");
	
	@FindBy(xpath="//h5[contains(text(),'Check-In/Check-Out')]")
	public WebElement textCICO;
	
	@FindBy(xpath="//div[@col-id='APPOINTMENT_DATETIME']")
	public List<WebElement> appointmentDateCol;
	public By byAppointmentDateCol = By.xpath("//div[@col-id='APPOINTMENT_DATETIME']");

	@FindBy(xpath="//span[@class='ag-header-cell-text'][contains(text(),'Client Name')]")
	public WebElement CN;
	
	@FindBy(xpath="//span[@class='ag-header-cell-text'][contains(text(),'Client Name')]")
	public WebElement headerClientName;
	
	@FindBy(xpath="//h5[contains(text(),'Case Details')]")
	public WebElement text_CaseDetails;
	
	@FindBy(xpath="//div[contains(@col-id,'CLIENT_LN_FN')]")
	public List<WebElement> clientName;
	
	@FindBy(xpath="//div[contains(@col-id,'CHECKIN_DATETIME')]")
	public List<WebElement> checkInDateTimeList;
	
	@FindBy(xpath="//div[contains(@col-id,'CMS_USER')]")
	public List<WebElement> cMSUserList;
	
	@FindBy(xpath="//div[contains(@col-id,'ACTIVITY_LOOKUP')]")
	public List<WebElement> appointmentTypeList;
	
	@FindBy(xpath="//div[contains(@col-id,'CASE_NUMBER')]")
	public List<WebElement> caseNumberList;
	
	@FindBy(xpath="//mat-icon[contains(@class,'action-icon mat-icon')]")
	public List<WebElement> actionIconList;

	@FindBy(xpath="//div[@class='mat-list-item-content']")
	public List<WebElement> actionTabListItems;
	public By byactionTabListItems = By.xpath("//div[@class='mat-list-item-content']");
	
	@FindBy(xpath = "//h5[contains(text(),'Opt-Out')]")
	public WebElement text_Opt_Out;
	
	@FindBy(xpath="//button[@class='mat-raised-button ng-star-inserted']")
	public WebElement button_Opt_Out_Cancel;
	
	@FindBy(xpath="//button[@class='mr-2 mat-raised-button ng-star-inserted']")
	public WebElement button_Modal_Cancel;
	
	@FindBy(xpath="//label[contains(text(),' Were there any Reasonable Accommodation(s) provided?')]")
	public WebElement CICO_CheckIn_Label_Recommendations;
	
	@FindBy(xpath="//label[contains(text(),'Type of interview')]")
	public WebElement text_typeOfInterview;
	public By bytext_typeOfInterview = By.xpath("//label[contains(text(),'Type of interview')]");
	
	@FindBy(xpath="//select[@formcontrolname='SELECTEDVALUE']")
	public WebElement dropdown_typeOfInterview;
	
	@FindBy(xpath="//div[@class='mat-radio-outer-circle']")
	public List<WebElement> CICO_CheckIn_RadioButtons;
	
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']//span[contains(text(),'CHECK-IN')]")
	public WebElement button_CheckIn;
	
	@FindBy(xpath="//div[contains(@col-id,'CLIENT_LN_FN')]")
	public List<WebElement> list_clientName;
	
	@FindBy(xpath="//div[@col-id='CMS_USER']")
	public List<WebElement> list_cmsUser;
	
	@FindBy(xpath="//div[contains(@col-id,'CHECKIN_DATETIME')]")
	public List<WebElement> list_checkInDateTime;
	
	@FindBy(xpath="//div[@class='mat-select-arrow']")
	public WebElement selectArrow;
	
	@FindBy(xpath="//span[@class='mat-option-text'][contains(text(),'50')]")
	public WebElement valueFromDropDown;
	
}