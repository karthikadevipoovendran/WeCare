package pageModel.CICOModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
public class CICOCarFarePageLocators {
	
	/*Car Fare History Header*/
	@FindBy(xpath="//h5[contains(text(),'Car Fare History')]")
	public WebElement header_CarFare_History;
	public By byHeader_Car_Fare_History = By.xpath("//h5[contains(text(),'Car Fare History')]");
	
	/*CarFare History Action button*/
	@FindBy(xpath="//button[@class='btn grid-custom-button']//mat-icon[@class='action-icon mat-icon notranslate material-icons mat-icon-no-color']")
	public WebElement CarFareHistory_ActionButton;
	
	/*CarFare History Edit Icon*/
	@FindBy(xpath="//mat-icon[@class='list-icon mat-list-icon mat-icon notranslate material-icons mat-icon-no-color']")
	public WebElement CarFare_History_Edit;
	
	@FindBy(xpath="//div[@class='mat-list-item-ripple mat-ripple']")
	public WebElement Edit;
	
	/*Option Car Fare*/
	@FindBy(xpath="//div[contains(text(),'Car Fare')]")
	public WebElement option_CarFare;
	
	/*Add button*/
	@FindBy(xpath="//span[@class='mat-button-wrapper']//i[@class='mr-1 button-icon fas fa-plus']")
	public WebElement button_Add;
	
	/*Card Number Text Box*/
	@FindBy(xpath="//input[@class='form-control ng-untouched ng-pristine ng-invalid']")
	public WebElement input_CardNumber;

	@FindBy(xpath="//button[@class='mat-icon-button']")
	public List<WebElement> buttons;
	
	/*Select Today's date from date picker*/
	@FindBy(xpath="//div[@class='mat-calendar-body-cell-content mat-calendar-body-today']")
	public WebElement todays_date;
	
	@FindBy(xpath="//select[@class='form-control ng-untouched ng-pristine ng-invalid']")
	public List<WebElement> checkBoxes_Issuance;

	@FindBy(xpath="//button[@class='mat-raised-button ng-star-inserted']")
	public WebElement button_Cancel;
	
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary ng-star-inserted']")
	public List<WebElement> button_Save;

	/*text signature required*/
	@FindBy(xpath="//div[contains(text(),'Signature Required')]")
	public WebElement text_SignatureRequired;

	/*Electronic button*/
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary ng-star-inserted']//span[contains(text(),'Electronic')]")
	public WebElement button_Electronic;
	public By byButtonElectronic = By.xpath("//button[@class='mat-raised-button mat-primary ng-star-inserted']//span[contains(text(),'Electronic')]");
	
	
	/*Handwritten button*/
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary ng-star-inserted']//span[contains(text(),'Handwritten')]")
	public WebElement button_Handwritten;
	public By byButtonHandwritten = By.xpath("//button[@class='mat-raised-button mat-primary ng-star-inserted']//span[contains(text(),'Handwritten')]");
	
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary ng-star-inserted']")
	public List<WebElement> buttons_carFare_sign;
	
	/*Verify button*/
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']//span[contains(text(),'Verify')]")
	public WebElement button_Verify;
	

	/*Client signature complete text*/
	@FindBy(xpath="//label[contains(text(),'Client Signature is complete!')]")
	public WebElement text_ClientSignatureCompleted;
	
	/*Text box Sign Here*/
	@FindBy(xpath="//input[contains(@formcontrolname,'SIGNATURE')]")
	public WebElement input_SignHere;
	
	/*Button FakeSign Here*/
	@FindBy(xpath="//span[contains(text(),'Fake Sign')]")
	public WebElement button_FakeSign;
	
	/*Sign Button*/
	@FindBy(xpath="//button[@class='mat-raised-button mat-primary']//span[contains(text(),'Sign')]")
	public WebElement button_Sign;
	
	/*Text User Signature is complete*/
	@FindBy(xpath="//label[contains(text(),'User Signature is complete!')]")
	public WebElement text_UserSignature;
	
	/*Signature Pad Cancel Button*/
	@FindBy(xpath="//button[@class='mat-raised-button mat-default']//span[contains(text(),'Cancel')]")
	public WebElement button_SignaturePad_Cancel;
	
	/*Header text Check In CheckOut*/
	@FindBy(xpath="//h5[contains(text(),'Check-In/Check-Out')]")
	public WebElement textCICO;
	
	/*Submit button*/
	@FindBy(xpath="//span[contains(text(),'Submit')]")
	public WebElement button_Submit;
	
	/*text edit car fare*/
	@FindBy(xpath="//h5[@class='ng-star-inserted']")
	public WebElement text_EditCarFare;

	/*Edit button*/
	@FindBy(xpath="//button[contains(text(),'Edit')]")
	public List<WebElement> button_Edit;

	@FindBy(xpath="//div[@col-id='ISSUANCE_DATE']")
	public List<WebElement> column_IssuanceDate;
	
	@FindBy(xpath="//div[@col-id='ISSUANCE_REASON_ID']")
	public List<WebElement> column_IssuanceReason;
	
	@FindBy(xpath="//div[@col-id='ISSUANCE_AMOUNT_ID']")
	public List<WebElement> column_IssuanceAmount;
	
	@FindBy(xpath="//div[@col-id='CARD_NUMBER']")
	public List<WebElement> column_CardNumber;	
	
	@FindBy(xpath="//span[@class='tab-close ng-star-inserted']")
	public WebElement button_carfare_close;
	public By bybutton_carfare_close = By.xpath("//span[@class='tab-close ng-star-inserted']");
	
	@FindBy(xpath="//div[contains(text(),' No documents found. ')]")
	public WebElement text_noDocuments;
	
	@FindBy(xpath="//select[@class='form-control ng-untouched ng-pristine ng-valid']")
	public List<WebElement> edit_checkBoxes_Issuance;

}