package pageModel.CICOModule;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CICOReSchedulePageLocators {
	
	@FindBy(xpath="//h5")
	public List<WebElement> rescheduleScreenHeader;
	@FindBy(xpath="//button[@class='mat-raised-button']")
	public WebElement rsScreenCancelBtn;
	
	@FindBy(xpath="//span[@class='example-trigger']")
	public WebElement rsDatePickerBtn;
	public By byRsDatePickerBtn = By.xpath("//span[@class='example-trigger']");

}
