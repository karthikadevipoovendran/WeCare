package pageModel.CICOModule;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CICOClientServicesScreenPageLocators {
	
	@FindBy(xpath="//div[contains(@class,'modal-header')]/h5")
	public WebElement cssHeader;
	@FindBy(xpath="//button[contains(@class,'mat-raised-button')]")
	public WebElement closeCSSBtn;
	
}
