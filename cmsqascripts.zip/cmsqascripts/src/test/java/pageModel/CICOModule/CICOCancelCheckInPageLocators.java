 package pageModel.CICOModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
public class CICOCancelCheckInPageLocators {
	
	@FindBy(xpath="//h3[contains(text(),'Actions')]")
	public WebElement ActionsButton;
	public By byActionsButton = By.xpath("//h3[contains(text(),'Actions')]");

	@FindBy(xpath="//div[@class='mat-list-item-content']//mat-icon[contains(text(),'schedule')]")
	public WebElement CICO_Reschedule;
	public By byReschedule = By.xpath("//mat-icon[contains(text(),'schedule')]");

	@FindBy(xpath="//div[@class='mat-list-item-content']//mat-icon[contains(text(),'event_busy')]")
	public WebElement CICO_CancelCheckIn;
	public By byCancelCheckIn = By.xpath("//mat-icon[contains(text(),'event_busy')]");

	@FindBy(xpath="//div[@class='mat-list-item-content']//mat-icon[contains(text(),'event_available')]")
	public WebElement CICO_CheckOut;
	public By byCheckOut = By.xpath("//mat-icon[contains(text(),'event_available')]");

	@FindBy(xpath="//div[@class='mat-list-item-content']//mat-icon[contains(text(),'description')]")
	public WebElement CICO_AppointmentLetter;
	public By byAppointmentLetter = By.xpath("//mat-icon[contains(text(),'description')]");

	@FindBy(xpath="//div[@class='mat-list-item-content']//mat-icon[contains(text(),'account_box')]")
	public WebElement CICO_ClientServicesScreen;
	public By byClientServicesScreen = By.xpath("//mat-icon[contains(text(),'account_box')]");

	@FindBy(xpath="//h5[contains(text(),'Cancel Check-In')]")
	public WebElement checkInTextInPopup;
	
	@FindBy(xpath="//textarea")
	public WebElement reasonForCancelTextBox;

	@FindBy(xpath="//span[contains(text(),'CONFIRM')]")
	public WebElement confirmButton;
	
	@FindBy(xpath="//div[@class='toast-message ng-star-inserted']")
	public WebElement popUpMessage;
	
	@FindBy(xpath="//div[contains(@col-id,'0')]")
	public List<WebElement> list_clientName;
	
	@FindBy(xpath="//mat-icon[contains(@class,'action-icon mat-icon')]")
	public List<WebElement> actionIconList;

	@FindBy(xpath="//div[contains(@col-id,'CHECKIN_DATETIME')]")
	public List<WebElement> list_checkInDateTime;

	@FindBy(xpath="//div[@col-id='CMS_USER']")
	public List<WebElement> list_cmsUser;
	
}