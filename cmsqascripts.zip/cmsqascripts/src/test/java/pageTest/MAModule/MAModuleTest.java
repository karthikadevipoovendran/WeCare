package pageTest.MAModule;

import java.util.ArrayList;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageTest.TestBase;
import testUtil.ExcelUtil;
import testUtil.Utility;

public class MAModuleTest extends TestBase {

	@Test(priority = 0, groups = { "regression", "MAModule" })
	public void OpenCaseFromMyAssignments() {	
		mAPageActions.navigateToMyAssignments("baseURL", "/myassignments");
		mAPageActions.openAssignedTask("Open");
		mAPageActions.confirmTask();
		//mAPageActions.verifyMyAssignmentPageHeader("My Assignments");
	}
	
//	@Test(priority = 0, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void assignUserAndOpenCase(ArrayList<String> inputSheet) {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//		MAPageCommonActions.getUserDetails();
//		MAPageCommonActions.openCaseInMyAssignments("baseURL", "/myassignments");
//	}
	
	@DataProvider(name = "loginData")
	public Object[][] loginDp() {
		String inputSheet = "Login_Input";
		return ExcelUtil.getTableArray(Utility.ExcelBasePath + "/CICO_Data.xlsx", inputSheet);
	}
	
	@Test(priority = 1, groups = { "regression", "MAModule" }) // dataProvider="cAssessmentData"
	public void ReleaseInfo() {
		
		mAReleasePageActions.clickOnReleaseTab();
		mAReleasePageActions.provideReleaseInfo("Release", "test_treatmentProv", "Neurology", "100 Old St", "Hilltown", "NY", "10021", "0049382439", "0092929022", "Yes", "test_Doc");	
		mAReleasePageActions.navigateBackToRATab();
	
	}

	@Test(priority = 2, groups = { "regression", "MAModule" }) // dataProvider="cAssessmentData"
	public void clientAssessmentInfo() { // ArrayList<String> inputSheet
		//mACaseOverviewPageActions.verifyUserLandedOnCaseOverviewPage("Case Overview");
		mAClinicalAssessPageActions.clickClientInfoSideMenu();

		mAReasonAccommoPageActions.provideReasonableAccomodationInfo("Reasonable Accommodation");

		mALanguageNeedPageActions.provideLanguageNeedInfo("Language Needs", "Russian", "", "Yes", "Yes", "Yes", "No",
				"", "", "test");

		mADocReviewPageActions.provideDocReviewInfo("Document Review", "test_doc");

		mAReleasePageActions.navigateToNextTab();

		mADemoInfoPageActions.provideDemoInfo("Demographic Info", "Email", "Mailing", "Cell Phone", "", "", "", "",
				"Asian/Pacific Islander", "");

		mAEmergencyInfoPageActions.provideEmergencyInfo("Emergency Info", "Doe", "John", "100 pacific st",
				"Throgs Neck", "718-123-4567", "NY", "11301", "718-123-4567", "test@mail.com", "STEP SON");

		mAFFMSupportPageActions.provideSupportInfo("Financial/Food/Medical Support", "Denied", "test_ssd", "Medicare",
				"", "", "Yes", "No", "Not Applicable", "Yes", "No", "Yes");

		mAPurposeOfVisitPageActions.providePurposeOfVisitInfo("Test_Purpose");

		mAMedicalConditionPageActions.provideMedicalConditionInfo("Yes", "Yes", "test_Condition", "Yes", "Unstable",
				"Current", "> 12 Months", "test_abilityWork", "Untreated", "100 Odd St", "test_Clinic", "New york",
				"11011", "Other (Specify)", "test_specOther", "NY", "2 years", "No", "test_Compliance", "Yes", "Flu",
				"No", "test_CompInTakingMedic", "Yes", "test_HospitalHistory", "Positive", "Yes", "Yes", "test_hivExp");

		mAMentalHealthPageActions.provideMentalHealthConditionInfo("No", "No", "test_Condition", "Yes", "Unstable",
				"Current", "> 12 Months", "test_abilityWork", "Untreated", "100 Odd St", "test_Clinic", "New york",
				"11011", "Other (Specify)", "test_specOther", "NY", "2 years", "No", "test_Compliance", "Yes", "Flu",
				"No", "test_CompInTakingMedic", "Yes", "test_HospitalHistory", "Yes", "Yes", "No", "Yes",
				"test_HearVoiceExp", "Yes", "Yes", "No", "Yes", "test_thoughtAttemptExp");
	}

	@DataProvider(name = "cAssessmentData")
	public Object[][] clientAssessmentData() {
		String inputSheet = "_Input";
		return ExcelUtil.getTableArray(Utility.ExcelBasePath + "/MA_Data.xlsx", inputSheet);
	}

//	@Test(priority = 2, groups = { "regression", "MAModule" })
//	public void fillDetailsinObservationsAndClientPresentationPage() {
//		mAClinicalAssessPageActions.clickADLLimitationsSideMenu();
//		mAObservationAndClientPresentationPageActions.validateUserLandedOnObservationPage();
//		mAObservationAndClientPresentationPageActions.provideClientAppearanceInfo("Client is neatly dressed");
//		mAClinicalAssessPageActions.navigateToNextPage();
//	}
//
//	@Test(priority = 3, groups = { "regression", "MAModule" })
//	public void provideExplanationForActivities() {
//		mAADLAndOtherActivitiesPageActions.validateUserLandedOnADLAndOtherActivitiesPage();
//		mAADLAndOtherActivitiesPageActions.validate_Content();
//		mAADLAndOtherActivitiesPageActions.select_CheckBoxes();
//		mAADLAndOtherActivitiesPageActions
//				.provideExplanation("Does not have access to any of the following mentioned above");
//		mAClinicalAssessPageActions.navigateToPreviousPage();
//		mAClinicalAssessPageActions.navigateToNextPage();
//	}
//
//	@Test(priority = 4, groups = { "regression", "MAModule" })
//	public void validateExplainTextboxonSelectingNone() {
//		mAADLAndOtherActivitiesPageActions.validateUserLandedOnADLAndOtherActivitiesPage();
//		mAADLAndOtherActivitiesPageActions.selectOptionNone();
//		mAADLAndOtherActivitiesPageActions.verifyExplainTextboxNotDisplayed();
//		mAADLAndOtherActivitiesPageActions.verifyOptionsDisabled();
//		mAClinicalAssessPageActions.navigateToPreviousPage();
//		mAClinicalAssessPageActions.navigateToNextPage();
//	}
//
//	@Test(priority = 5, groups = { "regression", "MAModule" })
//	public void provideDetailsForTravelAssistance() {
//		// mAClinicalAssessPageActions.navigateToNextPage();
//	}
//
//	@Test(priority = 6, groups = { "regression", "MAModule" })
//	public void provideDetailsForOtherActivities() {
//		mAADLAndOtherActivitiesPageActions.provideDetailsForOtherActivities("Reading");
//		// mAClinicalAssessPageActions.navigateToNextPage();
//	}

}
