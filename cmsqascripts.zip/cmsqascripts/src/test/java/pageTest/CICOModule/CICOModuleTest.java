package pageTest.CICOModule;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageTest.TestBase;
import testUtil.ExcelUtil;
import testUtil.Utility;


public class CICOModuleTest extends TestBase {

	@Test(priority = 0, dataProvider = "loginData", groups = { "regression", "CICOModule" })
	public void userLoginAndLandedOnAppointmentLogScreen(ArrayList<String> inputSheet) {
		logInPageActions.loginUserToTheApp(inputSheet.get(0), inputSheet.get(1));
		vendorSiteActions.clickVendorSiteBtn("YouthPathways", "Recare", "Site 4");
		cICOAppointmentLogPageActions.verifyClientLandedOnAppLogPage("Check-In/Check-Out");
	}
	@DataProvider(name = "loginData")
	public Object[][] loginDp() {
		String inputSheet = "Login_Input";
		return ExcelUtil.getTableArray(Utility.ExcelBasePath + "/CICO_Data.xlsx", inputSheet);
	}

////	@Test(dependsOnMethods = "userLoginAndLandedOnAppointmentLogScreen", dataProvider = "appLogData", groups = {"regression", "CICOModule" })
//	public void appointmentLogScreenDateDisplayValidation(List<ArrayList<String>> validSheet, ArrayList<String> inputSheet) {
//		cICOAppointmentLogPageActions.verifyAppointmentChronologicalOrder();
//		cICOAppointmentLogPageActions.filterClientName();
//		cICOAppointmentLogPageActions.filterWMSCase();
//		cICOAppointmentLogPageActions.filterAppointmentType();
////		cICOAppointmentLogPageActions.verifyAppointmentType(validSheet.get(0));
//	}
//
//	@DataProvider(name = "appLogData")
//	public Object[][] appLogDp() {
//		String validSheet = "AppLog_Valid";
//		String inputSheet = "AppLog_Input";
//		return ExcelUtil.getTableArray(Utility.ExcelBasePath + "/CICO_Data.xlsx", validSheet, inputSheet);
//	}
//
//	@Test(priority = 1, groups = { "regression", "CICOModule" })
//	public void cancelCheckIn_PendingUser() {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CICOCancelCheckInPageActions.getDetailsofCheckedInUser();
//		CICOCheckInCheckOutCommonActions.clickActionButtonforCheckedInUser();
//		CICOCancelCheckInPageActions.cancelCheckIn();
//		CICOCheckInCheckOutCommonActions.verifyLogViewAfterCancelCheckIn();
//	}

//	@Test(priority = 2, groups = { "regression", "CICOModule" })
//	public void cancelCheckIn_AssignedUser() {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CICOCancelCheckInPageActions.getDetailsofCheckedInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetailsfromCICO();
//		CAAssignCasePageActions.assignToAnyQHP();
//		CICOCheckInCheckOutCommonActions.clickActionButtonforCheckedInUser();
//		CICOCancelCheckInPageActions.cancelCheckIn();
//		CICOCheckInCheckOutCommonActions.verifyLogViewAfterCancelCheckIn();
//	}
//
//	@Test(priority = 3, dataProvider = "loginData", groups = { "regression", "CICOModule" })
//	public void cancelCheckIn_ProgressUser(ArrayList<String> inputSheet) {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CICOCancelCheckInPageActions.getDetailsofCheckedInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetailsfromCICO();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//		MAPageCommonActions.getUserDetailsfromCICO();
//		MAPageCommonActions.openCaseInMyAssignments("baseURL", "/myassignments");
//		CICOCheckInCheckOutCommonActions.clickActionButtonforCheckedInUser();
//		CICOCancelCheckInPageActions.cancelCheckIn();
//		CICOCheckInCheckOutCommonActions.verifyLogViewAfterCancelCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//	}
//
//	@Test(priority = 4, groups = { "regression", "CICOModule" })
//	public void cancelCarFare() {
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetailsfromCICO();
//		CAAssignCasePageActions.assignToAnyQHP();
//		CICOCheckInCheckOutCommonActions.clickActionButtonforCheckedInUser();
//		CICOCheckoutPageActions.getDetailsofCheckedInUser();
//		CICOCheckoutPageActions.checkOut();
//		CICOCarFarePageActions.getDetailsOfUserToCheckOut();
//		CICOCarFarePageActions.cancelCarFare("1234567890");
//		//CICOCarFarePageActions.cancelCarFareFromSignaturePad("1234567890");
//	}
//
//	@Test(priority = 5, groups = { "regression", "CICOModule" })
//	public void checkOutWithoutCarFare() {
//
//		CICOCarFarePageActions.closeCarFareScreen();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.clickActionButtonforCheckedInUser();
//		CICOCheckoutPageActions.getDetailsofCheckedInUser();
//		CICOCheckoutPageActions.checkOut();
//		CICOAppointmentsToSchedulePageActions.getDetailsofCheckedInUser();
//		CICOAppointmentsToSchedulePageActions.appointmentToSchedule();
//		CICOExitPackagePageActions.getDetailsofCheckedInUser();
//		CICOExitPackagePageActions.exitPackage();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//	}
//
//	@Test(priority = 6, groups = { "regression", "CICOModule" })
//	public void checkOutWithCarFare() {
//
//		CICOCarFarePageActions.closeCarFareScreen();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetailsfromCICO();
//		CAAssignCasePageActions.assignToAnyQHP();
//		CICOCheckInCheckOutCommonActions.clickActionButtonforCheckedInUser();
//		CICOCheckoutPageActions.getDetailsofCheckedInUser();
//		CICOCheckoutPageActions.checkOut();
//		CICOCarFarePageActions.getDetailsOfUserToCheckOut();
//		CICOCarFarePageActions.addCarFareValidation("1234567890");
//		CICOCarFarePageActions.closeCarFareScreen();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//	}
//
//	@Test(priority = 7, groups = { "regression", "CICOModule" })
//	public void userReScheduleFromAppointmentLogScreen() {
//		cICOAppointmentLogPageActions.clickReScheduleFromAppointmentLogPage("Reschedule");
//		cICOReSchedulePageActions.verifyClientLandedOnReScheduleScreen("Reschedule");
//	}
//
//	@Test(priority = 8, groups = { "regression", "CICOModule" })
//	public void verifyClientServicesScreen() {
//		cICOAppointmentLogPageActions.clickCSSAppointmentLogPageCheckIn("Client Services Screen");
//		cICOClientServicesScreenPageActions.verifyClientServicesScreen("Client Services Screen");
//	}
//
//	@Test(priority = 9, groups = { "regression", "CICOModule" })
//	public void userCheckInToSaveInfo() {
//		cICOAppointmentLogPageActions.clickCheckInAppointmentLogPageCheckIn("Check-In");
//		cICODetailsPageActions.clientLandedOnCheckInScreen("Check-In");
//		cICODetailsPageActions.saveCheckInDetails();
//		cICOAppointmentLogPageActions.checkInSavePostValidation();
//	}
//
//	@Test(priority = 10, dataProvider = "checkInData", groups = { "regression", "CICOModule" })
//	public void userCheckInFromAppointmentLogScreen(ArrayList<String> inputSheet) {
//		cICOAppointmentLogPageActions.clickCheckInAppointmentLogPageCheckIn("Check-In");
//		cICODetailsPageActions.clientLandedOnCheckInScreen("Check-In");
//		cICODetailsPageActions.checkInWithoutChoosingAnyOption();
//		cICODetailsPageActions.checkInWithoutChoosingOneOption();
//		cICODetailsPageActions.chooseCheckInRADetailsRadioOption(inputSheet.get(0));
//		cICODetailsPageActions.chooseCheckInRADetailsCheckboxOption(inputSheet.get(1));
//		cICODetailsPageActions.chooseCheckInRADetailsDocRadioOption(inputSheet.get(2));
//		cICODetailsPageActions.addCheckInRADetailsDocInfo(inputSheet.get(3), inputSheet.get(4));
//		cICOAppointmentLogPageActions.verifyPostCheckInFromAppointmentLogScreen("Check-In");
//	}
//
//	@DataProvider(name = "checkInData")
//	public static Object[][] checkInData() {
//		String inputSheet = "CheckIn_Input";
//		return ExcelUtil.getTableArray(Utility.ExcelBasePath + "/CICO_Data.xlsx", inputSheet);
//	}

////  @Test(priority = 11, groups = { "regression", "CICOModule" })
////	public void verifyCheckInUploadFile() {
////		cICOAppointmentLogPageActions.clickCheckInAppointmentLogPageCheckIn("Check-In");
////		cICODetailsPageActions.clientLandedOnCheckInScreen("Check-In");
////		cICODetailsPageActions.uploadCheckInDoc(); // Not working in IE
////	}


}
