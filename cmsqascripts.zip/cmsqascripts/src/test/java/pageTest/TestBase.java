package pageTest;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import pageObject.LogInPageActions;
import pageObject.LogOutPageActions;
import pageObject.MenuBarActions;
import pageObject.VendorSitePageActions;
import pageObject.CAModule.CAAssignCasePageActions;
import pageObject.CAModule.CAPageActions;
import pageObject.CAModule.CAReAssignCasePageActions;
import pageObject.CAModule.CACaseAssignmentsCommonActions;
import pageObject.CICOModule.CICOAppointmentLogPageActions;
import pageObject.CICOModule.CICOCancelCheckInPageActions;
import pageObject.CICOModule.CICOCheckoutPageActions;
import pageObject.CICOModule.CICOClientServicesScreenPageActions;
import pageObject.CICOModule.CICODetailsPageActions;
import pageObject.CICOModule.CICOReSchedulePageActions;
import pageObject.MAModule.FTCInitiationPageActions;
import pageObject.MAModule.MACaseOverviewPageActions;
import pageObject.MAModule.MACommonClinicalAssessPageActions;
import pageObject.MAModule.MADemoInfoPageActions;
import pageObject.MAModule.MADocReviewPageActions;
import pageObject.MAModule.MAEmergencyInfoPageActions;
import pageObject.MAModule.MAFFMSupportPageActions;
import pageObject.MAModule.MALanguageNeedPageActions;
import pageObject.MAModule.MAMedicalConditionPageActions;
import pageObject.MAModule.MAMentalHealthPageActions;
import pageObject.MAModule.MAPageActions;
import pageObject.MAModule.MAPageCommonActions;
import pageObject.MAModule.MAPurposeOfVisitPageActions;
import pageObject.MAModule.MAReasonAccommoPageActions;
import pageObject.MAModule.MAReleasePageActions;
import pageObject.MAModule.MAObservationAndClientPresentationPageActions;
import pageObject.MAModule.MAADLAndOtherActivitiesPageActions;
import pageObject.CAModule.CADeassignCasesPageActions;
import pageObject.CICOModule.CICOCheckInCheckOutCommonActions;
import pageObject.CICOModule.CICOCarFarePageActions;
import pageObject.CICOModule.CICOAppointmentsToSchedulePageActions;
import pageObject.CICOModule.CICOExitPackagePageActions;
import testUtil.Log;
import testUtil.Utility;

public class TestBase {

	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest test;

	// Static variables of action classes
	public static CICOAppointmentLogPageActions cICOAppointmentLogPageActions;
	public static LogInPageActions logInPageActions;
	public static MenuBarActions menuBarActions;
	public static VendorSitePageActions vendorSiteActions;
	public static CICODetailsPageActions cICODetailsPageActions;
	public static CICOReSchedulePageActions cICOReSchedulePageActions;
	public static LogOutPageActions logOutPageActions;
	public static CICOCancelCheckInPageActions CICOCancelCheckInPageActions;
	public static CICOCheckoutPageActions CICOCheckoutPageActions;
	public static CAAssignCasePageActions CAAssignCasePageActions;
	public static CAReAssignCasePageActions CAReAssignCasePageActions;
	public static CICOClientServicesScreenPageActions cICOClientServicesScreenPageActions;
	public static CACaseAssignmentsCommonActions CACaseAssignmentsCommonActions;
	public static CAPageActions cAPageActions;
	public static MAPageCommonActions MAPageCommonActions;
	public static CADeassignCasesPageActions CADeassignCasesPageActions;
	public static CICOCheckInCheckOutCommonActions CICOCheckInCheckOutCommonActions;
	public static CICOCarFarePageActions CICOCarFarePageActions;
	public static CICOAppointmentsToSchedulePageActions CICOAppointmentsToSchedulePageActions;
	public static CICOExitPackagePageActions CICOExitPackagePageActions;
	public static MAPageActions mAPageActions;
	public static MACommonClinicalAssessPageActions mAClinicalAssessPageActions;
	public static MAReasonAccommoPageActions mAReasonAccommoPageActions;
	public static MALanguageNeedPageActions mALanguageNeedPageActions;
	public static MADocReviewPageActions mADocReviewPageActions;
	public static MAReleasePageActions mAReleasePageActions;
	public static MADemoInfoPageActions mADemoInfoPageActions;
	public static MAEmergencyInfoPageActions mAEmergencyInfoPageActions;
	public static MAFFMSupportPageActions mAFFMSupportPageActions;
	public static MAPurposeOfVisitPageActions mAPurposeOfVisitPageActions;
	public static MAMedicalConditionPageActions mAMedicalConditionPageActions;
	public static MAMentalHealthPageActions mAMentalHealthPageActions;
	public static MACaseOverviewPageActions mACaseOverviewPageActions;
	public static FTCInitiationPageActions fTCInitiationPageActions;
	public static MAObservationAndClientPresentationPageActions mAObservationAndClientPresentationPageActions;
	public static MAADLAndOtherActivitiesPageActions mAADLAndOtherActivitiesPageActions;
	
	// Static object return methods of action classes
	public static MAADLAndOtherActivitiesPageActions mAADLAndOtherActivitiesPageActionsObject() {
		return mAADLAndOtherActivitiesPageActions = new MAADLAndOtherActivitiesPageActions();
	}
	public static MAObservationAndClientPresentationPageActions mAObservationAndClientPresentationPageActionsObject() {
		return mAObservationAndClientPresentationPageActions = new MAObservationAndClientPresentationPageActions();
	}
	public static FTCInitiationPageActions fTCInitiationPageActionsObject() {
		return fTCInitiationPageActions = new FTCInitiationPageActions();
	}
	public static MACaseOverviewPageActions mACaseOverviewPageActionsObject() {
		return mACaseOverviewPageActions = new MACaseOverviewPageActions();
	}
	public static MAMentalHealthPageActions mAMentalHealthPageActionsObject() {
		return mAMentalHealthPageActions = new MAMentalHealthPageActions();
	}
	public static MAMedicalConditionPageActions mAMedicalConditionPageActionsObject() {
		return mAMedicalConditionPageActions = new MAMedicalConditionPageActions();
	}
	public static MAPurposeOfVisitPageActions mAPurposeOfVisitPageActionsObject() {
		return mAPurposeOfVisitPageActions = new MAPurposeOfVisitPageActions();
	}
	public static MAFFMSupportPageActions MAFFMSupportPageActionsObject() {
		return mAFFMSupportPageActions = new MAFFMSupportPageActions();
	}
	public static MAEmergencyInfoPageActions mAEmergencyInfoPageActionsObject() {
		return mAEmergencyInfoPageActions = new MAEmergencyInfoPageActions();
	}
	public static MADemoInfoPageActions mADemoInfoPageActionsObject() {
		return mADemoInfoPageActions = new MADemoInfoPageActions();
	}
	public static MAReleasePageActions mAReleasePageActionsObject() {
		return mAReleasePageActions = new MAReleasePageActions();
	}
	public static MADocReviewPageActions mADocReviewPageActionsObject() {
		return mADocReviewPageActions = new MADocReviewPageActions();
	}
	public static MALanguageNeedPageActions mALanguageNeedPageActionsObject() {
		return mALanguageNeedPageActions = new MALanguageNeedPageActions();
	}
	public static MAReasonAccommoPageActions mAReasonAccommoPageActionsObject() {
		return mAReasonAccommoPageActions = new MAReasonAccommoPageActions();
	}
	public static MACommonClinicalAssessPageActions mAClinicalAssessPageActionsObject() {
		return mAClinicalAssessPageActions = new MACommonClinicalAssessPageActions();
	}	
	public static MAPageActions mAPageActionsObject() {
		return mAPageActions = new MAPageActions();
	}

	public static CICOExitPackagePageActions cICOExitPackagePageActionsObject() {
		return CICOExitPackagePageActions = new CICOExitPackagePageActions();
	}
	public static CICOAppointmentsToSchedulePageActions cICOAppointmentsToSchedulePageActionsObject() {
		return CICOAppointmentsToSchedulePageActions = new CICOAppointmentsToSchedulePageActions();
	}
	public static CICOCarFarePageActions cICOCarFarePageActionsObject() {
		return CICOCarFarePageActions = new CICOCarFarePageActions();
	}
	public static CICOCheckInCheckOutCommonActions cICOCheckInCheckOutCommonActionsObject(){
		return CICOCheckInCheckOutCommonActions = new CICOCheckInCheckOutCommonActions();
	}
	public static CADeassignCasesPageActions cADeassignAllCasesActionsObject(){
		return CADeassignCasesPageActions = new CADeassignCasesPageActions();
	}
	public static MAPageCommonActions mAPageCommonActionsObject() {
		return MAPageCommonActions = new MAPageCommonActions();
	} 
	public static CAPageActions cAPageActionsObject() {
		return cAPageActions = new CAPageActions();
	}
	public static CACaseAssignmentsCommonActions cACaseAssignmentsCommonActionsObject() {
		return CACaseAssignmentsCommonActions = new CACaseAssignmentsCommonActions();
	}
	
	public static CICOClientServicesScreenPageActions cICOClientServicesScreenPageActionsObject() {
		return cICOClientServicesScreenPageActions = new CICOClientServicesScreenPageActions();
	}

	public static CAReAssignCasePageActions cAReAssignCaseAndValidateActionsObject() {
		return CAReAssignCasePageActions = new CAReAssignCasePageActions();
	}

	public static CAAssignCasePageActions cAAssignCaseAndValidateActionsObject() {
		return CAAssignCasePageActions = new CAAssignCasePageActions();
	}

	public static CICOCheckoutPageActions cICOCheckoutWithCForATSActionsObject() {
		return CICOCheckoutPageActions = new CICOCheckoutPageActions();
	}

	public static CICOCancelCheckInPageActions cICOCancelCheckInPageActionsObject() {
		return CICOCancelCheckInPageActions = new CICOCancelCheckInPageActions();
	}

	public static LogOutPageActions logOutPageActionsObject() {
		return logOutPageActions = new LogOutPageActions();
	}

	public static CICOReSchedulePageActions cICOReSchedulePageActionsObject() {
		return cICOReSchedulePageActions = new CICOReSchedulePageActions();
	}

	public static CICODetailsPageActions cICODetailsPageActionsObject() {
		return cICODetailsPageActions = new CICODetailsPageActions();
	}

	public static CICOAppointmentLogPageActions cICOAppointmentLogPageActionsObject() {
		return cICOAppointmentLogPageActions = new CICOAppointmentLogPageActions();
	}

	public static VendorSitePageActions vendorSiteActionsObject() {
		return vendorSiteActions = new VendorSitePageActions();
	}

	public static MenuBarActions menuBarActionsObject() {
		return menuBarActions = new MenuBarActions();
	}

	public static LogInPageActions logInPageActionsObject() {
		return logInPageActions = new LogInPageActions();
	}
	
	@BeforeSuite(groups = "CICOModule") // alwaysRun = true
	@Parameters("browser") 
	public void setupDriver(String browser) {
//		TestBase.cleanDir(new File(System.getProperty("user.dir") + "/screenshot/*.png"));
		driver = TestBase.openBrowser(browser);
		String baseURL = Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL")+"/security";
		Log.info(browser + " Browser is Launched");

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get(baseURL);

		TestBase.menuBarActions = TestBase.menuBarActionsObject();
		TestBase.logOutPageActions = TestBase.logOutPageActionsObject();
	}
	
//	@AfterSuite(groups = "CAModule")
	@Parameters("browser")
	public void tearDownDriver(String browser) {
		if (driver != null) {
			driver.quit();
		}
		driver = null;
		Log.info(browser + " Driver is closed");
	}
	
	@BeforeTest(groups = "CICOModule")
	public void setupExtentReport() {
		TestBase.setupReport();
		logInPageActions = logInPageActionsObject();
	}
	
	@AfterTest(groups = "CAModule") // Change the Module name accordingly to populate the report
	public void tearDownExtentReport() {
		TestBase.tearDownReport();
	}
	
	@AfterMethod(groups = "CICOModule")
	public void afterMethod(ITestResult result) {
		String checkInURL = Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL") + "/checkin";

		if (!result.isSuccess()) {
			TestBase.getDriver().navigate().to(checkInURL);			
		}
	}

	public static void setupReport() {
		extent = new ExtentReports(
				System.getProperty("user.dir") + "/extentReport/WeCare-ES_Auto_Regression_Report.html", true);
		extent.addSystemInfo("Host Name", "WeCare-ES Project")
				.addSystemInfo("Environment", "QA Automation Regression Testing")
				.addSystemInfo("User Name", "Khaled / Karthika");
		extent.loadConfig(new File(System.getProperty("user.dir") + "/src/test/resources/extent-config.xml"));
	}

	public static void tearDownReport() {
		extent.flush();
		extent.close();
	}

	public static WebDriver openBrowser(String browserName) {

		if (browserName.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/browser/chromedriver_77.exe");

//			ChromeOptions options = new ChromeOptions();
			driver = new ChromeDriver();
			Log.info(browserName + " Driver is Initiated");
			
//			try {
//				driver = new RemoteWebDriver(new URL("http://127.0.0.1:4444/wd/hub"), options);
//			} catch (MalformedURLException e) {
//				e.printStackTrace();
//			}

		} else if (browserName.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/browser/geckodriver.exe");
			driver = new FirefoxDriver();
			Log.info(browserName + " Driver is Initiated");

		} else if (browserName.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/browser/IEDriverServer_32.exe");
			InternetExplorerOptions caps = new InternetExplorerOptions();
			caps.ignoreZoomSettings();
			caps.disableNativeEvents();
			caps.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, true);
			driver = new InternetExplorerDriver(caps);
			Log.info(browserName + " Driver is Initiated");
		}
		return driver;
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public static void cleanDir(File filePath) {
		try {
			FileUtils.cleanDirectory(filePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
