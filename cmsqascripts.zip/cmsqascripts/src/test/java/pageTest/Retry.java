package pageTest;


import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import com.relevantcodes.extentreports.LogStatus;


public class Retry implements IRetryAnalyzer{
	
	int counter = 0;
	int retryLimit = 0; //make it 1 to retry failed script
	
	public boolean retry(ITestResult result) {

		if (!result.isSuccess()) {
			if(counter < retryLimit) {
				counter++;
				return true;
			}		
			
		}else {
            result.setStatus(ITestResult.SUCCESS);
        }
		return false;
	}
	
	
}
