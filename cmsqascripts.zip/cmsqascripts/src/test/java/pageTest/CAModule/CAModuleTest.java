package pageTest.CAModule;

import java.util.ArrayList;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageTest.TestBase;
import testUtil.ExcelUtil;
import testUtil.Utility;


public class CAModuleTest extends TestBase {
	
//	@Test(priority = 0, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void assignUser(ArrayList<String> inputSheet) {
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();// CAPageAction object is created inside
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		//CACaseAssignmentsCommonActions.validateCaseLoadBeforeAssign(inputSheet.get(2)); // To Validate case Load
//		CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateCaseLoadAfterAssign(inputSheet.get(2)); // To Validate case Load
//		CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterAssign();
//		CACaseAssignmentsCommonActions.validateActionTabOnCaseAssignmentsPageAfterAssign();
//		CACaseAssignmentsCommonActions.validateLogViewForAssignedCase();
//	}
//	
//	@Test(priority = 1, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void assignUserAndOpenCase(ArrayList<String> inputSheet) {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		//CACaseAssignmentsCommonActions.validateCaseLoadBeforeAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateCaseLoadAfterAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterAssign();
//		MAPageCommonActions.getUserDetails();
//		MAPageCommonActions.openCaseInMyAssignments("baseURL", "/myassignments");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.getDetailsFromMA();
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterOpen();
//		CACaseAssignmentsCommonActions.validateActionTabOnCaseAssignmentsPageAfterOpen();
//		CACaseAssignmentsCommonActions.validateLogViewForInProgressCaseAfterOpen();
//	}
//	
//	@Test(priority = 2, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void deAssignspecificCase_InProgress(ArrayList<String> inputSheet) {
//
//		/* Assign Case */
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		//CACaseAssignmentsCommonActions.validateCaseLoadBeforeAssign(inputSheet.get(2)); // To Validate case Load
//		CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeAssign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateCaseLoadAfterAssign(inputSheet.get(2)); // To Validate case Load
//		CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterAssign(inputSheet.get(2));
//
//		/* Open Case */
//
//		MAPageCommonActions.getUserDetails();
//		MAPageCommonActions.openCaseInMyAssignments("baseURL", "/myassignments");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.getDetailsFromMA();
//
//		/* De-assign Case */
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		//CACaseAssignmentsCommonActions.validateCaseLoadBeforeDeassignSpecificCase(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeDeassignSpecificCase(inputSheet.get(2));
//		CADeassignCasesPageActions.getUserDetails();
//		CACaseAssignmentsCommonActions.selectActionsTabToDeassign();
//		CADeassignCasesPageActions.deassignSpecificCase();
//		//CACaseAssignmentsCommonActions.validateCaseLoadAfterDeassignSpecificCase(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterDeassignSpecificCase(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterDeassign();
//		CACaseAssignmentsCommonActions.validateActionTabOnCaseAssignmentsPageAfterDeassign();
//		CACaseAssignmentsCommonActions.validateLogViewForDeAssignedCase();
//	}
//
//	@Test(priority = 3, groups = { "regression", "CAModule" })
//	public void deAssignAllCases_Assigned() {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToAnyQHP();
//		CACaseAssignmentsCommonActions.validateCaseLoadBeforeDeassignAllCases();
//		// CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeDeassignAllCases();
//		CADeassignCasesPageActions.getUserDetails();
//		CADeassignCasesPageActions.deassignAllCases();
//		CACaseAssignmentsCommonActions.validateCaseLoadAfterDeassignAllCases();
//		// CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterDeassignAllCases();
//	}
//	
//	@Test(priority = 4,dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void deAssignspecificCase_Assigned(ArrayList<String> inputSheet) {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateCaseLoadBeforeDeassignSpecificCase(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeDeassignSpecificCase(inputSheet.get(2));
//		CADeassignCasesPageActions.getUserDetails();
//		CACaseAssignmentsCommonActions.selectActionsTabToDeassign();
//		CADeassignCasesPageActions.deassignSpecificCase();
//		//CACaseAssignmentsCommonActions.validateCaseLoadAfterDeassignSpecificCase(inputSheet.get(2));
//		//CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterDeassignSpecificCase(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterDeassign();
//		CACaseAssignmentsCommonActions.validateActionTabOnCaseAssignmentsPageAfterDeassign();
//		CACaseAssignmentsCommonActions.validateLogViewForDeAssignedCase();
//	}
//
//	@Test(priority = 5, groups = { "regression", "CAModule" }) //dataProvider = "loginData"
//	public void reAssignspecificCase_Assigned() {//ArrayList<String> inputSheet
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToAnyQHP();
//		//CACaseAssignmentsCommonActions.validateCaseLoadBeforeReassign();
//		//CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeReassign();
//		CAReAssignCasePageActions.getUserDetails();
//		CACaseAssignmentsCommonActions.selectActionsTabToReassign();
//		CAReAssignCasePageActions.reassignUser();
//		//CACaseAssignmentsCommonActions.validateCaseLoadAfterReassign();
//		//CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterReassign();
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterReassign();
//		CACaseAssignmentsCommonActions.validateActionTabOnCaseAssignmentsPageAfterReassign();
//		CACaseAssignmentsCommonActions.validateLogViewForReAssignedCase();
//	}
//	
//
//	@Test(priority = 6, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void deAssignAllCases_InProgress(ArrayList<String> inputSheet) {
//
//		/* Assign Case */
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//
//		/* Open Case */
//		MAPageCommonActions.getUserDetails();
//		MAPageCommonActions.openCaseInMyAssignments("baseURL", "/myassignments");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.getDetailsFromMA();
//
//		/* De-assign All */
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.validateCaseLoadBeforeDeassignAllCases();
//		// CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeDeassignAllCases();
//		CADeassignCasesPageActions.getUserDetails();
//		CADeassignCasesPageActions.deassignAllCases();
//		CACaseAssignmentsCommonActions.validateCaseLoadAfterDeassignAllCases();
//		// CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterDeassignAllCases();
//
//	}
//	
//	@Test(priority = 7, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void reassign_InProgress(ArrayList<String> inputSheet) {
//
//		/* Assign Case */
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
//
//		/* Open Case */
//		MAPageCommonActions.getUserDetails();
//		MAPageCommonActions.openCaseInMyAssignments("baseURL", "/myassignments");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.getDetailsFromMA();
//
//		/* Re-assign Case */
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		// CACaseAssignmentsCommonActions.validateAppointmentPerDayBeforeReassign();
//		CAReAssignCasePageActions.getUserDetails();
//		CACaseAssignmentsCommonActions.selectActionsTabToReassign();
//		CAReAssignCasePageActions.reassignUser();
//		// CACaseAssignmentsCommonActions.validateAppointmentPerDayAfterReassign();
//		CACaseAssignmentsCommonActions.validateCaseAssignmentsPageAfterReassign();
//		CACaseAssignmentsCommonActions.validateActionTabOnCaseAssignmentsPageAfterReassign();
//		CACaseAssignmentsCommonActions.validateLogViewForReAssignedCase();
//	}
//	
//	@Test(priority = 8, groups = { "regression", "CAModule" })
//	public void validate_AssignModal() {
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetailsfromCICO();
//		CAAssignCasePageActions.validate_AssignModal();
//		CAAssignCasePageActions.cancel_AssignModal();
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//	}
//
//	@Test(priority = 9, groups = { "regression", "CAModule" })
//	public void validate_ReassignModal() {
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CICOCheckInCheckOutCommonActions.checkInUser();
//		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
//		CACaseAssignmentsCommonActions.selectActionsTabToAssign_AnyQHP();
//		CAAssignCasePageActions.getUserDetails();
//		CAAssignCasePageActions.assignToAnyQHP();
//		CAReAssignCasePageActions.getUserDetails();
//		CACaseAssignmentsCommonActions.selectActionsTabToReassign();
//		CAReAssignCasePageActions.getUserDetails();
//		CAReAssignCasePageActions.validate_ReAssignModal();
//		CAReAssignCasePageActions.cancel_ReAssignModal();
//	}
//
////	@Test(priority = 10, groups = { "regression", "CAModule" })
////	public void verifyAllCasesChkBoxAndPendingCount() {
////		cAPageActions.verifyDateColAndPendingStatusCount("baseURL", "/assignments");
////		cAPageActions.verifyAllCasesOption();
////	}
////
////	//@Test(priority = 1, groups = { "regression", "CAModule" })
////	public void cAssignmentPageValidation() {
////		cAPageActions.verifyCurrentDateSelected();
////		cAPageActions.caLogScreenValidation();
////		cAPageActions.verifyAppOrCheckInDate();
////		cAPageActions.verifyInProgressStatusCount();
////	}
//
//	@Test(priority = 11, dataProvider = "loginData", groups = { "regression", "CAModule" })
//	public void multipleAssignments(ArrayList<String> inputSheet) {
//
//		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
//		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsPage("baseURL", "/assignments");
//		CADeassignCasesPageActions.deassignAllCases_ForParticularQHP(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.filterPendingCasesAndSelectCheckboxForBulkAssignment();
//		CAAssignCasePageActions.clickAssign();
//		CAAssignCasePageActions.assign(inputSheet.get(2));
//		CACaseAssignmentsCommonActions.validate_Timeline(inputSheet.get(2));
//
//	}
//
////	@Test(priority = 12, dataProvider = "loginData", groups = { "regression", "CAModule" })
////	public void ReassignFromTimeline(ArrayList<String> inputSheet) {
////		
////		CICOCheckInCheckOutCommonActions.closeModal();
////		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
////		CICOCheckInCheckOutCommonActions.checkInUser();
////		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
////		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
////		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
////		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
////		CAAssignCasePageActions.getUserDetails();
////		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
////		CACaseAssignmentsCommonActions.clickTimelineToReassign(inputSheet.get(2));
////		CAReAssignCasePageActions.getUserDetails();
////		CAReAssignCasePageActions.reassignUser();
////	}
////
////	@Test(priority = 13, dataProvider = "loginData", groups = { "regression", "CAModule" })
////	public void ReassignAgainFromTimeline(ArrayList<String> inputSheet) {
////
////		CICOCheckInCheckOutCommonActions.closeModal();
////		CICOCheckInCheckOutCommonActions.increasePageSize("baseURL", "/checkin");
////		CICOCheckInCheckOutCommonActions.checkInUser();
////		CACaseAssignmentsCommonActions.getDetailsFromCICOCheckIn();
////		CACaseAssignmentsCommonActions.navigateToCaseAssignmentsAndSelectAppointmentType("baseURL", "/assignments");
////		CACaseAssignmentsCommonActions.increasePageSize_CaseAssignments();
////		CACaseAssignmentsCommonActions.selectActionsTabToAssign(inputSheet.get(2));
////		CAAssignCasePageActions.getUserDetails();
////		CAAssignCasePageActions.assignToparticularQHP(inputSheet.get(2));
////		CAReAssignCasePageActions.getUserDetails();
////		CACaseAssignmentsCommonActions.selectActionsTabToReassign();
////		CAReAssignCasePageActions.reassignUser();
////		CACaseAssignmentsCommonActions.clickTimelineToReassign(inputSheet.get(2));
////		CAReAssignCasePageActions.getUserDetails();
////		CAReAssignCasePageActions.reassignUserFromTimeline();		
////	}
////
//	@Test(priority = 14,  groups = { "regression", "CAModule" })
//	public void logoutUserFromApp() {
//		// Need to logout for IE11; Use it as the last method of the last @Test
//		cICOAppointmentLogPageActions.logoutFromApp();
//	}
//
//	@DataProvider(name = "loginData")
//	public Object[][] loginDp() {
//		String inputSheet = "Login_Input";
//		return ExcelUtil.getTableArray(Utility.ExcelBasePath + "/CICO_Data.xlsx", inputSheet);
//	}
}
