package pageObject;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.LogInPageLocators;
import testUtil.CommonUtil;
import testUtil.Log;
import pageTest.TestBase;


public class LogInPageActions {

	
	LogInPageLocators logInPageLocators = null;

	public LogInPageActions() {
		this.logInPageLocators = new LogInPageLocators();
		PageFactory.initElements(TestBase.getDriver(), logInPageLocators);
	}

	public void loginUserToTheApp(String userName, String passWord) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), logInPageLocators.loginBtn);

		Assert.assertTrue(logInPageLocators.loginBtn.isDisplayed(), "'Login' page is not available");
		TestBase.test.log(LogStatus.INFO, "Client has landed on 'Login' page");
		Log.info("Client has landed on 'Login' page");

		CommonUtil.inputKeysToEle(logInPageLocators.userName, userName);
		CommonUtil.inputKeysToEle(logInPageLocators.passWord, passWord);
		CommonUtil.submitEle(logInPageLocators.loginBtn);
		
		TestBase.vendorSiteActions = TestBase.vendorSiteActionsObject();
	}

}
