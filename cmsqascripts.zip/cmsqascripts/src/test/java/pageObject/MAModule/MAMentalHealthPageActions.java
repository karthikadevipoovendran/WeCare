package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAMentalHealthPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAMentalHealthPageActions {

	MAMentalHealthPageLocators mAMentalHealthPageLocators = null;
	
	public MAMentalHealthPageActions() {
		mAMentalHealthPageLocators = new MAMentalHealthPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAMentalHealthPageLocators);
	}
	
	
	public void provideMentalHealthConditionInfo(String symptoms, String clinicInfo, 
			String condition, String impact, String stable, String current, 
			String duration, String abilityWorkExp, String treated, String addr,
			String treatingClinic, String city, String zip, String speciality, 
			String specOther, String state, String lengthOfTreat, 
			String compWithAppointment, String compReason, String medication, 
			String medicEntry, String compTakMedic, String compTakMedicExp, 
			String hospitalHistory, String hospHistExp, 
			String nervous, String depressed, String hopeless, String hearingVoices,
			String hearVoicesExp, String priorSuicide, String currentSuicide, 
			String priorHarming, String currentHarming, String thoughtAttemExp) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAMentalHealthPageLocators.addBtn.get(0));
		CommonUtil.sleep(2000);

		if(symptoms.equalsIgnoreCase("No")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.chkBox.get(0));
		}
		else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.addBtn.get(0));
			CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.condition, condition);
			
			for(int opt=0; opt<mAMentalHealthPageLocators.impactsAbility.size(); opt++) {
				String impactVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.impactsAbilityLabel.get(opt));
				String stableVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.stableLabel.get(opt));
				String currentVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.currentLabel.get(opt));
				String durationVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.durationLabel.get(opt));
				String treatedVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.treatedLabel.get(opt));
				
				if(impactVal.contains(impact)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.impactsAbility.get(opt));				
				}
				if(stableVal.contains(stable)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.stable.get(opt));				
				}
				if(currentVal.contains(current)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.current.get(opt));				
				}
				if(treatedVal.contains(treated)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.treated.get(opt));				
				}
				if(durationVal.contains(duration)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.duration.get(opt));				
				}
			}
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.medicCondiSaveBtn.get(1));//Change 1 to 0

			if(impact.equalsIgnoreCase("Yes")) {
				CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.impactAbilToWorkExp, abilityWorkExp);				
			}
		}
		
		if(clinicInfo.equalsIgnoreCase("No")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.chkBox.get(1));
		}
		else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.addBtn.get(0));
			CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.treatingClinic, treatingClinic);
			CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.addr, addr);
			CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.city, city);
			CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.zip, zip);
			CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.lengthOfTreat, lengthOfTreat);
			CommonUtil.selectEleFromDropDown(mAMentalHealthPageLocators.mhSelect.get(0)).selectByVisibleText(speciality);

			if(speciality.equalsIgnoreCase("Other")) {
				CommonUtil.selectEleFromDropDown(mAMentalHealthPageLocators.mhSelect.get(0)).selectByVisibleText("Other (Specify)");
				CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.specOther, specOther);
			}
			CommonUtil.selectEleFromDropDown(mAMentalHealthPageLocators.mhSelect.get(1)).selectByVisibleText(state);
			
			for(int comp=0; comp<mAMentalHealthPageLocators.compliance.size(); comp++) {
				String compVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.complianceLabel.get(comp));
		
				if(compVal.contains(compWithAppointment)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.compliance.get(comp));

					if(compWithAppointment.equalsIgnoreCase("No")) {
						CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.nonCompliReason, compReason);
					}
					break;
				}
				else {
					continue;
				}
			}
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.medicCondiSaveBtn.get(1));//Change 1 to 0
		}
		
		for(int opt=0; opt<mAMentalHealthPageLocators.nervous.size(); opt++) {
			String nervousVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.nervousLabel.get(opt));
			String depressedVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.depressedLabel.get(opt));
			String hopelessVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.hopelessLabel.get(opt));
			String hearingVoicesVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.hearingVoicesLabel.get(opt));
			String priorSuicVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.priorSuicThoughtsLabel.get(opt));
			String currSuicVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.currSuicThoughtsLabel.get(opt));
			String priorHarmVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.priorHarmAttemLabel.get(opt));
			String currHarmVal = CommonUtil.getTextOfEle(mAMentalHealthPageLocators.currHarmAttemLabel.get(opt));
			
			if(nervousVal.contains(nervous)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.nervous.get(opt));				
			}
			if(depressedVal.contains(depressed)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.depressed.get(opt));				
			}
			if(hopelessVal.contains(hopeless)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.hopeless.get(opt));				
			}
			if(hearingVoicesVal.contains(hearingVoices)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.hearingVoices.get(opt));				
			}
			if(nervous.equals("Yes") || depressed.equals("Yes") || hopeless.equals("Yes") || hearingVoices.equals("Yes")) {
				CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.hearVoiceExp, hearVoicesExp);
			}
			
			if(priorSuicVal.contains(priorSuicide)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.priorSuicThoughts.get(opt));				
			}
			if(currSuicVal.contains(currentSuicide)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.currSuicThoughts.get(opt));				
			}
			if(priorHarmVal.contains(priorHarming)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.priorHarmAttem.get(opt));				
			}
			if(currHarmVal.contains(currentHarming)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.currHarmAttem.get(opt));				
			}
			if(priorSuicide.equals("Yes") || currentSuicide.equals("Yes") || priorHarming.equals("Yes") || currentHarming.equals("Yes")) {
				CommonUtil.inputKeysToEle(mAMentalHealthPageLocators.thoughAttemExp, thoughtAttemExp);
			}
		}
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMentalHealthPageLocators.navBtn.get(1));

		TestBase.test.log(LogStatus.INFO, "User has provided mental health info");
		Log.info("User has provided mental health info");

	}
	
	
}
