package pageObject.MAModule;

import java.util.Date;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAPageLocators;
import pageModel.MAModule.MAReasonAccommoPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;


public class MAReasonAccommoPageActions {

	MAReasonAccommoPageLocators mAReasonAccommoPageLocators = null;
	MAPageLocators mAPageLocators = null;
	
	public MAReasonAccommoPageActions() {
		mAReasonAccommoPageLocators = new MAReasonAccommoPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAReasonAccommoPageLocators);
		
		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
	}
	
	public void provideReasonableAccomodationInfo(String pageName) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAReasonAccommoPageLocators.header);
		CommonUtil.sleep(2000);
		
		TestBase.test.log(LogStatus.INFO, "User has landed on '"+pageName+"' screen");
		Log.info("User has landed on '"+pageName+"' screen");
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(1));
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReasonAccommoPageLocators.navBtn.get(1));
		
		TestBase.mALanguageNeedPageActions = TestBase.mALanguageNeedPageActionsObject();
	}
	
	
}
