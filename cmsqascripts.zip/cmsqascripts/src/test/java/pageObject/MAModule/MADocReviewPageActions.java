package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MADocReviewPageLocators;
import pageModel.MAModule.MAPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MADocReviewPageActions {
	
	MADocReviewPageLocators mADocReviewPageLocators = null;
	MAPageLocators mAPageLocators = null;
	
	public MADocReviewPageActions(){
		mADocReviewPageLocators = new MADocReviewPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mADocReviewPageLocators);
		
		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
	}
	

	public void provideDocReviewInfo(String pageName, String comments) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mADocReviewPageLocators.docHeader.get(0));
		CommonUtil.sleep(2000);
		
		TestBase.test.log(LogStatus.INFO, "User has landed on '"+pageName+"' screen");
		Log.info("User has landed on '"+pageName+"' screen");
		
		CommonUtil.inputKeysToEle(mADocReviewPageLocators.docRevTxtArea, comments);	
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(1));
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mADocReviewPageLocators.navBtn.get(1));
		
		TestBase.test.log(LogStatus.INFO, "User has provided documentation review info");
		Log.info("User has provided documentation review info");
		
		TestBase.mAReleasePageActions = TestBase.mAReleasePageActionsObject();
	}
	
}
