package pageObject.MAModule;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAReleasePageLocators;
import pageModel.MAModule.MAPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAReleasePageActions {

	MAReleasePageLocators mAReleasePageLocators = null;
	MAPageLocators mAPageLocators = null;

	public MAReleasePageActions() {
		mAReleasePageLocators = new MAReleasePageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAReleasePageLocators);

		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
	}

	public void clickOnReleaseTab() {

		CommonUtil.sleep(2000);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.tabs_ClientInfo.get(2));
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAReleasePageLocators.text_Releases);
		TestBase.test.log(LogStatus.INFO, "User has navigated to Releases Tab");
		Log.info("User has navigated to Releases Tab");
	}

	public void navigateToNextTab() {

		CommonUtil.sleep(1000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.navBtn.get(1));

		TestBase.test.log(LogStatus.INFO, "User has already provided releases info");
		Log.info("User has already provided releases info");

		TestBase.mADemoInfoPageActions = TestBase.mADemoInfoPageActionsObject();
	}

	public void navigateBackToRATab() {

		CommonUtil.sleep(2000);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.tabs_ClientInfo.get(0));
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAReleasePageLocators.text_RA);
		TestBase.test.log(LogStatus.INFO, "User has navigated to Reasonable Accommodations Tab");
		Log.info("User has navigated to Reasonable Accommodations Tab");

		CommonUtil.sleep(2000);
	}

	public void provideReleaseInfo(String pageName, String treatmentProvider, String speciality, String addr,
			String city, String state, String zip, String contactNum, String faxNum, String HIPAAConsent,
			String comments) {

		CommonUtil.waitDriverUntilElementIsClickable(TestBase.getDriver(), mAReleasePageLocators.releaseHeader);
		CommonUtil.sleep(2000);

		TestBase.test.log(LogStatus.INFO, "User has landed on '" + pageName + "' screen");
		Log.info("User has landed on '" + pageName + "' screen");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.medDocProviderRadioBtn.get(0));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.provideInfoAddBtn);
		CommonUtil.inputKeysToEle(mAReleasePageLocators.treatmentProvider, treatmentProvider);
		CommonUtil.selectEleFromDropDown(mAReleasePageLocators.provDetDrpDwn.get(0)).selectByVisibleText(speciality);

		CommonUtil.inputKeysToEle(mAReleasePageLocators.addr, addr);
		CommonUtil.inputKeysToEle(mAReleasePageLocators.city, city);
		CommonUtil.selectEleFromDropDown(mAReleasePageLocators.provDetDrpDwn.get(1)).selectByVisibleText(state);

		CommonUtil.inputKeysToEle(mAReleasePageLocators.zip, zip);
		CommonUtil.inputKeysToEle(mAReleasePageLocators.contactNum, contactNum);
		CommonUtil.inputKeysToEle(mAReleasePageLocators.faxNum, faxNum);
		// CommonUtil.clickEleJsExec(TestBase.getDriver(),
		// mAReleasePageLocators.newTreatProviderBtn.get(1));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.button_TP_Save);

		/* Consent Sign */
		try {
		if (CommonUtil.isElementPresent(TestBase.getDriver(), mAReleasePageLocators.bytext_Yes)) {
			TestBase.test.log(LogStatus.INFO, "Consent is already signed");
			Log.info("Consent is already signed");
		} else {
			// code for HIPAA
			if (HIPAAConsent.equalsIgnoreCase("Yes")) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.hIPAAConsent.get(0));
				// CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				// mAReleasePageLocators.signOptionBtn.get(0));
				// CommonUtil.clickEleJsExec(TestBase.getDriver(),
				// mAReleasePageLocators.signOptionBtn.get(0));
				// CommonUtil.clickEleJsExec(TestBase.getDriver(),
				// mAReleasePageLocators.verifyBtn);

				try {
					CommonUtil.inputKeysToEle(mAReleasePageLocators.signTxtField, "test");
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.signBtn);
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.signConsentBtn.get(0));
				} catch (NoSuchElementException e) {
					Log.info("Sign-in text Field is not available");
				}

				CommonUtil.sleep(2000);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.button_Handwritten);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.signSubmitBtn.get(0));
			} else if (HIPAAConsent.equalsIgnoreCase("No")) {
				// create object of FTC class
				TestBase.fTCInitiationPageActions = TestBase.fTCInitiationPageActionsObject();

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.hIPAAConsent.get(1));
				TestBase.fTCInitiationPageActions.initiateFTC();
			}
		}
		
		}
		catch(NoSuchElementException e) {
			Log.info(e.getMessage());
		}

		CommonUtil.sleep(2000);
		/* Consent Sign for Treatment Provider */

			// code for HIPAA
			if (HIPAAConsent.equalsIgnoreCase("Yes")) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.hIPAAConsent.get(0));
				// CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				// mAReleasePageLocators.signOptionBtn.get(0));
				// CommonUtil.clickEleJsExec(TestBase.getDriver(),
				// mAReleasePageLocators.signOptionBtn.get(0));
				// CommonUtil.clickEleJsExec(TestBase.getDriver(),
				// mAReleasePageLocators.verifyBtn);

				try {
					CommonUtil.inputKeysToEle(mAReleasePageLocators.signTxtField, "test");
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.signBtn);
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.signConsentBtn.get(0));
				} catch (NoSuchElementException e) {
					Log.info("Sign-in text Field is not available");
				}

				CommonUtil.sleep(2000);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.button_Handwritten);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.signSubmitBtn.get(0));
			} else if (HIPAAConsent.equalsIgnoreCase("No")) {
				// create object of FTC class
				TestBase.fTCInitiationPageActions = TestBase.fTCInitiationPageActionsObject();

				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAReleasePageLocators.hIPAAConsent.get(1));
				TestBase.fTCInitiationPageActions.initiateFTC();
			}
		

		CommonUtil.inputKeysToEle(mAReleasePageLocators.docComments, comments);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(1));
		TestBase.test.log(LogStatus.INFO, "Save button is clicked");
		Log.info("Save button is clicked");
		// CommonUtil.clickEleJsExec(TestBase.getDriver(),
		// mAReleasePageLocators.navBtn.get(1));

		TestBase.test.log(LogStatus.INFO, "User has provided releases info");
		Log.info("User has provided releases info");

		// TestBase.mADemoInfoPageActions = TestBase.mADemoInfoPageActionsObject();
	}

}
