package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAPurposeOfVisitPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAPurposeOfVisitPageActions {

	MAPurposeOfVisitPageLocators mAPurposeOfVisitPageLocators = null;
	
	
	public MAPurposeOfVisitPageActions() {
		mAPurposeOfVisitPageLocators = new MAPurposeOfVisitPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPurposeOfVisitPageLocators);
	}
	
	public void providePurposeOfVisitInfo(String purpose) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAPurposeOfVisitPageLocators.povHeader);
		CommonUtil.sleep(2000);
		
		CommonUtil.inputKeysToEle(mAPurposeOfVisitPageLocators.povReason, purpose);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPurposeOfVisitPageLocators.navBtn.get(1));
		
		TestBase.test.log(LogStatus.INFO, "User has provided purpose of visit info");
		Log.info("User has provided purpose of visit info");
		
		TestBase.mAMedicalConditionPageActions = TestBase.mAMedicalConditionPageActionsObject();
	}
	
	
	
}
