package pageObject.MAModule;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAPageCommonLocators;
import pageObject.CAModule.CAAssignCasePageActions;
import pageObject.CAModule.CACaseAssignmentsCommonActions;
import pageObject.CICOModule.CICOCheckInCheckOutCommonActions;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;

public class MAPageCommonActions {

	public static MAPageCommonLocators mAPageCommonLocators = null;
	public static String MAC_nameToValidate = null;
	public static String MAC_caseNumberToValidate = null;
	public static String MAC_appointmentType = null;
	public static String MAC_CheckInDate = null;
	public static String MAC_CMSUser = null;
	public static String MAC_caseWorkerAssigned = null;
	public static String MAC_StatusBeforeOpen = null;

	CAAssignCasePageActions CA_AssignCase = new CAAssignCasePageActions();
	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public MAPageCommonActions() {

		MAPageCommonActions.mAPageCommonLocators = new MAPageCommonLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageCommonLocators);

	}

	public void getUserDetails() {

		MAC_nameToValidate = CAAssignCasePageActions.AC_nameToValidate;
		MAC_caseNumberToValidate = CAAssignCasePageActions.AC_caseNumberToValidate;
		MAC_appointmentType = CAAssignCasePageActions.AC_appointmentType;
		MAC_CheckInDate = CAAssignCasePageActions.AC_CheckInDate;
		MAC_CMSUser = CAAssignCasePageActions.AC_CMSUser;
		MAC_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;
		MAC_StatusBeforeOpen = CACaseAssignmentsCommonActions.common_StatusAfterAssign;
	}

	public void getUserDetailsfromCICO() {

		MAC_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		MAC_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		MAC_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
		MAC_CheckInDate = CICOCheckInCheckOutCommonActions.common_CheckInDate;
		MAC_CMSUser = CICOCheckInCheckOutCommonActions.common_CMSUser;
		MAC_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;
		MAC_StatusBeforeOpen = CACaseAssignmentsCommonActions.common_StatusAfterAssign;
	}
	
	public void NavigateToMyAssignments(String configFileURL, String endPoint) {
		
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);	
		TestBase.test.log(LogStatus.INFO, "Navigated successfully to My Assignments");
		Log.info("Navigated successfully to My Assignments");
		
		CommonUtil.sleep(2000);
	}

	public void openCaseInMyAssignments(String configFileURL, String endPoint) {

		CommonUtil.sleep(2000);

		if (MAC_nameToValidate == null || CACaseAssignmentsCommonActions.common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "Cannot proceed with opening a case in My assignments");
			Log.info("Cannot proceed with opening a case in My assignments");
		} else {
			//CommonUtil.navigateTo(TestBase.driver, "http://dev.ewweb.prutechlab.com/cms/#/myassignments");
			CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);
			TestBase.test.log(LogStatus.INFO, "User has navigated to My Assignments Page");
			Log.info("User has navigated to My Assignments Page");

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					mAPageCommonLocators.myAssignments_headername);
			TestBase.test.log(LogStatus.INFO, "Header is displayed");
			Log.info("Header is displayed");

			CommonUtil.sleep(2000);

			for (int client = 1; client < mAPageCommonLocators.clientName_MyAssignments.size(); client++) {

				if (mAPageCommonLocators.clientName_MyAssignments.get(client).getText().contains(MAC_nameToValidate)) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							mAPageCommonLocators.clientName_MyAssignments.get(client));
					TestBase.test.log(LogStatus.INFO, "Client is selected in My Assignments Page");
					Log.info("Client is selected in My Assignments Page");

					CommonUtil.sleep(2000);

					CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
							mAPageCommonLocators.list_actionicons.get(client - 1));

					if (mAPageCommonLocators.list_actionicons.get(client - 1).isDisplayed()) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								mAPageCommonLocators.list_actionicons.get(client - 1));
						TestBase.test.log(LogStatus.INFO, "Action button is clicked");
						Log.info("Action button is clicked");

						CommonUtil.sleep(3000);

						CommonUtil.waitDriverUntilElementIsClickable(TestBase.getDriver(),
								mAPageCommonLocators.myAssignments_Open);

						CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageCommonLocators.myAssignments_Open);
						
						CommonUtil.sleep(2000);

						try {
							CommonUtil.clickEleJsExec(TestBase.getDriver(),
									mAPageCommonLocators.myAssignments_Confirm.get(0));
						} catch (IndexOutOfBoundsException e) {
							TestBase.test.log(LogStatus.INFO, "Confirm button not available");
							Log.info("Confirm button not available");
						}

						CommonUtil.sleep(2000);
						
						if(MAC_appointmentType.contains("Clinical")||MAC_appointmentType.contains("Medical")||MAC_appointmentType.contains("Psychiatric")) {
							
							CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
									mAPageCommonLocators.myAssignments_ClientAssessment);

							Assert.assertTrue(mAPageCommonLocators.myAssignments_ClientAssessment.isDisplayed());
							TestBase.test.log(LogStatus.INFO, "Case is opened");
							Log.info("Case is opened");
							
						}else if(MAC_appointmentType.contains("Wellness")){
							
							CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
									mAPageCommonLocators.myAssignments_CaseOverview);

							Assert.assertTrue(mAPageCommonLocators.myAssignments_CaseOverview.isDisplayed());
							TestBase.test.log(LogStatus.INFO, "Case is opened");
							Log.info("Case is opened");
							
						}
				

						break;

					}

				}
			}

		}

		TestBase.mAClinicalAssessPageActions = TestBase.mAClinicalAssessPageActionsObject();
		TestBase.mACaseOverviewPageActions = TestBase.mACaseOverviewPageActionsObject();
		TestBase.mAReleasePageActions = TestBase.mAReleasePageActionsObject();
		TestBase.mAPageActions = TestBase.mAPageActionsObject();
	}

}
