package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Test;

import pageModel.MAModule.MAMedicalConditonPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAMedicalConditionPageActions {
	
	MAMedicalConditonPageLocators mAMedicalConditonPageLocators = null;
	
	public MAMedicalConditionPageActions() {
		mAMedicalConditonPageLocators = new MAMedicalConditonPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAMedicalConditonPageLocators);
	}
	
	
	public void provideMedicalConditionInfo(String symptoms, String clinicInfo,
			String condition, String impact, String stable, String current, 
			String duration, String abilityWorkExp, String treated, String addr, 
			String treatingClinic, String city, String zip, String speciality, 
			String specOther, String state, String lengthOfTreat, 
			String compWithAppointment, String compReason, String medication, 
			String medicEntry, String compTakMedic, String compTakMedicExp,
			String hospitalHistory, String hospHistExp, 
			String hivStat, String hivMedic,
			String aids, String hivExp) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAMedicalConditonPageLocators.addBtn.get(0));
		CommonUtil.sleep(2000);
		
		if(symptoms.equalsIgnoreCase("No")) {
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.chkBox.get(0));
		}
		else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.addBtn.get(0));
			CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.condition, condition);
			
			for(int opt=0; opt<mAMedicalConditonPageLocators.impactsAbility.size(); opt++) {
				String impactVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.impactsAbilityLabel.get(opt));
				String stableVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.stableLabel.get(opt));
				String currentVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.currentLabel.get(opt));
				String durationVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.durationLabel.get(opt));
				String treatedVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.treatedLabel.get(opt));
				
				if(impactVal.contains(impact)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.impactsAbility.get(opt));				
				}
				if(stableVal.contains(stable)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.stable.get(opt));				
				}
				if(currentVal.contains(current)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.current.get(opt));				
				}
				if(treatedVal.contains(treated)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.treated.get(opt));				
				}
				if(durationVal.contains(duration)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.duration.get(opt));				
				}
			}
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.medicCondiSaveBtn.get(1));//Change 1 to 0
			
			if(impact.equalsIgnoreCase("Yes")) {
				CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.impactAbilToWorkExp, abilityWorkExp);				
			}
		}
		
		if(clinicInfo.equalsIgnoreCase("No")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.chkBox.get(1));
		}
		else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.addBtn.get(1));
			CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.treatingClinic, treatingClinic);
			CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.addr, addr);
			CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.city, city);
			CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.zip, zip);
			CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.lengthOfTreat, lengthOfTreat);
			CommonUtil.selectEleFromDropDown(mAMedicalConditonPageLocators.mhSelect.get(0)).selectByVisibleText(speciality);

			if(speciality.equalsIgnoreCase("Other")) {
				CommonUtil.selectEleFromDropDown(mAMedicalConditonPageLocators.mhSelect.get(0)).selectByVisibleText("Other (Specify)");
				CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.specOther, specOther);
			}
			CommonUtil.selectEleFromDropDown(mAMedicalConditonPageLocators.mhSelect.get(1)).selectByVisibleText(state);
			
			for(int comp=0; comp<mAMedicalConditonPageLocators.compliance.size(); comp++) {
				String compVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.complianceLabel.get(comp));
		
				if(compVal.contains(compWithAppointment)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.compliance.get(comp));

					if(compWithAppointment.equalsIgnoreCase("No")) {
						CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.nonCompliReason, compReason);
					}
					break;
				}
				else {
					continue;
				}
			}
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.medicCondiSaveBtn.get(1));//Change 1 to 0
		}
		
		for(int opt=0; opt<mAMedicalConditonPageLocators.medication.size(); opt++) {
			String medicVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.medicationLabel.get(opt));
			String histHospVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.historyOfHospitalLabel.get(opt));
			String hivMedicVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.hivMedicTreatLabel.get(opt));
			
			if(medicVal.contains(medication)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.medication.get(opt));
				
				if(medication.equalsIgnoreCase("Yes")) {
					CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.medicEntry, medicEntry);
					String compInTakMedicVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.compInMedicLabel.get(opt));
					
					if(compInTakMedicVal.contains(compTakMedic)) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.compInTakMedic.get(opt));

						if(compTakMedic.equalsIgnoreCase("No")) {
							CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.compInMedicReason, compTakMedicExp);
						}
					}
				}
			}
			if(histHospVal.contains(hospitalHistory)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.historyOfHospital.get(opt));

				if(hospitalHistory.equalsIgnoreCase("Yes")) {
					CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.historyHospiComment, hospHistExp);
				}
			}

			CommonUtil.selectEleFromDropDown(mAMedicalConditonPageLocators.mhSelect.get(0)).selectByVisibleText(hivStat);

			if(hivStat.equalsIgnoreCase("Positive")) {
		
				if(hivMedicVal.contains(hivMedic)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.hivMedicTreat.get(opt));

					if(hivMedic.equalsIgnoreCase("Yes")) {
						CommonUtil.inputKeysToEle(mAMedicalConditonPageLocators.hivReason, hivExp);
						String aidsVal = CommonUtil.getTextOfEle(mAMedicalConditonPageLocators.aidsLabel.get(opt));
						
						if(aidsVal.contains(aids)) {
							CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.aids.get(opt));
						}
					}
				}
			}
		}
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.datePicker);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.activeDate);
	
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAMedicalConditonPageLocators.navBtn.get(1));
		
		TestBase.test.log(LogStatus.INFO, "User has provided medical condition info");
		Log.info("User has provided medical condition info");
		
		TestBase.mAMentalHealthPageActions = TestBase.mAMentalHealthPageActionsObject();
	}
	
	

}
