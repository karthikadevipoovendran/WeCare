package pageObject.MAModule;

import org.apache.poi.poifs.crypt.dsig.services.TSPTimeStampService;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MACommonClinicalAssessPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MACommonClinicalAssessPageActions {
	
	MACommonClinicalAssessPageLocators mAClinicalAssessPageLocators = null;
	
	public MACommonClinicalAssessPageActions() {
		mAClinicalAssessPageLocators = new MACommonClinicalAssessPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAClinicalAssessPageLocators);
	}
	
	public void clickClientInfoSideMenu() {
				
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAClinicalAssessPageLocators.sideMenuSubBar.get(0));
		TestBase.test.log(LogStatus.INFO, "User has clicked on Client Information Side Tab");
		Log.info("User has clicked on Client Information Side Tab");
		
		TestBase.mAReasonAccommoPageActions = TestBase.mAReasonAccommoPageActionsObject();
	}
	
	public void clickADLLimitationsSideMenu() {
		
		CommonUtil.sleep(3000);
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAClinicalAssessPageLocators.sideMenuSubBar.get(2));
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAClinicalAssessPageLocators.sideMenuSubBar.get(2));
		TestBase.test.log(LogStatus.INFO, "User has clicked on ADLs/Limitations tab");
		Log.info("User has clicked on ADLs/Limitations tab");
		
		TestBase.mAObservationAndClientPresentationPageActions = TestBase.mAObservationAndClientPresentationPageActionsObject();
	}
	
	public void navigateToNextPage() {
		
		CommonUtil.sleep(2000);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAClinicalAssessPageLocators.buttons_PrevAndNext.get(1));
		TestBase.test.log(LogStatus.INFO, "Next button is clicked");
		Log.info("Next button is clicked");	
	}
	
	public void navigateToPreviousPage() {
		
		CommonUtil.sleep(2000);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAClinicalAssessPageLocators.buttons_PrevAndNext.get(0));
		TestBase.test.log(LogStatus.INFO, "Previous button is clicked");
		Log.info("Previous button is clicked");	
	}
	
	
}
