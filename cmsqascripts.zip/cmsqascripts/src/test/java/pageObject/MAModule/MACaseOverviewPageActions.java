package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MACaseOverviewPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;


public class MACaseOverviewPageActions {
	
	MACaseOverviewPageLocators mACaseOverviewPageLocators = null;
	
	public MACaseOverviewPageActions() {
		mACaseOverviewPageLocators = new MACaseOverviewPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mACaseOverviewPageLocators);
	}

	public void verifyUserLandedOnCaseOverviewPage(String header) {
		try {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mACaseOverviewPageLocators.coHeader.get(0));
			CommonUtil.sleep(2000);
			
			CommonUtil.verifyPageHeader(header, mACaseOverviewPageLocators.coHeader.get(0));			
		} 
		catch(IndexOutOfBoundsException e) {
			Log.info(e.getMessage());
		}
	}
	
	
}
