package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAEmergencyInfoPageLocators;
import pageModel.MAModule.MAPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAEmergencyInfoPageActions {

	MAEmergencyInfoPageLocators mAEmergencyInfoPageLocators = null;
	MAPageLocators mAPageLocators = null; 
	
	
	public MAEmergencyInfoPageActions() {
		mAEmergencyInfoPageLocators = new MAEmergencyInfoPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAEmergencyInfoPageLocators);
		
		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
	}
	
	public void provideEmergencyInfo(String pageName, String lName, String fName, String addr, 
			String city, String tele, String state, String zip, String cell, 
			String email, String relationship) {
		
		//CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAEmergencyInfoPageLocators.addBtn);
		CommonUtil.sleep(2000);
		
		TestBase.test.log(LogStatus.INFO, "User has landed on '"+pageName+"' screen");
		Log.info("User has landed on '"+pageName+"' screen");
		
		CommonUtil.sleep(2000);
		//CommonUtil.clickEleJsExec(TestBase.getDriver(), mAEmergencyInfoPageLocators.addBtn);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.lName, lName);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.fName, fName);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.addr, addr);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.city, city);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.tele, tele);
		CommonUtil.selectEleFromDropDown(mAEmergencyInfoPageLocators.emerDrpDwn.get(0)).selectByVisibleText(state);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.zip, zip);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.cell, cell);
		CommonUtil.inputKeysToEle(mAEmergencyInfoPageLocators.email, email);
		CommonUtil.selectEleFromDropDown(mAEmergencyInfoPageLocators.emerDrpDwn.get(1)).selectByVisibleText(relationship);
		CommonUtil.clickEleJsExec(TestBase.driver, mAEmergencyInfoPageLocators.emerInfoBtn.get(0)); //change it to 0

		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(1));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAEmergencyInfoPageLocators.navBtn.get(1));
		
		TestBase.test.log(LogStatus.INFO, "User has provided emergency info");
		Log.info("User has provided emergency info");
		
		TestBase.mAFFMSupportPageActions = TestBase.MAFFMSupportPageActionsObject();
	}
}
