package pageObject.MAModule;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MALanguageNeedPageLocators;
import pageModel.MAModule.MAPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MALanguageNeedPageActions {

	MALanguageNeedPageLocators mALanguageNeedPageLocators = null;
	MAPageLocators mAPageLocators = null;

	public MALanguageNeedPageActions() {
		mALanguageNeedPageLocators = new MALanguageNeedPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mALanguageNeedPageLocators);
		
		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
	}

	public void provideLanguageNeedInfo(String pageName, String language, String otherLang, String spoken, String read, String write,
			String translator, String interpretor, String translatorType, String comments) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mALanguageNeedPageLocators.langHeader.get(0));
		CommonUtil.sleep(2000);
		
		TestBase.test.log(LogStatus.INFO, "User has landed on '"+pageName+"' screen");
		Log.info("User has landed on '"+pageName+"' screen");
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.langAddBtn);
		CommonUtil.selectEleFromDropDown(mALanguageNeedPageLocators.langDrpDwn.get(0)).selectByVisibleText(language);
		
		if (language.equalsIgnoreCase("Other Language")) {
			CommonUtil.selectEleFromDropDown(mALanguageNeedPageLocators.langDrpDwn.get(1)).selectByVisibleText(otherLang);
		}

		for (int opt = 0; opt < mALanguageNeedPageLocators.langSpokenBtn.size(); opt++) {
			String spokenVal = CommonUtil.getTextOfEle(mALanguageNeedPageLocators.langSpokenBtnTxt.get(opt));
			String readVal = CommonUtil.getTextOfEle(mALanguageNeedPageLocators.langSpokenBtnTxt.get(opt));
			String writeVal = CommonUtil.getTextOfEle(mALanguageNeedPageLocators.langSpokenBtnTxt.get(opt));

			if (spokenVal.contains(spoken)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.langSpokenBtn.get(opt));
			}
			if (readVal.contains(read)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.langReadBtn.get(opt));
			}
			if (writeVal.contains(write)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.langWriteBtn.get(opt));
			}
		}
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.langInfoConfBtn.get(0)); //Change 1 to 0
		
		try {
		if (CommonUtil.isElementPresent(TestBase.getDriver(), mALanguageNeedPageLocators.bytext_English)) {
			
			TestBase.test.log(LogStatus.INFO, "Primary Language is English so translator option will not be provided");
			Log.info("Primary Language is English so translator option will not be provided");
		}
		else {
		
		try {
			if (translator.equalsIgnoreCase("Yes")) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.transRadioBtn.get(0));
				CommonUtil.selectEleFromDropDown(mALanguageNeedPageLocators.langDrpDwn.get(0)).selectByVisibleText(interpretor);;
				CommonUtil.selectEleFromDropDown(mALanguageNeedPageLocators.langDrpDwn.get(1)).selectByVisibleText(translatorType);
				
				if (interpretor.equalsIgnoreCase("Other")) {
					CommonUtil.inputKeysToEle(mALanguageNeedPageLocators.otherTxtInp.get(0), "test_interpreter");
				}
				if (translatorType.equalsIgnoreCase("Other")) {
					CommonUtil.inputKeysToEle(mALanguageNeedPageLocators.otherTxtInp.get(1), "test_translator_type");
				}
				
			}else {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.transRadioBtn.get(1));
			}
		}catch(ArrayIndexOutOfBoundsException e) {
			Log.info(e.getMessage());
		}
		}
		}
		catch(NoSuchElementException e1) {
			Log.info(e1.getMessage());
		}
		
		CommonUtil.sleep(2000);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.comments);
		CommonUtil.inputKeysToEle(mALanguageNeedPageLocators.comments, comments);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(1));//To Save
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mALanguageNeedPageLocators.navBtn.get(1));
		
		TestBase.test.log(LogStatus.INFO, "User has provided language info");
		Log.info("User has provided language info");
		
		TestBase.mADocReviewPageActions = TestBase.mADocReviewPageActionsObject();
	}

}
