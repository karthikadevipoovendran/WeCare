package pageObject.MAModule;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAADLAndOtherActivitiesPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAADLAndOtherActivitiesPageActions {

	MAADLAndOtherActivitiesPageLocators mAADLAndOtherActivitiesPageLocators = null;
	public List<String> Options_Travel = Arrays.asList("Subway", "Bus", "Car", "Taxi", "Walk", "Ambulette",
			"Driven by Other", "Bus and Subway", "Access-a-ride", "Other");
	public List<String> Options_Activities = Arrays.asList(
			"Personal Hygiene: Bathing, toileting or incontinence, washing clothes, appropriate dress for the weather",
			"Traveling / Mobility: Able to follow directions and comfortable using public transportation; able to climb stairs, walk, get around; any vision, hearing or physical challenges",
			"Shopping & Meal Preparation: Able to plan meals by buying or cooking food",
			"Managing Finances: Ability to pay rent and bills; maintain income benefits; able to budget for the month",
			"Apartment / Room Upkeep: Regular cleaning of space; take out garbage; no excess clutter or hoarding; understands fire safety and evacuation",
			"Social Skills / Supports: Interacts regularly with family/other supports; does not isolate; respects the rights of others/neighbors",
			"Manage Health & Behavioral Health: Recognize health and mental health symptoms/problems; communicate health concerns to care providers; make and keep appointments; take medications as prescribed; relapse preventive awareness",
			"Other", "None");

	public MAADLAndOtherActivitiesPageActions() {
		mAADLAndOtherActivitiesPageLocators = new MAADLAndOtherActivitiesPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAADLAndOtherActivitiesPageLocators);
	}

	public void validateUserLandedOnADLAndOtherActivitiesPage() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.linkbar_Blue);

		if (mAADLAndOtherActivitiesPageLocators.linkbar_Blue.isDisplayed()) {

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					mAADLAndOtherActivitiesPageLocators.header_Activity);

			Assert.assertTrue(mAADLAndOtherActivitiesPageLocators.header_Activity.isDisplayed(),
					"User is not in ADL & Other Activities Tab");
			TestBase.test.log(LogStatus.INFO, "User is in ADL & Other Activities Tab");
			Log.info("User is in ADL & Other Activities Tab");
		}

	}

	public void validate_Content() {

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(0).getText()),
				"Option personal hygiene is not available");
		TestBase.test.log(LogStatus.INFO, "Option for personal hygiene is available");
		Log.info("Option for persona hygiene is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(1).getText()),
				"Option for Traveling/Mobility is not available");
		TestBase.test.log(LogStatus.INFO, "Option for Traveling/Mobility is available");
		Log.info("Option for Traveling/Mobility is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(2).getText()),
				"Option for shopping and meal preparation is not available");
		TestBase.test.log(LogStatus.INFO, "Option for shopping and meal preparation is available");
		Log.info("Option for shopping and meal preparation is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(3).getText()),
				"Option for Managing Finances is not available");
		TestBase.test.log(LogStatus.INFO, "Option for Managing Finances is available");
		Log.info("Option for Managing Finances is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(4).getText()),
				"Option for Apartment/Room UpKeep is not available");
		TestBase.test.log(LogStatus.INFO, "Option for Apartment/Room UpKeep is available");
		Log.info("Option for Apartment/Room UpKeep is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(5).getText()),
				"Option for Social Skills/Supports is not available");
		TestBase.test.log(LogStatus.INFO, "Option for Social Skills/Supports is available");
		Log.info("Option for Social Skills/Supports is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(6).getText()),
				"Option for Manage Health & Behavioral Health is not available");
		TestBase.test.log(LogStatus.INFO, "Option for Manage Health & Behavioral Health is available");
		Log.info("Option for Manage Health & Behavioral Health is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(7).getText()),
				"Option Other is not available");
		TestBase.test.log(LogStatus.INFO, "Option Other is available");
		Log.info("Option Other is available");

		Assert.assertTrue(
				Options_Activities.contains(mAADLAndOtherActivitiesPageLocators.text_all_Checkbox.get(8).getText()),
				"Option None is not available");
		TestBase.test.log(LogStatus.INFO, "Option None is available");
		Log.info("Option None is available");

	}

	public void select_CheckBoxes() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.header_Activity);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.rows_AllOptions.get(0));

		for (int Action = 0; Action < mAADLAndOtherActivitiesPageLocators.rows_AllOptions.size(); Action++) {

			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					mAADLAndOtherActivitiesPageLocators.rows_AllCheckbox.get(0));

		}
	}

	public void provideExplanation(String message) {

		CommonUtil.sleep(2000);

		boolean bool = mAADLAndOtherActivitiesPageLocators.textbox_Explain.isDisplayed();

		if (bool = true) {

			Assert.assertTrue(mAADLAndOtherActivitiesPageLocators.textbox_Explain.isDisplayed(),
					"Textbox to provide explanation is not displayed");
			CommonUtil.scrollIntoView(TestBase.getDriver(), mAADLAndOtherActivitiesPageLocators.textbox_Explain);
			CommonUtil.inputKeysToEle(mAADLAndOtherActivitiesPageLocators.textbox_Explain, message);

		} else {
			Assert.assertTrue(mAADLAndOtherActivitiesPageLocators.textbox_Explain.isDisplayed(),
					"Textbox to provide explanation is not displayed");
		}

	}

	public void verifyExplainTextboxNotDisplayed() {

		CommonUtil.sleep(2000);

		try {
			Assert.assertFalse(mAADLAndOtherActivitiesPageLocators.textbox_Explain.isDisplayed(),
					"Textbox to provide explanation is not displayed");
		} catch (NoSuchElementException e) {
			TestBase.test.log(LogStatus.INFO, "Textbox to provide explanation is not displayed as expected");
			Log.info("Textbox to provide explanation is not displayed as expected");
		}

	}

	public void selectOptionNone() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.header_Activity);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.rows_AllOptions.get(0));

		for (int Action = 0; Action < mAADLAndOtherActivitiesPageLocators.rows_AllOptions.size(); Action++) {
			if (mAADLAndOtherActivitiesPageLocators.rows_AllOptions.get(Action).getText().contains("None")) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						mAADLAndOtherActivitiesPageLocators.rows_AllCheckbox.get(Action));
				break;
			}
		}

	}

	public void verifyOptionsDisabled() {

		int size = mAADLAndOtherActivitiesPageLocators.all_Checkbox_Disabled.size();

		Assert.assertTrue(mAADLAndOtherActivitiesPageLocators.all_Checkbox_Disabled.get(size - 1).isDisplayed(),
				"All options are not disabled");
		TestBase.test.log(LogStatus.INFO, "All Options except None are disabled as expected");
		Log.info("All Options except None are disabled as expected");
	}

	public void provideDetailsForOtherActivities(String message) {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.textbox_OtherActivities);

		CommonUtil.inputKeysToEle(mAADLAndOtherActivitiesPageLocators.textbox_OtherActivities, message);
	}

	public void selectOptionForTravelAssistance() {
		
		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.header_Activity);

		CommonUtil.scrollIntoView(TestBase.getDriver(), mAADLAndOtherActivitiesPageLocators.header_Activity);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAADLAndOtherActivitiesPageLocators.rows_AllOptions.get(0));

		for (int Action = 0; Action < mAADLAndOtherActivitiesPageLocators.rows_AllOptions.size(); Action++) {

			if (mAADLAndOtherActivitiesPageLocators.rows_AllOptions.get(Action).getText().contains("Traveling")) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						mAADLAndOtherActivitiesPageLocators.rows_AllCheckbox.get(Action));
				TestBase.test.log(LogStatus.INFO, "Option for Travelling and Mobility assistance is selected");
				Log.info("Option for Travelling and Mobility assistance is selected");
				break;

			}
		}
	}

	public void FillDetailsForTravelAssistance() {

		
	}

}
