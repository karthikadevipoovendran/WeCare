package pageObject.MAModule;

import org.testng.Assert;

import pageModel.MAModule.FTCInitiationPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;

public class FTCInitiationPageActions {
	
	public FTCInitiationPageLocators fTCInitiationPageLocators = null;
	
	public FTCInitiationPageActions() {
		fTCInitiationPageLocators = new FTCInitiationPageLocators();
	}
	
	public void initiateFTC() {
		String actComments = "test_FTC_Initiation";
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), fTCInitiationPageLocators.fTCChkBox);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), fTCInitiationPageLocators.fTCChkBox);
		CommonUtil.inputKeysToEle(fTCInitiationPageLocators.comments, actComments);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), fTCInitiationPageLocators.ftcBtn.get(0));
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), fTCInitiationPageLocators.ftcRow.get(0));
		String expComments = CommonUtil.getTextOfEle(fTCInitiationPageLocators.ftcRow.get(1));
		Assert.assertTrue(actComments.equalsIgnoreCase(expComments), "Comments are mismatched");
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), fTCInitiationPageLocators.initFTCBtn.get(0));
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), fTCInitiationPageLocators.fTCConfBtn.get(0));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), fTCInitiationPageLocators.fTCConfBtn.get(0));
		
	}
	

}
