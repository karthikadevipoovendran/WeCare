package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAObservationAndClientPresentationPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;



public class MAObservationAndClientPresentationPageActions {

	MAObservationAndClientPresentationPageLocators mAObservationAndClientPresentationPageLocators = null;
	
	public MAObservationAndClientPresentationPageActions() {
		mAObservationAndClientPresentationPageLocators = new MAObservationAndClientPresentationPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAObservationAndClientPresentationPageLocators);
	}
	
	
	public void validateUserLandedOnObservationPage() {
		
		CommonUtil.sleep(2000);
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAObservationAndClientPresentationPageLocators.linkbar_Blue);
		
		if(mAObservationAndClientPresentationPageLocators.linkbar_Blue.isDisplayed()) {
			
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAObservationAndClientPresentationPageLocators.label_Describe);
			
			Assert.assertTrue(mAObservationAndClientPresentationPageLocators.label_Describe.isDisplayed(),"User is not in Observations and Client presentation tab");
			TestBase.test.log(LogStatus.INFO, "User is in Observations and Client presentation tab");
			Log.info("User is in Observations and Client presentation tab");
		}
	}
	
	public void provideClientAppearanceInfo(String message) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAObservationAndClientPresentationPageLocators.label_Describe);
		
		if(CommonUtil.isElementPresent(TestBase.getDriver(), mAObservationAndClientPresentationPageLocators.bytextbox_Describe)) {
			CommonUtil.inputKeysToEle(mAObservationAndClientPresentationPageLocators.textbox_Describe, message);
		}
		else {
			Assert.assertTrue(mAObservationAndClientPresentationPageLocators.textbox_Describe.isDisplayed(), "Textbox to describe client's appearance is not available");
		}
		
		TestBase.mAADLAndOtherActivitiesPageActions = TestBase.mAADLAndOtherActivitiesPageActionsObject();
	}
	
	
}
