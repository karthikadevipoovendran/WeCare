package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Test;

import pageModel.MAModule.MAFFMSupportPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MAFFMSupportPageActions {
	
	MAFFMSupportPageLocators mAFFMSupportPageLocators = null;
	
	public MAFFMSupportPageActions() {
		mAFFMSupportPageLocators = new MAFFMSupportPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAFFMSupportPageLocators);
	}
	
	
	public void provideSupportInfo(String pageName, String ssd, String ssdText, String healthInsuCov, String medicaidType, 
			String manageCareProg, String pension, String compensation, String hivServAdmin, 
			String unemployBenef, String other, String weCare) {

//		for(int tab=0; tab<mAFFMSupportPageLocators.cAssessmentTab.size(); tab++) {
//			if(tab < 6) {
//				CommonUtil.clickEle(mAFFMSupportPageLocators.navBtn.get(1));
//			}
//		}
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mAFFMSupportPageLocators.fFMHeader);
		CommonUtil.sleep(2000);
		
		TestBase.test.log(LogStatus.INFO, "User has landed on '"+pageName+"' screen");
		Log.info("User has landed on '"+pageName+"' screen");

		CommonUtil.selectEleFromDropDown(mAFFMSupportPageLocators.supportDrpDwn.get(0)).selectByVisibleText(ssd);

		if(!ssd.equals("N/A")) {
//			CommonUtil.inputKeysToEle(mAFFMSupportPageLocators.expInput.get(0), ssdText);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.ssiDateBtn);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.ssiDate);
		}
		
		for(int hic=0; hic<mAFFMSupportPageLocators.healthInsuCov.size(); hic++) {
			String hicVal = CommonUtil.getTextOfEle(mAFFMSupportPageLocators.healthInsuCovTxt.get(hic));

			if(hicVal.equalsIgnoreCase(healthInsuCov)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.healthInsuCov.get(hic));
				
				if(healthInsuCov.contains("Other")) {
					CommonUtil.inputKeysToEle(mAFFMSupportPageLocators.otherInsuCov, "test_medicaid");
				}
				else if(healthInsuCov.contains("Medicaid")) {
					
					for(int type=0; type<mAFFMSupportPageLocators.medicaidType.size(); type++) {
						String typeVal = CommonUtil.getTextOfEle(mAFFMSupportPageLocators.medicaidTypeTxt.get(type));
						
						if(typeVal.contains("Managed Care")) {
							CommonUtil.selectEleFromDropDown(mAFFMSupportPageLocators.supportDrpDwn.get(1)).selectByVisibleText(manageCareProg);
							
							if(manageCareProg.equalsIgnoreCase("Other(Specify)")) {
								CommonUtil.inputKeysToEle(mAFFMSupportPageLocators.otherManageCareProg, "test_manage_program");
							}
						}
					}
				}
			}
		}
		
		for(int opt=0; opt<mAFFMSupportPageLocators.pension.size(); opt++) {
			String pensionVal = CommonUtil.getTextOfEle(mAFFMSupportPageLocators.pensionTxt.get(opt));
			String compensationVal = CommonUtil.getTextOfEle(mAFFMSupportPageLocators.compensationTxt.get(opt));
			String hivServAdminVal = CommonUtil.getTextOfEle(mAFFMSupportPageLocators.hivServicesAdminTxt.get(opt));
			String unemployBenefVal = CommonUtil.getTextOfEle(mAFFMSupportPageLocators.unEmployBenefitsTxt.get(opt));
			
			if(pensionVal.equalsIgnoreCase(pension)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.pension.get(opt));
			}
			if(compensationVal.equalsIgnoreCase(compensation)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.compensation.get(opt));
			}
			if(hivServAdminVal.equalsIgnoreCase(hivServAdmin)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.hivServicesAdmin.get(opt));
			}
			if(unemployBenefVal.equalsIgnoreCase(unemployBenef)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.unEmployBenefits.get(opt));
			}
		}
		if(other.equalsIgnoreCase("Yes")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.other.get(0));
			CommonUtil.inputKeysToEle(mAFFMSupportPageLocators.otherComment, other);
		}else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.other.get(1));			
		}
		
		if(weCare.equalsIgnoreCase("Yes")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.otherThanWeCare.get(0));
			CommonUtil.inputKeysToEle(mAFFMSupportPageLocators.provName, "test_provider");
			CommonUtil.inputKeysToEle(mAFFMSupportPageLocators.contPerson, "test_contact_person");
			
		}else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.otherThanWeCare.get(1));			
		}
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAFFMSupportPageLocators.navBtn.get(1));
		
		TestBase.test.log(LogStatus.INFO, "User has provided FFM Support info");
		Log.info("User has provided FFM Support info");
		
		TestBase.mAPurposeOfVisitPageActions = TestBase.mAPurposeOfVisitPageActionsObject();
	}

}
