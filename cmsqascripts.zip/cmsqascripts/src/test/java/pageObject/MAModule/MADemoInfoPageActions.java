package pageObject.MAModule;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MADemoInfoPageLocators;
import pageModel.MAModule.MAPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class MADemoInfoPageActions {

	MADemoInfoPageLocators mADemoInfoPageLocators = null;
	MAPageLocators mAPageLocators = null;

	public MADemoInfoPageActions() {
		mADemoInfoPageLocators = new MADemoInfoPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mADemoInfoPageLocators);
		
		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
	}

	public void provideDemoInfo(String pageName, String pCommuMode, String pAddr, String pPhn, String addr, String city, String state,
			String zip, String ethnic, String otherEthnic) {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), mADemoInfoPageLocators.demoHeader);
		CommonUtil.sleep(2000);
		
		TestBase.test.log(LogStatus.INFO, "User has landed on '"+pageName+"' screen");
		Log.info("User has landed on '"+pageName+"' screen");
		
		CommonUtil.selectEleFromDropDown(mADemoInfoPageLocators.demoDrpDwn.get(0)).selectByVisibleText(pCommuMode);
		CommonUtil.selectEleFromDropDown(mADemoInfoPageLocators.demoDrpDwn.get(1)).selectByVisibleText(pPhn);
		
		if (addr.equalsIgnoreCase("Other")) {
			CommonUtil.inputKeysToEle(mADemoInfoPageLocators.otherAddr, addr);
			CommonUtil.inputKeysToEle(mADemoInfoPageLocators.otherAddr, city);
			CommonUtil.selectEleFromDropDown(mADemoInfoPageLocators.demoDrpDwn.get(4)).selectByVisibleText(state);
			CommonUtil.inputKeysToEle(mADemoInfoPageLocators.otherAddr, zip);
		}
		CommonUtil.selectEleFromDropDown(mADemoInfoPageLocators.demoDrpDwn.get(2)).selectByVisibleText(pAddr);
		CommonUtil.selectEleFromDropDown(mADemoInfoPageLocators.demoDrpDwn.get(3)).selectByVisibleText(ethnic);
		
		if (ethnic.equalsIgnoreCase("Other(Specify)")) {
			CommonUtil.inputKeysToEle(mADemoInfoPageLocators.otherEthnicity, otherEthnic);
		}
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(1));
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), mADemoInfoPageLocators.navBtn.get(1));
				
		TestBase.test.log(LogStatus.INFO, "User has provided demographic info");
		Log.info("User has provided demographic info");
		
		TestBase.mAEmergencyInfoPageActions = TestBase.mAEmergencyInfoPageActionsObject();
	}

}
