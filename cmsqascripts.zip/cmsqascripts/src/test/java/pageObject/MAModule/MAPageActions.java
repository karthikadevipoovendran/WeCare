package pageObject.MAModule;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.MAModule.MAPageLocators;
import pageModel.MAModule.MAPageCommonLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;


public class MAPageActions {

	MAPageLocators mAPageLocators = null;
	MAPageCommonLocators mAPageCommonLocators = null;
	
	public MAPageActions() {
		mAPageLocators = new MAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageLocators);
		
		mAPageCommonLocators = new MAPageCommonLocators();
		PageFactory.initElements(TestBase.getDriver(), mAPageCommonLocators);
	}

	public void verifyMyAssignmentPageHeader(String header) {
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), mAPageLocators.byActivityStatusTxt, 1);
		CommonUtil.verifyPageHeader(header, mAPageLocators.myAssignmentHeader);
	}
	
	
	public void navigateToMyAssignments(String configFileURL, String endPoint) {
		
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);
		TestBase.test.log(LogStatus.INFO, "User has navigated to My Assignments Page");
		Log.info("User has navigated to My Assignments Page");

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				mAPageCommonLocators.myAssignments_headername);
		TestBase.test.log(LogStatus.INFO, "Header is displayed");
		Log.info("Header is displayed");
		
	}
	public void openAssignedTask(String actionOptionText) {
		
		CommonUtil.sleep(2000);
		
		List<String> appType = new ArrayList<>();
		appType.add("Clinical Assessment");
		appType.add("Clinical Re-Assessment");
		appType.add("Psychiatric Evaluation");
		
		boolean bool = false;
		
		for(int statCol = 1; statCol < mAPageLocators.activityStatusTxt.size(); statCol++) {
			String statVal = CommonUtil.getTextOfEle(mAPageLocators.activityStatusTxt.get(statCol));
			String appVal = CommonUtil.getTextOfEle(mAPageLocators.appType.get(statCol));
			
			if((statVal.equals("In Progress") || statVal.equals("Assigned")) && (appType.contains(appVal))) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.actionBtn.get(statCol-1));
				
				for(int actOpt = 0; actOpt < mAPageLocators.actionOptBtn.size(); actOpt++) {
					String actOptText = CommonUtil.getTextOfEle(mAPageLocators.actionOptBtnTxt.get(actOpt));
					
					if(actOptText.contains(actionOptionText)) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.actionOptBtn.get(actOpt));
						bool = true;
						break;
					}
					else if(actOpt == mAPageLocators.actionOptBtn.size()-1 && bool == false) {
						Assert.assertTrue(false, "No '"+actionOptionText+"' action option is available");
					}
				}
			}else {
				if(statCol == mAPageLocators.activityStatusTxt.size()-1) {
					TestBase.test.log(LogStatus.INFO, "No '"+actionOptionText+"' option available");
					Log.info("No '"+actionOptionText+"' option available");
				}
				continue;
			}
			if(bool == true) {
				break;
			}
		}
		
		TestBase.mAClinicalAssessPageActions = TestBase.mAClinicalAssessPageActionsObject();
		TestBase.mACaseOverviewPageActions = TestBase.mACaseOverviewPageActionsObject();
		TestBase.mAReleasePageActions = TestBase.mAReleasePageActionsObject();
		TestBase.mAPageActions = TestBase.mAPageActionsObject();
	}
	
	public void confirmTask() {
		try {
			if(mAPageLocators.assessmentConfBtn.get(0).isDisplayed()) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), mAPageLocators.assessmentConfBtn.get(0));
			}

		}catch(IndexOutOfBoundsException e) {
			Log.info("Confirm Task: " + e.getMessage());
		}
	}
	
	
}

