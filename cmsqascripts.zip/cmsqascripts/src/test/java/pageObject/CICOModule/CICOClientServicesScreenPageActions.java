package pageObject.CICOModule;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Test;

import pageModel.CICOModule.CICOClientServicesScreenPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CICOClientServicesScreenPageActions {
	
	CICOClientServicesScreenPageLocators cICOClientServicesScreenPageLocators = null;
	
	public CICOClientServicesScreenPageActions() {
		this.cICOClientServicesScreenPageLocators = new CICOClientServicesScreenPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOClientServicesScreenPageLocators);
	}
	
	public void verifyClientServicesScreen(String val) {
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOClientServicesScreenPageLocators.closeCSSBtn);
		CommonUtil.verifyPageHeader(val, cICOClientServicesScreenPageLocators.cssHeader);
		TestBase.test.log(LogStatus.INFO, "CSS page header is verified");
		Log.info("CSS page header is verified");

		CommonUtil.scrollIntoView(TestBase.getDriver(), cICOClientServicesScreenPageLocators.closeCSSBtn);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOClientServicesScreenPageLocators.closeCSSBtn);
		TestBase.test.log(LogStatus.INFO, "User has clicked on CSS page close button");
		Log.info("User has clicked on CSS page close button");
	}

}
