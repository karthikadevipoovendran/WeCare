package pageObject.CICOModule;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOReSchedulePageLocators;
import testUtil.CommonUtil;
import testUtil.Log;
import pageTest.TestBase;


public class CICOReSchedulePageActions {
	
	CICOReSchedulePageLocators cICOReSchedulePageLocators = null;
	
	public CICOReSchedulePageActions() {
		this.cICOReSchedulePageLocators = new CICOReSchedulePageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOReSchedulePageLocators);
	}
	

	public void verifyClientLandedOnReScheduleScreen(String screenName) {
		CommonUtil.waitDriverUntilElementIsClickable(TestBase.getDriver(), cICOReSchedulePageLocators.rsDatePickerBtn);		
		CommonUtil.verifyPageHeader(screenName, cICOReSchedulePageLocators.rescheduleScreenHeader.get(1));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOReSchedulePageLocators.rsScreenCancelBtn);
	}

	
	

}
