package pageObject.CICOModule;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOExitPackagePageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CICOExitPackagePageActions {

	private static CICOExitPackagePageLocators cICOExitPackagePageLocators = null;
	public static String EP_nameToValidate = null;
	public static String EP_caseNumberToValidate = null;
	public static String EP_appointmentType = null;

	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public CICOExitPackagePageActions() {

		CICOExitPackagePageActions.cICOExitPackagePageLocators = new CICOExitPackagePageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOExitPackagePageLocators);

	}

	public void getDetailsofCheckedInUser() {

		EP_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		EP_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		EP_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
	}

	public void exitPackage() {
		if (EP_nameToValidate == null) {
			Log.info("No records are available to be checked out");
		} else {
			/* Navigate to exit package */
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOExitPackagePageLocators.text_Exit_package);
			TestBase.test.log(LogStatus.INFO, "Exit Package is clicked");
			Log.info("Exit Package is clicked");

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cICOExitPackagePageLocators.header_Exit_Package);

			Assert.assertTrue(cICOExitPackagePageLocators.header_Exit_Package.isDisplayed());
			TestBase.test.log(LogStatus.INFO, "User is in Exit Package Page");
			Log.info("User is in Exit Package Page");

			try {
				boolean isDocumentAvailable = cICOExitPackagePageLocators.text_noDocuments.isDisplayed();

				if (isDocumentAvailable == false) {

					for (WebElement checkboxselect : cICOExitPackagePageLocators.checkbox_SSAorDR) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(), checkboxselect);
						TestBase.test.log(LogStatus.INFO, "All check boxes have been selected");
						Log.info("All check boxes have been selected");
					}

				} else {
					TestBase.test.log(LogStatus.INFO, "There are no documents available");
					Log.info("There are no documents available");
				}
			} catch (NoSuchElementException e) {

				for (WebElement checkboxselect : cICOExitPackagePageLocators.checkbox_SSAorDR) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), checkboxselect);
					TestBase.test.log(LogStatus.INFO, "All check boxes have been selected");
					Log.info("All check boxes have been selected");
				}

			}

			boolean isCheckOutEnabled = cICOExitPackagePageLocators.exitPackage_CheckOutButton.isEnabled();

			if (isCheckOutEnabled) {
				TestBase.test.log(LogStatus.INFO, "Check out button is enabled");
				Log.info("Check out button is enabled");
			} else {
				TestBase.test.log(LogStatus.INFO, "Check out button is not enabled");
				Log.info("Check out button is not enabled");
			}

			/* To click on the check out button */
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckoutWithCForATSLocators.exitPackage_CheckOutButton);
//		TestBase.test.log(LogStatus.INFO, "Check out button is clicked");
//		Log.info("Check out button is clicked");

			/* To exit back to check-in/check-out screen */
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOExitPackagePageLocators.button_carfare_close);
			TestBase.test.log(LogStatus.INFO,
					"Close button is clicked to take the user back to check in/check out page");
			Log.info("Close button is clicked to take the user back to check in/check out page");

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOExitPackagePageLocators.textCICO);
			TestBase.test.log(LogStatus.INFO, "User is now in check-in/check-out page");
			Log.info("User is now in check-in/check-out page");

		}

	}
}
