package pageObject.CICOModule;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOCancelCheckInPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CICOCancelCheckInPageActions {

	public static CICOCancelCheckInPageLocators cICOCancelCheckInPageLocators = null;
	public static String CC_nameToValidate = null;
	public static String CC_caseNumberToValidate = null;
	public static String CC_appointmentType = null;
	public static boolean CC_checkInSuccessfull = false;
	public static boolean CC_isInProgressUser = false;

	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public CICOCancelCheckInPageActions() {

		CICOCancelCheckInPageActions.cICOCancelCheckInPageLocators = new CICOCancelCheckInPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOCancelCheckInPageLocators);

	}

	public void getDetailsofCheckedInUser() {

		CC_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		CC_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		CC_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
		CC_checkInSuccessfull = CICOCheckInCheckOutCommonActions.common_checkInSuccessfull;
	}

	public void cancelCheckIn() {

		//CICO_Common.increasePageSize("baseURL", "/checkin");

		CommonUtil.sleep(2000);

		if (CC_nameToValidate == null || CC_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot proceed with cancel check-in");
			Log.info("No checked in records. Cannot proceed with cancel check-in");
		} else {
			


			/* Options in Action button for any User */
			if (CommonUtil.isElementPresent(TestBase.getDriver(), cICOCancelCheckInPageLocators.byActionsButton)) {

				try {
					if (CommonUtil.isElementPresent(TestBase.getDriver(), cICOCancelCheckInPageLocators.byReschedule)) {
						TestBase.test.log(LogStatus.INFO, "Re-schedule option is displayed");
						Log.info("Re-schedule option is displayed");
					} else {
						TestBase.test.log(LogStatus.INFO, "Re-schedule option is not displayed");
						Log.info("Re-schedule option is not displayed");
					}
				} catch (NoSuchElementException e) {

					TestBase.test.log(LogStatus.INFO, "Re-schedule option does not exist");
					Log.info("Re-schedule option does not exist");

				}

				try {
					if (CommonUtil.isElementPresent(TestBase.getDriver(),
							cICOCancelCheckInPageLocators.byCancelCheckIn)) {
						TestBase.test.log(LogStatus.INFO, "Cancel Check-In option is displayed");
						Log.info("Cancel Check-In option is displayed");
					} else {
						TestBase.test.log(LogStatus.INFO, "Cancel Check-In option is not displayed");
						Log.info("Cancel Check-In option is not displayed");
					}
				} catch (NoSuchElementException e) {

					TestBase.test.log(LogStatus.INFO, "Cancel Check-In option does not exist");
					Log.info("Cancel Check-In option does not exist");
				}

				try {
					if (CommonUtil.isElementPresent(TestBase.getDriver(), cICOCancelCheckInPageLocators.byCheckOut)) {
						TestBase.test.log(LogStatus.INFO, "Check-Out option is displayed");
						Log.info("Check-Out option is displayed");
					} else {
						TestBase.test.log(LogStatus.INFO, "Check-Out option is not displayed");
						Log.info("Check-Out option is not displayed");
					}
				} catch (NoSuchElementException e) {

					TestBase.test.log(LogStatus.INFO, "Check-Out option does not exist");
					Log.info("Check-out option does not exist");
				}

				try {
					if (CommonUtil.isElementPresent(TestBase.getDriver(),
							cICOCancelCheckInPageLocators.byAppointmentLetter)) {
						TestBase.test.log(LogStatus.INFO, "Appointment letter option is displayed");
						Log.info("Appointment letter option is displayed");
					} else {
						TestBase.test.log(LogStatus.INFO, "Appointment letter option is not displayed");
						Log.info("Appointment letter option is not displayed");
					}
				} catch (NoSuchElementException e) {
					TestBase.test.log(LogStatus.INFO, "Appointment letter option does not exist");
					Log.info("Appointment letter option does not exist");

				}

				try {
					if (CommonUtil.isElementPresent(TestBase.getDriver(),
							cICOCancelCheckInPageLocators.byClientServicesScreen)) {
						TestBase.test.log(LogStatus.INFO, "Client Services Screen option is displayed");
						Log.info("Client Services Screen option is displayed");
					} else {
						TestBase.test.log(LogStatus.INFO, "Client Services Screen option is not displayed");
						Log.info("Client Services Screen option is not displayed");
					}
				} catch (NoSuchElementException e) {
					TestBase.test.log(LogStatus.INFO, "Client Services Screen option does not exist");
					Log.info("Client Services Screen option does not exist");
				}

				TestBase.test.log(LogStatus.INFO, "All AV Options for Pending user has been validated");
				Log.info("All AV Options has been validated");

			} else {
				TestBase.test.log(LogStatus.INFO, "AV options could not be validated");
				Log.info("AV options could not be validated");
			}

			try {
				if (CommonUtil.isElementPresent(TestBase.getDriver(), cICOCancelCheckInPageLocators.byCancelCheckIn)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCancelCheckInPageLocators.CICO_CancelCheckIn);
					TestBase.test.log(LogStatus.INFO, "Cancel Check-In button is clicked");
					Log.info("Cancel Check-In button is clicked");

					/* Enter Reason for Cancel Check-In */
					CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
							cICOCancelCheckInPageLocators.checkInTextInPopup);

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOCancelCheckInPageLocators.reasonForCancelTextBox);

					CommonUtil.inputKeysToEle(cICOCancelCheckInPageLocators.reasonForCancelTextBox, "Automation Test");
					TestBase.test.log(LogStatus.INFO, "Reason for Cancel Check-In is provided");
					Log.info("Reason for Cancel Check-In is provided");

					//Assert.assertTrue(cICOCancelCheckInPageLocators.reasonForCancelTextBox.getText().isEmpty());

					/* Click on Confirm Button */

					CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
							cICOCancelCheckInPageLocators.checkInTextInPopup);

					//Assert.assertTrue(cICOCancelCheckInPageLocators.reasonForCancelTextBox.getText().isEmpty());

					CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCancelCheckInPageLocators.confirmButton);
					TestBase.test.log(LogStatus.INFO, "Confirm button is clicked");
					Log.info("Confirm button is clicked");

//					SoftAssert softAssertion = new SoftAssert();
//					softAssertion.assertEquals(cICOCancelCheckInPageLocators.popUpMessage.getText(),
//							"Check-In Cancelled successfully");
//					TestBase.test.log(LogStatus.INFO, "Cancel Check-In Successful for a Pending/Assigned User");
//					Log.info("Cancel Check-In Successful for a Pending/Assigned User");
				} else {
					TestBase.test.log(LogStatus.INFO,
							"Cancel Check-In option will not be available for In-Progress User");
					Log.info("Cancel Check-In option will not be available for In-Progress User");
					CC_isInProgressUser = true;
				}
			} catch (NoSuchElementException e) {
				//e.printStackTrace();
				TestBase.test.log(LogStatus.INFO, "Cancel Check-In option will not be available for In-Progress User");
				Log.info("Cancel Check-In option will not be available for In-Progress User");
				CC_isInProgressUser = true;
			}

		}

	}
	
	
}
