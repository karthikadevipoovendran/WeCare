package pageObject.CICOModule;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOCheckInCheckOutCommonLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;

public class CICOCheckInCheckOutCommonActions {

	public static CICOCheckInCheckOutCommonLocators cICOCheckInCheckOutCommonLocators = null;
	public static String common_ClientName = null;
	public static String common_CheckInDate = null;
	public static String common_CMSUser = null;
	public static String common_AppointmentType = null;
	public static String common_CaseNumber = null;
	public static String common_ClientName_Current = null;
	public static String common_CheckInDate_Current = null;
	public static String common_CMSUser_Current = null;
	public static String common_AppointmentType_Current = null;
	public static String common_CaseNumber_Current = null;
	public static boolean common_checkInSuccessfull = false;
	public static String isActionOptionsDisplayed = "No";
	public static List<String> invalid_ApptTypes = Arrays.asList("Wellness Plan Initiation","VRS Child Care Review","Wellness Case Management");
	public static List<String> ApptType_Assessment= Arrays.asList("Clinical","Medical","Psychiatric");
	

	CICOAppointmentLogPageActions Log_Actions = new CICOAppointmentLogPageActions();

	public CICOCheckInCheckOutCommonActions() {

		CICOCheckInCheckOutCommonActions.cICOCheckInCheckOutCommonLocators = new CICOCheckInCheckOutCommonLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators);

	}

	/* To increase the page size */

	public void increasePageSize(String configFileURL, String endPoint) {

		//CommonUtil.navigateTo(TestBase.driver, "http://dev.ewweb.prutechlab.com/cms/#/checkin");
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);
		TestBase.test.log(LogStatus.INFO, "User is navigated to Check-In/Check-Out Page");
		Log.info("User is navigated to Check-In/Check-Out Page");

		CommonUtil.sleep(2000);
		
		Log_Actions.clickAllAppointments();

//		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.byMsgContainer);
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.byAppointmentDateCol, 1);
		CommonUtil.sleep(2000);

		Log_Actions.clickAllAppointments();

		CommonUtil.sleep(2000);

//		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.byMsgContainer);
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.byAppointmentDateCol, 1);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCheckInCheckOutCommonLocators.textCICO);
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCheckInCheckOutCommonLocators.CN);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.selectArrow);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.valueFromDropDown);
		TestBase.test.log(LogStatus.INFO, "Page Size is increased successfully");
		Log.info("Page Size is increased successfully");

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCheckInCheckOutCommonLocators.CN);

		Assert.assertTrue(cICOCheckInCheckOutCommonLocators.CN.isDisplayed());

		TestBase.CAAssignCasePageActions = TestBase.cAAssignCaseAndValidateActionsObject();
		TestBase.CAReAssignCasePageActions = TestBase.cAReAssignCaseAndValidateActionsObject();
		TestBase.CICOCarFarePageActions = TestBase.cICOCarFarePageActionsObject();
		TestBase.MAPageCommonActions = TestBase.mAPageCommonActionsObject();
		TestBase.CADeassignCasesPageActions = TestBase.cADeassignAllCasesActionsObject();
		TestBase.cAPageActions = TestBase.cAPageActionsObject();
	}

	/* TO check in a user */

	public void checkInUser() {
		

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCheckInCheckOutCommonLocators.headerClientName);
		Assert.assertTrue(cICOCheckInCheckOutCommonLocators.headerClientName.isDisplayed());
		
		CommonUtil.sleep(1000);

		for (int clientName = 1; clientName < cICOCheckInCheckOutCommonLocators.clientName.size(); clientName++) {

			common_ClientName_Current = cICOCheckInCheckOutCommonLocators.clientName.get(clientName).getText();
			common_CheckInDate_Current = cICOCheckInCheckOutCommonLocators.checkInDateTimeList.get(clientName)
					.getText();
			common_CMSUser_Current = cICOCheckInCheckOutCommonLocators.cMSUserList.get(clientName).getText();
			common_AppointmentType_Current = cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName)
					.getText();
			common_CaseNumber_Current = cICOCheckInCheckOutCommonLocators.caseNumberList.get(clientName).getText();

		if (invalid_ApptTypes.contains(common_AppointmentType_Current)) {
			continue;
		}
		else {
			if (common_CheckInDate_Current.isEmpty() && common_CMSUser_Current.isEmpty()) {

				common_ClientName = cICOCheckInCheckOutCommonLocators.clientName.get(clientName).getText();
				common_CheckInDate = cICOCheckInCheckOutCommonLocators.checkInDateTimeList.get(clientName).getText();
				common_CMSUser = cICOCheckInCheckOutCommonLocators.cMSUserList.get(clientName).getText();
				common_AppointmentType = cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName)
						.getText();
				common_CaseNumber = cICOCheckInCheckOutCommonLocators.caseNumberList.get(clientName).getText();

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.clientName.get(clientName));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.clientName.get(clientName));

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

				CommonUtil.sleep(2000);

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

				try {
					CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));

				} catch (TimeoutException actionTab) {
					try {
						if (CommonUtil.isElementPresent(TestBase.getDriver(),
								cICOCheckInCheckOutCommonLocators.byactionTabListItems)) {

							CommonUtil.clickEleJsExec(TestBase.getDriver(),
									cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));
						}
					} catch (NoSuchElementException NoAction) {
						TestBase.test.log(LogStatus.INFO, "Action Tab items are not displayed");
						Log.info("Action Tab items are not displayed");
					}

				}

				// CommonUtil.clickEleJsExec(TestBase.getDriver(),cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));

				try {
					if (cICOCheckInCheckOutCommonLocators.text_Opt_Out.isDisplayed()) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								cICOCheckInCheckOutCommonLocators.button_Opt_Out_Cancel);

						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								cICOCheckInCheckOutCommonLocators.actionTabListItems.get(1));
						TestBase.test.log(LogStatus.INFO, "Check-In Option is clicked");
						Log.info("Check-In Option is clicked");

						break;
					}

				} catch (NoSuchElementException noOptOut) {
					TestBase.test.log(LogStatus.INFO, "Check-In Option is clicked");
					Log.info("Check-In Option is clicked");
					break;

				}

			} else {
				common_ClientName = null;
				common_CheckInDate = null;
				common_CMSUser = null;
				common_AppointmentType = null;
				common_CaseNumber = null;
				continue;
			}
		}


		}

		if (common_ClientName == null) {
			TestBase.test.log(LogStatus.INFO, "All records have been already checked in");
			Log.info("All records have been already checked in");
		} else {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cICOCheckInCheckOutCommonLocators.CICO_CheckIn_Label_Recommendations);
			try {
				if (CommonUtil.isElementPresent(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.bytext_typeOfInterview)) {

					Select typeofInterview = new Select(cICOCheckInCheckOutCommonLocators.dropdown_typeOfInterview);

					typeofInterview.selectByIndex(1);

				}
			} catch (NoSuchElementException type) {
				TestBase.test.log(LogStatus.INFO, "Type of interview option not available for this client");
				Log.info("Type of interview option not available for this client");
			}
			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cICOCheckInCheckOutCommonLocators.CICO_CheckIn_RadioButtons.get(1));
			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cICOCheckInCheckOutCommonLocators.CICO_CheckIn_RadioButtons.get(3));

			CommonUtil.sleep(1000);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.button_CheckIn);

			common_checkInSuccessfull = true;

			if (common_checkInSuccessfull == true) {
				TestBase.test.log(LogStatus.INFO, "Check In for the client " + common_ClientName + " is successfull");
				Log.info("Check In for the client " + common_ClientName + " is successfull");
			} else {
				TestBase.test.log(LogStatus.INFO, "Check In could not be completed");
				Log.info("Check In could not be completed");
			}

			if (common_ClientName == null) {
				TestBase.test.log(LogStatus.INFO, "All records have been checked in");
				Log.info("All records have been checked in");
			}

		}

		TestBase.CICOCancelCheckInPageActions = TestBase.cICOCancelCheckInPageActionsObject();
		TestBase.CICOCheckoutPageActions = TestBase.cICOCheckoutWithCForATSActionsObject();
		TestBase.cAPageActions = TestBase.cAPageActionsObject();
	}
	
	public void checkInUser_FilterByApptType() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCheckInCheckOutCommonLocators.headerClientName);
		Assert.assertTrue(cICOCheckInCheckOutCommonLocators.headerClientName.isDisplayed());

		for (int clientName = 1; clientName < cICOCheckInCheckOutCommonLocators.clientName.size(); clientName++) {

			common_ClientName_Current = cICOCheckInCheckOutCommonLocators.clientName.get(clientName).getText();
			common_CheckInDate_Current = cICOCheckInCheckOutCommonLocators.checkInDateTimeList.get(clientName)
					.getText();
			common_CMSUser_Current = cICOCheckInCheckOutCommonLocators.cMSUserList.get(clientName).getText();
			common_AppointmentType_Current = cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName)
					.getText();
			common_CaseNumber_Current = cICOCheckInCheckOutCommonLocators.caseNumberList.get(clientName).getText();

			// if (common_AppointmentType_Current.contains("Clinical")) {

			if (common_CheckInDate_Current.isEmpty() && common_CMSUser_Current.isEmpty()) {

				common_ClientName = cICOCheckInCheckOutCommonLocators.clientName.get(clientName).getText();
				common_CheckInDate = cICOCheckInCheckOutCommonLocators.checkInDateTimeList.get(clientName).getText();
				common_CMSUser = cICOCheckInCheckOutCommonLocators.cMSUserList.get(clientName).getText();
				common_AppointmentType = cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName)
						.getText();
				common_CaseNumber = cICOCheckInCheckOutCommonLocators.caseNumberList.get(clientName).getText();
				
				if(ApptType_Assessment.contains(common_AppointmentType)) {

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.clientName.get(clientName));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.clientName.get(clientName));

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

				CommonUtil.sleep(2000);

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

				try {
					CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));

				} catch (TimeoutException actionTab) {
					try {
						if (CommonUtil.isElementPresent(TestBase.getDriver(),
								cICOCheckInCheckOutCommonLocators.byactionTabListItems)) {

							CommonUtil.clickEleJsExec(TestBase.getDriver(),
									cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));
						}
					} catch (NoSuchElementException NoAction) {
						TestBase.test.log(LogStatus.INFO, "Action Tab items are not displayed");
						Log.info("Action Tab items are not displayed");
					}

				}

				// CommonUtil.clickEleJsExec(TestBase.getDriver(),cICOCheckInCheckOutCommonLocators.actionTabListItems.get(0));

				try {
					if (cICOCheckInCheckOutCommonLocators.text_Opt_Out.isDisplayed()) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								cICOCheckInCheckOutCommonLocators.button_Opt_Out_Cancel);

						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								cICOCheckInCheckOutCommonLocators.actionTabListItems.get(1));
						TestBase.test.log(LogStatus.INFO, "Check-In Option is clicked");
						Log.info("Check-In Option is clicked");

						break;
					}

				} catch (NoSuchElementException noOptOut) {
					TestBase.test.log(LogStatus.INFO, "Check-In Option is clicked");
					Log.info("Check-In Option is clicked");
					break;

				}
				
			}

			} else {
				common_ClientName = null;
				common_CheckInDate = null;
				common_CMSUser = null;
				common_AppointmentType = null;
				common_CaseNumber = null;
				continue;
			}

			// }

//			else {
//
//				common_ClientName = null;
//				common_CheckInDate = null;
//				common_CMSUser = null;
//				common_AppointmentType = null;
//				common_CaseNumber = null;
//
//				continue;
//
//			}

		}

		if (common_ClientName == null) {
			TestBase.test.log(LogStatus.INFO, "All records have been already checked in");
			Log.info("All records have been already checked in");
		} else {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cICOCheckInCheckOutCommonLocators.CICO_CheckIn_Label_Recommendations);
			try {
				if (CommonUtil.isElementPresent(TestBase.getDriver(),
						cICOCheckInCheckOutCommonLocators.bytext_typeOfInterview)) {

					Select typeofInterview = new Select(cICOCheckInCheckOutCommonLocators.dropdown_typeOfInterview);

					typeofInterview.selectByIndex(1);

				}
			} catch (NoSuchElementException type) {
				TestBase.test.log(LogStatus.INFO, "Type of interview option not available for this client");
				Log.info("Type of interview option not available for this client");
			}
			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cICOCheckInCheckOutCommonLocators.CICO_CheckIn_RadioButtons.get(1));
			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cICOCheckInCheckOutCommonLocators.CICO_CheckIn_RadioButtons.get(3));

			CommonUtil.sleep(1000);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.button_CheckIn);

			common_checkInSuccessfull = true;

			if (common_checkInSuccessfull == true) {
				TestBase.test.log(LogStatus.INFO, "Check In for the client " + common_ClientName + " is successfull");
				Log.info("Check In for the client " + common_ClientName + " is successfull");
			} else {
				TestBase.test.log(LogStatus.INFO, "Check In could not be completed");
				Log.info("Check In could not be completed");
			}

			if (common_ClientName == null) {
				TestBase.test.log(LogStatus.INFO, "All records have been checked in");
				Log.info("All records have been checked in");
			}

		}

		TestBase.CICOCancelCheckInPageActions = TestBase.cICOCancelCheckInPageActionsObject();
		TestBase.CICOCheckoutPageActions = TestBase.cICOCheckoutWithCForATSActionsObject();

	}

	public void clickActionButtonforCheckedInUser() {

		this.increasePageSize("baseURL", "/checkin");

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			Log.info("All records are already checked in");
		} else {

			CommonUtil.sleep(2000);

			for (int clientName = 1; clientName < cICOCheckInCheckOutCommonLocators.list_clientName
					.size(); clientName++) {

				if (cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName).getText()
						.contains(common_ClientName)) {
					
					if (cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName).getText().contains(common_AppointmentType)) {

						//System.out.println(cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName).getText());
					// CommonUtil.scrollIntoView(TestBase.getDriver(),
					// cICOCancelCheckIn_PendingUserLocators.list_clientName.get(clientName));

					CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName));

					CommonUtil.sleep(1000);

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.actionIconList.get(clientName - 1));
					TestBase.test.log(LogStatus.INFO, "Action button is clicked");
					Log.info("Action button is clicked");
					break;

				}
				}
				
			}
		}

	}

	public void verifyLogViewAfterCancelCheckIn() {

		this.increasePageSize("baseURL", "/checkin");

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "Check-In Date field is empty as expected");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			CommonUtil.sleep(2000);

			for (int clientName = 1; clientName < cICOCheckInCheckOutCommonLocators.list_clientName
					.size(); clientName++) {

				if (cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName).getText()
						.contains(common_ClientName)) {
					
					if (cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName).getText().contains(common_AppointmentType)) {

						//System.out.println(cICOCheckInCheckOutCommonLocators.appointmentTypeList.get(clientName).getText());

					CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName));

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOCheckInCheckOutCommonLocators.list_clientName.get(clientName));

					if (CICOCancelCheckInPageActions.CC_isInProgressUser == false) {
						Assert.assertTrue(cICOCheckInCheckOutCommonLocators.list_checkInDateTime.get(clientName)
								.getText().isEmpty());
						TestBase.test.log(LogStatus.INFO, "Check-In Date field is empty as expected");
						Log.info("Check-In Date field is empty as expected");

						Assert.assertTrue(
								cICOCheckInCheckOutCommonLocators.list_cmsUser.get(clientName).getText().isEmpty());
						TestBase.test.log(LogStatus.INFO, "Assignee field is empty as expected");
						Log.info("Assignee field is empty as expected");

					} else {
						Assert.assertFalse(cICOCheckInCheckOutCommonLocators.list_checkInDateTime.get(clientName)
								.getText().isEmpty());
						TestBase.test.log(LogStatus.INFO, "Check-In Date field is not empty as expected");
						Log.info("Check-In Date field is not empty as expected");

						Assert.assertFalse(
								cICOCheckInCheckOutCommonLocators.list_cmsUser.get(clientName).getText().isEmpty());
						TestBase.test.log(LogStatus.INFO, "Assignee field is not empty as expected");
						Log.info("Assignee field is not empty as expected");
					}

					break;

				}
					
				}
			}

		}

	}
	
	public void closeModal() {
		
		try {
		if(cICOCheckInCheckOutCommonLocators.text_CaseDetails.isDisplayed()) {
			
			CommonUtil.scrollIntoView(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.button_Modal_Cancel);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckInCheckOutCommonLocators.button_Modal_Cancel);
			TestBase.test.log(LogStatus.INFO, "Modal which was opened is now closed");
			Log.info("Modal which was opened is now closed");
			
		}
		}
		catch(NoSuchElementException e) {
			
			TestBase.test.log(LogStatus.INFO, "Modal is not in open state");
			Log.info("Modal is not in open state");
			
		}
		
	}

}
