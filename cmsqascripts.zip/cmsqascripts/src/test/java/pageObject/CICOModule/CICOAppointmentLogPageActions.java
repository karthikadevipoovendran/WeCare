package pageObject.CICOModule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Test;

import pageModel.CICOModule.CICOAppointmentLogPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;

public class CICOAppointmentLogPageActions {

	CICOAppointmentLogPageLocators cICOAppointmentLogPageLocators = null;
	public static String checkInPageClientName = null;
	public static String appointmentType = null;
	public static String caseNumber = null;
	public static int clientRow = 0;
	public static int saveRow = 0;

	public CICOAppointmentLogPageActions() {
		this.cICOAppointmentLogPageLocators = new CICOAppointmentLogPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOAppointmentLogPageLocators);
	}
	
	public void closeTab() {
		if(cICOAppointmentLogPageLocators.checkInTabs.size() > 1) {
			TestBase.test.log(LogStatus.INFO, "Tab size is more than 1: " + cICOAppointmentLogPageLocators.checkInTabs.size());
			Log.info("Tab size is more than 1: " + cICOAppointmentLogPageLocators.checkInTabs.size());

			for(int tabs = 0; tabs<cICOAppointmentLogPageLocators.tabCloseBtn.size(); tabs++) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.tabCloseBtn.get(tabs));
			}
		}
	}
	public void logoutFromApp() {
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL") + "/checkin");
		this.closeTab();
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byMsgContainer);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dotMenuBtn);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.logoutBtn);
		TestBase.test.log(LogStatus.INFO, "Logout button is clicked");
		Log.info("Logout button is clicked");
	}
	
	public void increasePageSize() {
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDown);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDownOpt.get(cICOAppointmentLogPageLocators.dropDownOpt.size()-1));
		TestBase.test.log(LogStatus.INFO, "Page size is increased");
		Log.info("Page size is increased");
	}
	public void allAppointments() {
		if(CommonUtil.getAttributeOfEle(cICOAppointmentLogPageLocators.allApp, "aria-checked").equalsIgnoreCase("false")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.allApp);
			TestBase.test.log(LogStatus.INFO, "All Appointments checkbox is selected");
			Log.info("All Appointments checkbox is selected");			
		}else {
			TestBase.test.log(LogStatus.INFO, "All Appointments checkbox is already selected");
			Log.info("All Appointments checkbox is already selected");	
		}
	}

	public void clickCSSAppointmentLogPageCheckIn(String val) {
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL") + "/checkin");
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		CommonUtil.sleep(2000);
		this.increasePageSize();
		
		this.allAppointments(); // comment it if data refresh happening everyday
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		
//		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 1);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDown);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDownOpt.get(cICOAppointmentLogPageLocators.dropDownOpt.size()));

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.checkInActionBtn.get(0));
		TestBase.test.log(LogStatus.INFO, "User has clicked on action button");

		for (int actOpt = 0; actOpt < cICOAppointmentLogPageLocators.checkInActionOptionBtnText.size(); actOpt++) {
			String actVal = CommonUtil
					.getTextOfEle(cICOAppointmentLogPageLocators.checkInActionOptionBtnText.get(actOpt));

			if (actVal.contains(val)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOAppointmentLogPageLocators.checkInActionOptionBtn.get(actOpt));
				TestBase.test.log(LogStatus.INFO, "User has clicked on CSS action button");
				break;
			}
		}
		TestBase.cICOClientServicesScreenPageActions = TestBase.cICOClientServicesScreenPageActionsObject();
	}

	public void checkInSavePostValidation() {
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		CommonUtil.sleep(2000);
		String dateVal = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkInDateCol.get(CICOAppointmentLogPageActions.saveRow + 1));

		Assert.assertTrue(dateVal.equals(""), dateVal + " should be empty");
		
		TestBase.test.log(LogStatus.INFO, "CheckIn Save Post Validation is successful");
		Log.info("CheckIn Save Post Validation is successful");
	}

	public void clickCheckInAppointmentLogPageCheckIn(String actionButtonText) {
		String actBtnLogoTxt = "today";
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL") + "/checkin");
		this.closeTab();
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		CommonUtil.sleep(2000);
		this.increasePageSize();
		this.allAppointments();
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDown);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDownOpt.get(cICOAppointmentLogPageLocators.dropDownOpt.size()));

		boolean bool = false;

		// Date Col starts from header row but Action Col starts from row 1
		for (int dateCol = 1; dateCol < cICOAppointmentLogPageLocators.checkInDateCol.size(); dateCol++) {
			String dateVal = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkInDateCol.get(dateCol));
			checkInPageClientName = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkPageClientName.get(dateCol));
			appointmentType = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.appointmentType.get(dateCol));
			caseNumber = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.caseNumCol.get(dateCol));
			clientRow = dateCol - 1;
			saveRow = dateCol - 1;

			if (dateVal.equals("")) {
				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cICOAppointmentLogPageLocators.checkInActionBtn.get(dateCol - 1));
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOAppointmentLogPageLocators.checkInActionBtn.get(dateCol - 1));

				// Doesn't have any header for Action Col
				for (int actionCol = 0; actionCol < cICOAppointmentLogPageLocators.checkInActionOptionBtnText.size(); actionCol++) {

					if (CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkInActionOptionBtnText.get(actionCol)).contains(actBtnLogoTxt)) {
						Log.info("Client Name: '" + checkInPageClientName + "'");
						Log.info("Appointment Type: " + appointmentType);
						CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.checkInActionOptionBtn.get(actionCol));
						TestBase.test.log(LogStatus.INFO, "User has clicked on " + actionButtonText + " action button");
						bool = true;
						break;
					} else if (actionCol == cICOAppointmentLogPageLocators.checkInActionOptionBtnText.size() - 1
							&& bool == false) {
						Assert.assertTrue(false, "No '" + actionButtonText + "' action option is available");
					}
				}
			} else {
				if (dateCol == cICOAppointmentLogPageLocators.checkInDateCol.size() - 1) {
					TestBase.test.log(LogStatus.INFO, "No '" + actionButtonText + "' option available");
					Log.info("No " + actionButtonText + "' option available");
				}
				continue;
			}

			if (bool == true) {
				break;
			}
		}
		TestBase.cICODetailsPageActions = TestBase.cICODetailsPageActionsObject();
		
	}

	public void clickReScheduleFromAppointmentLogPage(String actionButtonText) {
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL") + "/checkin");
		this.closeTab();
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		CommonUtil.sleep(2000);
		this.increasePageSize();
		
		this.allAppointments(); // comment it if data refresh happening everyday
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2); //header is available while refreshing
		
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDown);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDownOpt.get(cICOAppointmentLogPageLocators.dropDownOpt.size()));

		boolean bool = false;

		// Date Col starts from header row but Action Col starts from row 1
		for (int checkOutCol = 1; checkOutCol < cICOAppointmentLogPageLocators.checkOutDateCol.size(); checkOutCol++) {
			String checkOutColVal = CommonUtil
					.getTextOfEle(cICOAppointmentLogPageLocators.checkOutDateCol.get(checkOutCol));

			if (checkOutColVal.equals("")) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cICOAppointmentLogPageLocators.checkInActionBtn.get(checkOutCol - 1)); // Doesn't have any
																								// header for Action Col

				for (int actionCol = 0; actionCol < cICOAppointmentLogPageLocators.checkInActionOptionBtnText
						.size(); actionCol++) {

					if (CommonUtil
							.getTextOfEle(cICOAppointmentLogPageLocators.checkInActionOptionBtnText.get(actionCol))
							.contains(actionButtonText)) {
						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								cICOAppointmentLogPageLocators.checkInActionOptionBtn.get(actionCol));
						bool = true;
						break;
					} else if (actionCol == cICOAppointmentLogPageLocators.checkInActionOptionBtnText.size() - 1
							&& bool == false) {
						Assert.assertTrue(false, "No '" + actionButtonText + "' action option is available");
					}
				}
			} else {
				if (checkOutCol == cICOAppointmentLogPageLocators.checkOutDateCol.size() - 1) {
					TestBase.test.log(LogStatus.INFO, "No '" + actionButtonText + "' Appointment option available");
					Log.info("No '" + actionButtonText + "' Appointment option available");
				}
				continue;
			}

			if (bool == true) {
				break;
			}
		}

		TestBase.cICOReSchedulePageActions = TestBase.cICOReSchedulePageActionsObject();
	}

	public void verifyClientLandedOnAppLogPage(String headerText) {
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty("baseURL") + "/checkin");
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		CommonUtil.verifyPageHeader(headerText, cICOAppointmentLogPageLocators.checkInAppointmentLogPageHeader);
	}

	public void verifyPostCheckInFromAppointmentLogScreen(String actionBtnName) {
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol, 2);
		CommonUtil.sleep(2000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.checkInActionBtn.get(CICOAppointmentLogPageActions.clientRow));
		for (int actionCol = 0; actionCol < cICOAppointmentLogPageLocators.checkInActionOptionBtnText.size(); actionCol++) {

			if(CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkInActionOptionBtnText.get(actionCol)).contains(actionBtnName)) {
				Assert.assertTrue(cICOAppointmentLogPageLocators.checkInActionOptionBtnText.get(actionCol).isDisplayed(), "Check-In Action Button should not be available");
			}
		}
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.checkInActionBtn.get(CICOAppointmentLogPageActions.clientRow));
	}

	public void verifyAppointmentChronologicalOrder() {
		Date dOne = null;
		Date dTwo = null;
		String txtOne = null;
		String txtTwo = null;

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byAppointmentDateCol,
				2);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDown);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.dropDownOpt.get(1));

		List<WebElement> listOfDate = cICOAppointmentLogPageLocators.appointmentDateCol;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");

		for (int date = 1; date < listOfDate.size() - 1; date++) {
			txtOne = CommonUtil.getTextOfEle(listOfDate.get(date));
			txtTwo = CommonUtil.getTextOfEle(listOfDate.get(date + 1));

			try {
				dOne = sdf.parse(txtOne);
				dTwo = sdf.parse(txtTwo);
			} catch (ParseException e) {
				e.printStackTrace();
				Assert.assertTrue(false, "No Appointment date is available");
			}

			if (dOne.compareTo(dTwo) == 0 || dOne.compareTo(dTwo) == -1) {
				continue;
			} else {
				Assert.assertTrue(false, "'Appointment dates' are not in chronological order");
				break;
			}
		}
		TestBase.test.log(LogStatus.INFO, "'Appointment dates' are in chronological order");
		Log.info("'Appointment dates' are in chronological order");
	}

	public void filterClientName() {
		String[] filter = { "Equals", "Not equal", "Starts with", "Ends with", "Contains", "Not contains" };

		for (int i = 0; i < filter.length; i++) {
			String cName = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.clientNameCol.get(1));
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.burgerMenu.get(0));
			CommonUtil.selectEleFromDropDown(cICOAppointmentLogPageLocators.filterDrpDwn)
					.selectByVisibleText(filter[i]);
			CommonUtil.inputKeysToEle(cICOAppointmentLogPageLocators.filterTxt, cName);

			CommonUtil.sleep(2000);
			String equalName = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.clientNameCol.get(1));

			if (equalName.equals(cName) && filter[i].contains("Not")) {
				TestBase.test.log(LogStatus.INFO, filter[i] + ": " + cName + " != " + equalName);
				Log.info(filter[i] + ": " + cName + " != " + equalName);
				Assert.assertTrue(!equalName.equals(cName), "Client name should not match");
			}
		}
		TestBase.test.log(LogStatus.INFO, "'Client name' column filter is validated");
		Log.info("'Client name' column filter is validated");
		CommonUtil.sleep(1000);

		CommonUtil.inputKeysToEle(cICOAppointmentLogPageLocators.filterTxt, "");
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.arrowMenu);
	}

	public void filterWMSCase() {
		String[] filter = { "Equals", "Not equal", "Starts with", "Ends with", "Contains", "Not contains" };

		for (int i = 0; i < filter.length; i++) {
			String caseNum = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.caseNumCol.get(1));
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.burgerMenu.get(1));
			TestBase.test.log(LogStatus.INFO, "User cliked on filter icon");
			CommonUtil.selectEleFromDropDown(cICOAppointmentLogPageLocators.filterDrpDwn)
					.selectByVisibleText(filter[i]);
			CommonUtil.inputKeysToEle(cICOAppointmentLogPageLocators.filterTxt, caseNum);
			TestBase.test.log(LogStatus.INFO, "User entered WMS Case number");

			CommonUtil.sleep(2000);
			String equalCaseNum = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.caseNumCol.get(1));

			if (equalCaseNum.equals(caseNum) && filter[i].contains("Not")) {
				TestBase.test.log(LogStatus.INFO, filter[i] + ": " + caseNum + " != " + equalCaseNum);
				Log.info(filter[i] + ": " + caseNum + " != " + equalCaseNum);
				Assert.assertTrue(false, "'WMS Case' should not match");
			}
		}
		TestBase.test.log(LogStatus.INFO, "'WMS Case' column filter is validated");
		Log.info("'WMS Case' column filter is validated");
		CommonUtil.sleep(1000);

		CommonUtil.inputKeysToEle(cICOAppointmentLogPageLocators.filterTxt, "");
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.arrowMenu);
	}

	public void filterAppointmentType() {
		String appointmentType = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.appointmentType.get(1));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.burgerMenu.get(3));
		TestBase.test.log(LogStatus.INFO, "User clicked on filter icon");

		int count = 0;
		for (int i = 0; i < cICOAppointmentLogPageLocators.drpDwnChkBox.size(); i++) {
			String equalAppointmentType = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.drpDwnTxt.get(i));

			if (appointmentType.equals(equalAppointmentType)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.drpDwnChkBox.get(i));
				TestBase.test.log(LogStatus.INFO, "User clicked on " + appointmentType + " appointment type");
				break;
			}
			count++;
		}
		CommonUtil.sleep(2000);
		String postAppointmentType = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.appointmentType.get(1));
		Assert.assertTrue(!appointmentType.equals(postAppointmentType), "'Appointment Type' should not match");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.drpDwnChkBox.get(count));
		TestBase.test.log(LogStatus.INFO, "'Appointment Type' column filter is validated");
		Log.info("Appointment Type' column filter is validated");
		CommonUtil.sleep(1000);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.arrowMenu);
	}

	public void filterAssignedTo() {
		String assignedTo = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkInAssignedToCol.get(1));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.burgerMenu.get(6));
		TestBase.test.log(LogStatus.INFO, "User clicked on filter icon");

		int count = 0;
		for (int i = 0; i < cICOAppointmentLogPageLocators.drpDwnChkBox.size(); i++) {
			String equalAssignedTo = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.drpDwnTxt.get(i));

			if (assignedTo.equals("")) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.drpDwnChkBox.get(0)); // for
																														// Blank
																														// Option
			} else if (assignedTo.equals(equalAssignedTo)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.drpDwnChkBox.get(i));
				break;
			}
			count++;
		}
		CommonUtil.sleep(2000);

		String postAssignedTo = "";
		try {
			postAssignedTo = CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.checkInAssignedToCol.get(1));
		} catch (IndexOutOfBoundsException e) {
			Log.info(e.getMessage());
		}
		Assert.assertTrue(!assignedTo.equals(postAssignedTo), "'Assigned To' name should not match");

		if (assignedTo.equals("")) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.drpDwnChkBox.get(0));
		} else {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.drpDwnChkBox.get(count));
		}
		TestBase.test.log(LogStatus.INFO, "'Assigned To' column filter is validated");
		Log.info("'Assigned To' column filter is validated");

		CommonUtil.sleep(1000);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOAppointmentLogPageLocators.arrowMenu);
	}

	public void verifyAppointmentType(List<String> appointmentType) {

		for (int type = 1; type < cICOAppointmentLogPageLocators.appointmentType.size(); type++) {
			boolean match = appointmentType
					.contains(CommonUtil.getTextOfEle(cICOAppointmentLogPageLocators.appointmentType.get(type)));
			Assert.assertTrue(match, "'Appointment type' doesn't match with excel");
		}
		TestBase.test.log(LogStatus.INFO, "'Appointment type' matches with excel");
		Log.info("'Appointment type' matches with excel");
	}

	public void clickAllAppointments() {

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOAppointmentLogPageLocators.byMsgContainer);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOAppointmentLogPageLocators.label_AllAppointments);

		try {
			if (cICOAppointmentLogPageLocators.label_AllAppointments.isDisplayed()) {

				boolean AllAppointments_Checked_Initial = CommonUtil.isElementPresent(TestBase.getDriver(),
						cICOAppointmentLogPageLocators.byvalidate_CheckBox_AA);

				if (AllAppointments_Checked_Initial) {
					TestBase.test.log(LogStatus.INFO, "All Appointments checkbox is already selected");
					Log.info("All Appointments checkbox is already selected");
				}

				else {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOAppointmentLogPageLocators.checkbox_AllAppointments);

					CommonUtil.sleep(2000);

					boolean AllAppointments_Checked = CommonUtil.isElementPresent(TestBase.getDriver(),
							cICOAppointmentLogPageLocators.byvalidate_CheckBox_AA);

					if (AllAppointments_Checked) {
						TestBase.test.log(LogStatus.INFO, "All Appointments checkbox is selected");
						Log.info("All Appointments checkbox is selected");
					} else {
						TestBase.test.log(LogStatus.INFO, "All Appointments checkbox is not selected");
						Log.info("All Appointments checkbox is not selected");
					}
				}
			}
		} catch (NoSuchElementException AA) {
			TestBase.test.log(LogStatus.INFO, "All Appointments checkbox is not available");
			Log.info("All Appointments checkbox is not available");
		}

	}

}
