package pageObject.CICOModule;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOAppointmentsToSchedulePageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CICOAppointmentsToSchedulePageActions {

	private static CICOAppointmentsToSchedulePageLocators cICOAppointmentsToSchedulePageLocators = null;
	public static String ATS_nameToValidate = null;
	public static String ATS_caseNumberToValidate = null;
	public static String ATS_appointmentType = null;
	
	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public CICOAppointmentsToSchedulePageActions() {

		CICOAppointmentsToSchedulePageActions.cICOAppointmentsToSchedulePageLocators = new CICOAppointmentsToSchedulePageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOAppointmentsToSchedulePageLocators);

	}

	public void getDetailsofCheckedInUser() {

		ATS_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		ATS_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		ATS_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
	}

	public void appointmentToSchedule() {
		
		CommonUtil.sleep(2000);

		if (ATS_nameToValidate == null) {
			Log.info("No records are available to be checked out");
		} else {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cICOAppointmentsToSchedulePageLocators.header_CarFare_History);

			Assert.assertTrue(cICOAppointmentsToSchedulePageLocators.header_CarFare_History.isDisplayed());

			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cICOAppointmentsToSchedulePageLocators.text_AppointmentToSchedule);
			TestBase.test.log(LogStatus.INFO, "Appointment to schedule is clicked");
			Log.info("Appointment to schedule is clicked");

			try {
				boolean appointmentexists = cICOAppointmentsToSchedulePageLocators.text_NoAppointments.isDisplayed();

				if (appointmentexists) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cICOAppointmentsToSchedulePageLocators.checkbox_NoAppointments);
					TestBase.test.log(LogStatus.INFO, "No Appointments check box is clicked");
					Log.info("No Appointments check box is clicked");
				} else {
					TestBase.test.log(LogStatus.INFO, "No Appointments check box is not clicked");
					Log.info("No Appointments check box is not clicked");
				}
			} catch (NoSuchElementException e) {
				TestBase.test.log(LogStatus.INFO,
						"No Appointments check box is not available as the user already may have appointments");
				Log.info("No Appointments check box is not available as the user already may have appointments");
			}

		}
	}

}
