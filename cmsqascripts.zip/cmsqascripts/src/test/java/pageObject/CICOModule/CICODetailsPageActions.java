package pageObject.CICOModule;

import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Test;

import pageModel.CICOModule.CICODetailsPageLocators;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;
import pageTest.TestBase;


public class CICODetailsPageActions {
	
	CICODetailsPageLocators cICODetailsPageLocators = null;
	
	public CICODetailsPageActions() {
		this.cICODetailsPageLocators = new CICODetailsPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICODetailsPageLocators);
	}
	
	public void clientLandedOnCheckInScreen(String screenName) {
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICODetailsPageLocators.byCheckInRaRadioOptions, 1);
		CommonUtil.sleep(2000);
		CommonUtil.verifyPageHeader(screenName, cICODetailsPageLocators.checkInHeader);
		TestBase.test.log(LogStatus.INFO, "Check-In page header is verified");
		Log.info("Check-In page header is verified");
	}
	
	public void uploadCheckInDoc() {
		String filePath = System.getProperty("user.dir")+"/src/test/resources/App_Letter.pdf";
		//click side menu
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.sideMenu);
		TestBase.test.log(LogStatus.INFO, "Upload sidemenu is clicked");
		Log.info("Upload sidemenu is clicked");
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICODetailsPageLocators.uplHeader);
		CommonUtil.sleep(2000);
		CommonUtil.inputKeysToEle(cICODetailsPageLocators.fileBtn, filePath);
		CommonUtil.sleep(2000);
		TestBase.test.log(LogStatus.INFO, "File is chosen");
		Log.info("File is chosen");
		CommonUtil.selectEleFromDropDown(cICODetailsPageLocators.selectType).selectByIndex(1);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.uploadBtn.get(0));
		TestBase.test.log(LogStatus.INFO, "File is uploaded");
		Log.info("File is uploaded");
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICODetailsPageLocators.toastMsg.get(0));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.dynamicTabsClose.get(1));
		TestBase.test.log(LogStatus.INFO, "Upload tab is closed");
		Log.info("Upload tab is closed");
		//post validation
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.dynamicTabs.get(0));
		TestBase.test.log(LogStatus.INFO, "CICO tab is clicked");
		Log.info("CICO tab is clicked");
		//wait for check in page
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICODetailsPageLocators.byCheckInRaRadioOptions, 1);
		//click side menu
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.sideMenu);
		TestBase.test.log(LogStatus.INFO, "Upload sidemenu is clicked");
		Log.info("Upload sidemenu is clicked");
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICODetailsPageLocators.uplHeader);
		CommonUtil.sleep(2000);
		try {			
			Assert.assertTrue(cICODetailsPageLocators.uplSubHeader.isDisplayed(), "Uploaded Doc is not present");
		} catch(NoSuchElementException e) {
			Log.info("Upload Header is not found");
		}
		//Tear down
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.dynamicTabsClose.get(1));
		TestBase.test.log(LogStatus.INFO, "Upload tab is closed");
		Log.info("Upload tab is closed");
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.dynamicTabs.get(0));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.dynamicTabsClose.get(0));
		TestBase.test.log(LogStatus.INFO, "CICO tab is closed");
		Log.info("CICO tab is closed");
	}
	
	public void saveCheckInDetails() {
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInBtns.get(1));
		TestBase.test.log(LogStatus.INFO, "User has clicked on save button");
		Log.info("User has clicked on save button");
//		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICODetailsPageLocators.errToastMsg.get(0));
//		CommonUtil.waitDriverUntilElementIsInvisible(TestBase.getDriver(), cICODetailsPageLocators.errToastMsg.get(0));	
	}
	
	public void checkInWithoutChoosingAnyOption() {
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInBtns.get(0));
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICODetailsPageLocators.errToastMsg.get(0));
		
		Assert.assertEquals("Please fill out all required fields", CommonUtil.getTextOfEle(cICODetailsPageLocators.errToastMsg.get(0)), "Unable to get the toast message");
		TestBase.test.log(LogStatus.INFO, "'"+CommonUtil.getTextOfEle(cICODetailsPageLocators.errToastMsg.get(0))+"' toast message is displayed");
		Log.info("'"+CommonUtil.getTextOfEle(cICODetailsPageLocators.errToastMsg.get(0))+"' toast message is displayed");
		CommonUtil.waitDriverUntilElementIsInvisible(TestBase.getDriver(), cICODetailsPageLocators.errToastMsg.get(0));
	}
	
	public void checkInWithoutChoosingOneOption() {
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInRaRadioOptions.get(1));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInBtns.get(0));
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICODetailsPageLocators.errToastMsg.get(0));
		
		Assert.assertEquals("Please fill out all required fields", CommonUtil.getTextOfEle(cICODetailsPageLocators.errToastMsg.get(0)), "Unable to get the toast message");
		TestBase.test.log(LogStatus.INFO, "'"+CommonUtil.getTextOfEle(cICODetailsPageLocators.errToastMsg.get(0))+"' toast message is displayed");
		Log.info("'"+CommonUtil.getTextOfEle(cICODetailsPageLocators.errToastMsg.get(0))+"' toast message is displayed");
		CommonUtil.waitDriverUntilElementIsInvisible(TestBase.getDriver(), cICODetailsPageLocators.errToastMsg.get(0));
	}
	
	public void chooseCheckInRADetailsRadioOption(String optionText) {	
		
		if(optionText.equalsIgnoreCase("Yes")) {
			WebElement raYes = cICODetailsPageLocators.checkInRaRadioOptions.get(0);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), raYes);
			TestBase.test.log(LogStatus.INFO, "Client has chosen '"+optionText+"' for RA option");
			Log.info("Client has chosen '"+optionText+"' for RA option");
		}
		else if(optionText.equalsIgnoreCase("No")) {
			WebElement raNa = cICODetailsPageLocators.checkInRaRadioOptions.get(1);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), raNa);
			TestBase.test.log(LogStatus.INFO, "Client has chosen '"+optionText+"' for RA option");
			Log.info("Client has chosen '"+optionText+"' for RA option");
		}
	}
	
	public void chooseCheckInRADetailsCheckboxOption(String checkboxText) {
		
		for(int checkBox=0; checkBox<cICODetailsPageLocators.checkInRaCheckbox.size(); checkBox++) {
			String checkBoxVal = CommonUtil.getTextOfEle(cICODetailsPageLocators.checkInRaCheckboxText.get(checkBox));
			
			if(checkBoxVal.equalsIgnoreCase(checkboxText) && !cICODetailsPageLocators.checkInRaCheckbox.get(checkBox).isSelected()) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInRaCheckbox.get(checkBox));
				TestBase.test.log(LogStatus.INFO, "Client has chosen '"+checkBoxVal+"' for RA checkbox");
				Log.info("Client has chosen '"+ checkBoxVal +"' for RA checkbox");
			}
			else if(checkBoxVal.equalsIgnoreCase(checkboxText) && cICODetailsPageLocators.checkInRaCheckbox.get(checkBox).isSelected()) {
				TestBase.test.log(LogStatus.INFO, "Client has chosen '"+checkBoxVal+"' for RA checkbox");
				Log.info("Client has chosen '"+ checkBoxVal +"' for RA checkbox");
			}
		}
	}
	
	public void chooseCheckInRADetailsDocRadioOption(String optionText) {
		
		if(optionText.equalsIgnoreCase("Yes")) {
			WebElement docYes = cICODetailsPageLocators.checkInRaRadioOptions.get(2);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), docYes);
			TestBase.test.log(LogStatus.INFO, "Client has chosen '"+optionText+"' for document option");
			Log.info("Client has chosen '"+optionText+"' for Document option");
		}
		else if(optionText.equalsIgnoreCase("No")) {
			WebElement docNa = cICODetailsPageLocators.checkInRaRadioOptions.get(3);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), docNa);
			TestBase.test.log(LogStatus.INFO, "Client has chosen '"+optionText+"' for document option");
			Log.info("Client has chosen '"+optionText+"' for Document option");
		}
	}
	
	public void addCheckInRADetailsDocInfo(String docTypeName, String pageCount) {
		
		if(cICODetailsPageLocators.checkInDocBtn.size() < 2) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInDocBtn.get(0));
		}
		
		int docInfoRowSize = cICODetailsPageLocators.checkInDocType.size();
		List<WebElement> docTypeList = CommonUtil.selectEleFromDropDown(cICODetailsPageLocators.checkInDocType.get(docInfoRowSize-1))
														.getOptions();
			
		for(int docType=0; docType<docTypeList.size(); docType++) {
			String docTypeVal = CommonUtil.getTextOfEle(docTypeList.get(docType));
		
			if(docTypeName.equalsIgnoreCase(docTypeVal)) {
				CommonUtil.selectEleFromDropDown(cICODetailsPageLocators.checkInDocType.get(docInfoRowSize-1)).selectByVisibleText(docTypeName);
//				CommonUtil.clickEleJsExec(TestBase.getDriver(), docTypeList.get(docType));
				CommonUtil.inputKeysToEle(cICODetailsPageLocators.checkInDocPage.get(docInfoRowSize-1), pageCount);
				TestBase.test.log(LogStatus.INFO, "Client has chosen '"+docTypeVal+"' document Type");
				Log.info("Client has chosen '"+docTypeVal+"' document Type");
				break;
			}
			else {
				continue;
			}
		}

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICODetailsPageLocators.checkInBtns.get(1));

	}
	
	
	
}
