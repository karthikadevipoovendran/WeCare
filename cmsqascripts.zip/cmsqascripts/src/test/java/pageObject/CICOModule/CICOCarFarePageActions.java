package pageObject.CICOModule;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOCarFarePageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CICOCarFarePageActions {

	private static CICOCarFarePageLocators cICOCarFarePageLocators = null;
	public static String CF_nameToValidate = null;
	public static String CF_caseNumberToValidate = null;
	public static String CF_appointmentType = null;
	public static boolean CF_issuanceDateExists = false;
	public static boolean CF_issuanceReasonExists = false;
	public static boolean CF_issuanceAmountExists = false;
	public static boolean CF_cardNumberExists = false;

	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();
	CICOCheckoutPageActions Checkout_Actions = new CICOCheckoutPageActions();
	
	public CICOCarFarePageActions() {

		CICOCarFarePageActions.cICOCarFarePageLocators = new CICOCarFarePageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOCarFarePageLocators);

	}
	
	public void getDetailsOfUserToCheckOut() {
		
		CF_nameToValidate = CICOCheckoutPageActions.CO_nameToValidate;
		CF_caseNumberToValidate = CICOCheckoutPageActions.CO_caseNumberToValidate;
		CF_appointmentType = CICOCheckoutPageActions.CO_appointmentType;
	}

	public void getDetailsofCheckedInUser() {

		CF_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		CF_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		CF_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
	}

	public void cancelCarFare(String cardNumber) {
		
		CommonUtil.sleep(2000);
		
		if (CF_nameToValidate == null) {
			TestBase.test.log(LogStatus.INFO, "Cannot perform cancel carfare as no records are available for check out");
			Log.info("Cannot perform cancel carfare as no records are available for check out");
		} else {

		/* Enter Car Fare details */

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.header_CarFare_History);

		Assert.assertTrue(cICOCarFarePageLocators.header_CarFare_History.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
		Log.info("User is in Car Fare History Page");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.option_CarFare);
		TestBase.test.log(LogStatus.INFO, "Car Fare Option is clicked");
		Log.info("Car Fare Option is clicked");

		CommonUtil.sleep(2000);

		try {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			TestBase.test.log(LogStatus.INFO, "Add button is clicked");
			Log.info("Add button is clicked");
		} catch (TimeoutException e2) {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			TestBase.test.log(LogStatus.INFO, "Add button is clicked");
			Log.info("Add button is clicked");
		}

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.input_CardNumber);
		CommonUtil.inputKeysToEle(cICOCarFarePageLocators.input_CardNumber, cardNumber);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.buttons.get(0));

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.todays_date);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.todays_date);
		
		//CommonUtil.sleep(1000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		Select IssuanceReason = new Select(cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		IssuanceReason.selectByIndex(1);

		//CommonUtil.sleep(1000);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		Select IssuanceAmount = new Select(cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		IssuanceAmount.selectByIndex(1);

		//CommonUtil.sleep(1000);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Cancel);
		TestBase.test.log(LogStatus.INFO, "Car Fare details are not saved");
		Log.info("Car Fare details are not saved");

		//CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.header_CarFare_History);

		Assert.assertTrue(cICOCarFarePageLocators.header_CarFare_History.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
		Log.info("User is in Car Fare History Page");

		}
	}

	public void cancelCarFareFromSignaturePad(String cardNumber) {
		
		if (CF_nameToValidate == null) {
			Log.info("No records are available to be checked out");
		} else {

		/* Enter Car Fare details */

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.header_CarFare_History);

		Assert.assertTrue(cICOCarFarePageLocators.header_CarFare_History.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
		Log.info("User is in Car Fare History Page");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.option_CarFare);
		TestBase.test.log(LogStatus.INFO, "Car Fare Option is clicked");
		Log.info("Car Fare Option is clicked");

		CommonUtil.sleep(2000);

		try {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			TestBase.test.log(LogStatus.INFO, "Add button is clicked");
			Log.info("Add button is clicked");
		} catch (TimeoutException e2) {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			TestBase.test.log(LogStatus.INFO, "Add button is clicked");
			Log.info("Add button is clicked");
		}

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.input_CardNumber);
		CommonUtil.inputKeysToEle(cICOCarFarePageLocators.input_CardNumber, cardNumber);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.buttons.get(0));

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.todays_date);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.todays_date);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		Select IssuanceReason = new Select(cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		IssuanceReason.selectByIndex(1);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.checkBoxes_Issuance.get(1));
		Select IssuanceAmount = new Select(cICOCarFarePageLocators.checkBoxes_Issuance.get(1));
		IssuanceAmount.selectByIndex(1);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Save.get(0));
		TestBase.test.log(LogStatus.INFO, "Car Fare details are saved");
		Log.info("Car Fare details are saved");

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.text_SignatureRequired);

		CommonUtil.sleep(4000);

		//CommonUtil.isElementPresent(TestBase.getDriver(), cICOCarFarePageLocators.byButtonElectronic);
		CommonUtil.isElementPresent(TestBase.getDriver(), cICOCarFarePageLocators.byButtonHandwritten);
		
		CommonUtil.sleep(4000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.buttons_carFare_sign.get(2));
		TestBase.test.log(LogStatus.INFO, "Option Handwritten Signature is selected");
		Log.info("Option Handwritten Signature is selected");
		
//		TestBase.test.log(LogStatus.INFO, "Option Electronic Signature is selected");
//		Log.info("Option Electronic Signature is selected");

		try {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Verify);
			TestBase.test.log(LogStatus.INFO, "Verify button is selected");
			Log.info("Verify button is selected");
		} catch (NoSuchElementException e) {
			TestBase.test.log(LogStatus.INFO, "Verify button is auto selected");
			Log.info("Verify button is auto selected");
		}

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.text_ClientSignatureCompleted);

		CommonUtil.sleep(3000);

		try {
//			if (cICOCarFarePageLocators.input_SignHere.isDisplayed()) {
//				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.input_SignHere);
//				CommonUtil.inputKeysToEle(cICOCarFarePageLocators.input_SignHere, "Susan");

			if(cICOCarFarePageLocators.button_FakeSign.isDisplayed()) {
				//CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Sign);
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_FakeSign);

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cICOCarFarePageLocators.text_UserSignature);
				TestBase.test.log(LogStatus.INFO, "User Signature is completed");
				Log.info("User Signature is completed");
			}
		} catch (NoSuchElementException e) {
			TestBase.test.log(LogStatus.INFO, "User Signature already exists");
			Log.info("User Signature already exists");

		}

	//	if (cICOCarFarePageLocators.button_SignaturePad_Cancel.size() > 0) {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cICOCarFarePageLocators.button_SignaturePad_Cancel);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_SignaturePad_Cancel);
			TestBase.test.log(LogStatus.INFO, "Cancel button is clicked in Signature Pad");
			Log.info("Cancel button is clicked in Signature Pad");
		//}

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Cancel);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Cancel);
		TestBase.test.log(LogStatus.INFO, "Car Fare details are not saved");
		Log.info("Car Fare details are not saved");

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCarFarePageLocators.byHeader_Car_Fare_History);

		Assert.assertTrue(cICOCarFarePageLocators.header_CarFare_History.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
		Log.info("User is in Car Fare History Page");

		/* To exit back to check-in/check-out screen */
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_carfare_close);
		TestBase.test.log(LogStatus.INFO, "Close button is clicked to take the user back to check in/check out page");
		Log.info("Close button is clicked to take the user back to check in/check out page");

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCarFarePageLocators.textCICO);
		TestBase.test.log(LogStatus.INFO, "User is now in check-in/check-out page");
		Log.info("User is now in check-in/check-out page");

		}
	}

	public void addCarFareValidation(String cardNumber) {
		
		if (CF_nameToValidate == null) {
			Log.info("No records are available to be checked out");
		} else {

		/* Enter Car Fare details */

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.header_CarFare_History);

		Assert.assertTrue(cICOCarFarePageLocators.header_CarFare_History.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
		Log.info("User is in Car Fare History Page");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.option_CarFare);
		TestBase.test.log(LogStatus.INFO, "Car Fare Option is clicked");
		Log.info("Car Fare Option is clicked");

		CommonUtil.sleep(2000);

		try {
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			TestBase.test.log(LogStatus.INFO, "Add button is clicked");
			Log.info("Add button is clicked");
		} catch (TimeoutException e2) {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Add);
			TestBase.test.log(LogStatus.INFO, "Add button is clicked");
			Log.info("Add button is clicked");
		}

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.input_CardNumber);
		CommonUtil.inputKeysToEle(cICOCarFarePageLocators.input_CardNumber, cardNumber);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.buttons.get(0));

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.todays_date);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.todays_date);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		Select IssuanceReason = new Select(cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		IssuanceReason.selectByIndex(1);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		Select IssuanceAmount = new Select(cICOCarFarePageLocators.checkBoxes_Issuance.get(0));
		IssuanceAmount.selectByIndex(1);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Save.get(0));
		TestBase.test.log(LogStatus.INFO, "Car Fare details are saved");
		Log.info("Car Fare details are saved");

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.text_SignatureRequired);

		CommonUtil.sleep(4000);

		//CommonUtil.isElementPresent(TestBase.getDriver(), cICOCarFarePageLocators.byButtonElectronic);

		//CommonUtil.sleep(4000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Handwritten);
		TestBase.test.log(LogStatus.INFO, "Option Handwritten Signature is selected");
		Log.info("Option Handwritten Signature is selected");

		try {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Verify);
			TestBase.test.log(LogStatus.INFO, "Verify button is selected");
			Log.info("Verify button is selected");
		} catch (NoSuchElementException e) {
			TestBase.test.log(LogStatus.INFO, "Verify button is auto selected");
			Log.info("Verify button is auto selected");
		}

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cICOCarFarePageLocators.text_ClientSignatureCompleted);

		CommonUtil.sleep(3000);

		try {
//			if (cICOCarFarePageLocators.input_SignHere.isDisplayed()) {
//				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.input_SignHere);
//				CommonUtil.inputKeysToEle(cICOCarFarePageLocators.input_SignHere, "Susan");

			if(cICOCarFarePageLocators.button_FakeSign.isDisplayed()) {
				//CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_FakeSign);
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_FakeSign);

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cICOCarFarePageLocators.text_UserSignature);
				TestBase.test.log(LogStatus.INFO, "User Signature is completed");
				Log.info("User Signature is completed");
			}
		} catch (NoSuchElementException e) {
			TestBase.test.log(LogStatus.INFO, "User Signature already exists");
			Log.info("User Signature already exists");

		}
		
		CommonUtil.sleep(3000);

		//CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Submit);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Submit);
		TestBase.test.log(LogStatus.INFO, "Submit button is clicked");
		Log.info("Submit button is clicked");

//		CommonUtil.sleep(2000);
//
//		/* Edit Car Fare Details */
//		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCarFarePageLocators.byHeader_Car_Fare_History);
//		TestBase.test.log(LogStatus.INFO, "CarFare successfully added");
//		Log.info("CarFare successfully added");
//
//		CommonUtil.sleep(2000);
		
//		//CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Edit.get(0));
//		
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.CarFareHistory_ActionButton);
//		
//		CommonUtil.sleep(3000);
//		
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.Edit);
//
//		//CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Edit.get(0));
//		TestBase.test.log(LogStatus.INFO, "Edit button is clicked");
//		Log.info("Edit button is clicked");
//		
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.CarFare_History_Edit);
//		TestBase.test.log(LogStatus.INFO, "Edit button is clicked again");
//		Log.info("Edit button is clicked again");
//		CommonUtil.sleep(1000);
//		
////		try {
////		if(cICOCarFarePageLocators.CarFareHistory_ActionButton.isDisplayed()) {
////			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.CarFareHistory_ActionButton);
////			CommonUtil.sleep(2000);
////			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.CarFare_History_Edit);
////			CommonUtil.sleep(2000);
////		}
////		}
////		catch(NoSuchElementException e1) {
////			
////		}
//
//		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.text_EditCarFare);
//
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.edit_checkBoxes_Issuance.get(0));
//		Select IssuanceReason1 = new Select(cICOCarFarePageLocators.edit_checkBoxes_Issuance.get(0));
//		IssuanceReason1.selectByIndex(2);
//
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.edit_checkBoxes_Issuance.get(0));
//		Select IssuanceAmount1 = new Select(cICOCarFarePageLocators.edit_checkBoxes_Issuance.get(0));
//		IssuanceAmount1.selectByIndex(2);
//
//		CommonUtil.sleep(2000);
//
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Save.get(1));
//		TestBase.test.log(LogStatus.INFO, "Car Fare details are edited and saved");
//		Log.info("Car Fare details are edited and saved");
//
//		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
//				cICOCarFarePageLocators.text_SignatureRequired);
//
//		CommonUtil.sleep(4000);
//
//		CommonUtil.isElementPresent(TestBase.getDriver(), cICOCarFarePageLocators.byButtonElectronic);
//
//		CommonUtil.sleep(4000);
//
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.buttons_carFare_sign.get(2));
//		TestBase.test.log(LogStatus.INFO, "Option Electronic Signature is selected");
//		Log.info("Option Electronic Signature is selected");
//
//		try {
//			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Verify);
//			TestBase.test.log(LogStatus.INFO, "Verify button is selected");
//			Log.info("Verify button is selected");
//		} catch (NoSuchElementException e) {
//			TestBase.test.log(LogStatus.INFO, "Verify button is auto selected");
//			Log.info("Verify button is auto selected");
//		}
//
//		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
//				cICOCarFarePageLocators.text_ClientSignatureCompleted);
//
//		CommonUtil.sleep(3000);
//
//		try {
//			if (cICOCarFarePageLocators.input_SignHere.isDisplayed()) {
//				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.input_SignHere);
//				CommonUtil.inputKeysToEle(cICOCarFarePageLocators.input_SignHere, "Susan");
//
//				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Sign);
//				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Sign);
//
//				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
//						cICOCarFarePageLocators.text_UserSignature);
//				TestBase.test.log(LogStatus.INFO, "User Signature is completed");
//				Log.info("User Signature is completed");
//			}
//		} catch (NoSuchElementException e) {
//			TestBase.test.log(LogStatus.INFO, "User Signature already exists");
//			Log.info("User Signature already exists");
//
//		}
//
//		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cICOCarFarePageLocators.button_Submit);
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_Submit);
//		TestBase.test.log(LogStatus.INFO, "Submit button is clicked");
//		Log.info("Submit button is clicked");
//
//		/* Validate car fare details */
//
//		CommonUtil.sleep(2000);
//
//		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCarFarePageLocators.byHeader_Car_Fare_History);
//
//		/* To validate the date */
//		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
//		Date date = new Date();
//		String date1 = dateFormat.format(date);
//
//		for (WebElement IssuanceDate : cICOCarFarePageLocators.column_IssuanceDate) {
//			if (IssuanceDate.getText().equalsIgnoreCase(date1)) {
//				CF_issuanceDateExists = true;
//				break;
//
//			} else {
//				continue;
//			}
//
//		}
//
//		if (CF_issuanceDateExists == true) {
//			TestBase.test.log(LogStatus.INFO, "Issuance date validated and it as expected");
//			Log.info("Issuance date validated and it as expected");
//		} else {
//			TestBase.test.log(LogStatus.INFO, "Issuance date could not be validated as it is not available");
//			Log.info("Issuance date could not be validated as it is not available");
//		}
//
//		/* To validate Issuance Reason */
//
//		String issuanceReason = "Clinical Re-Assessment";
//		for (WebElement IR : cICOCarFarePageLocators.column_IssuanceReason) {
//			if (IR.getText().contentEquals(issuanceReason)) {
//				CF_issuanceReasonExists = true;
//				break;
//
//			} else {
//				continue;
//			}
//
//		}
//
//		if (CF_issuanceReasonExists == true) {
//			TestBase.test.log(LogStatus.INFO, "Issuance Reason validated and it as expected");
//			Log.info("Issuance Reason validated and it as expected");
//		} else {
//			TestBase.test.log(LogStatus.INFO, "Issuance Reason could not be validated as it is not available");
//			Log.info("Issuance Reason could not be validated as it is not available");
//		}
//
//		/* To validate Issuance Amount */
//
//		String issuanceAmount = "$31";
//		for (WebElement IA : cICOCarFarePageLocators.column_IssuanceAmount) {
//			if (IA.getText().contentEquals(issuanceAmount)) {
//				CF_issuanceAmountExists = true;
//				break;
//
//			} else {
//				continue;
//			}
//
//		}
//
//		if (CF_issuanceAmountExists == true) {
//			TestBase.test.log(LogStatus.INFO, "Issuance Amount validated and it as expected");
//			Log.info("Issuance Amount validated and it as expected");
//		} else {
//			TestBase.test.log(LogStatus.INFO, "Issuance Amount could not be validated as it is not available");
//			Log.info("Issuance Amount could not be validated as it is not available");
//		}
//
//		/* To validate Card Number */
//
//		for (WebElement cardnumber : cICOCarFarePageLocators.column_CardNumber) {
//			if (cardnumber.getText().contentEquals(cardNumber)) {
//				CF_cardNumberExists = true;
//				break;
//
//			} else {
//				continue;
//			}
//
//		}
//
//		if (CF_cardNumberExists == true) {
//			TestBase.test.log(LogStatus.INFO, "Card Number validated and it as expected");
//			Log.info("Card Number validated and it as expected");
//		} else {
//			TestBase.test.log(LogStatus.INFO, "Card Number could not be validated as it is not available");
//			Log.info("Card Number could not be validated as it is not available");
//		}
//
		
		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cICOCarFarePageLocators.byHeader_Car_Fare_History);

		Assert.assertTrue(cICOCarFarePageLocators.header_CarFare_History.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
		Log.info("User is in Car Fare History Page");

		/* To exit back to check-in/check-out screen */
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_carfare_close);
		TestBase.test.log(LogStatus.INFO, "Close button is clicked to take the user back to check in/check out page");
		Log.info("Close button is clicked to take the user back to check in/check out page");

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCarFarePageLocators.textCICO);
		TestBase.test.log(LogStatus.INFO, "User is now in check-in/check-out page");
		Log.info("User is now in check-in/check-out page");

		
	}

}
	
	public void closeCarFareScreen() {
		
		try {
	
		if(CommonUtil.isElementPresent(TestBase.getDriver(),cICOCarFarePageLocators.bybutton_carfare_close)) {
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCarFarePageLocators.button_carfare_close);
			TestBase.test.log(LogStatus.INFO, "CarFare Screen was already displayed. Hence, it was closed");
			Log.info("CarFare Screen was already displayed. Hence, it was closed");
			
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cICOCarFarePageLocators.textCICO);
			TestBase.test.log(LogStatus.INFO, "User is now in check-in/check-out page");
			Log.info("User is now in check-in/check-out page");
			
		}
		
		}
		catch(NoSuchElementException e) {
			TestBase.test.log(LogStatus.INFO, "User is not already in the car fare page");
			Log.info("User is not already in the car fare page");
		}
	}
	
	
}
