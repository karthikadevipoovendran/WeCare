package pageObject.CICOModule;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CICOModule.CICOCheckoutPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CICOCheckoutPageActions {

	private static CICOCheckoutPageLocators cICOCheckoutPageLocators = null;
	public static String CO_nameToValidate = null;
	public static String CO_caseNumberToValidate = null;
	public static String CO_appointmentType = null;

	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public CICOCheckoutPageActions() {

		CICOCheckoutPageActions.cICOCheckoutPageLocators = new CICOCheckoutPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cICOCheckoutPageLocators);

	}

	public void getDetailsofCheckedInUser() {

		CO_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		CO_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		CO_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
	}

	public void checkOut() {

		//CICO_Common.increasePageSize("baseURL", "/checkin");

		if (CO_nameToValidate == null) {
			Log.info("No records are available to be checked out");
		} else {

			if (CommonUtil.isElementPresent(TestBase.getDriver(), cICOCheckoutPageLocators.byCheckOut)) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cICOCheckoutPageLocators.checkOut);
				TestBase.test.log(LogStatus.INFO, "Check-Out is clicked");
				Log.info("Check-Out is clicked successfully");

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cICOCheckoutPageLocators.header_CarFare_History);

				Assert.assertTrue(cICOCheckoutPageLocators.header_CarFare_History.isDisplayed());
				TestBase.test.log(LogStatus.INFO, "User is in Car Fare History Page");
				Log.info("User is in Car Fare History Page");

			}

		}
		
		
		TestBase.CICOAppointmentsToSchedulePageActions = TestBase.cICOAppointmentsToSchedulePageActionsObject();
		TestBase.CICOExitPackagePageActions = TestBase.cICOExitPackagePageActionsObject();

	}

}
