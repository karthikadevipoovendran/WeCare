package pageObject;

import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Test;

import pageModel.MenuBarLocators;
import testUtil.CommonUtil;
import testUtil.Log;
import pageTest.TestBase;

public class MenuBarActions {
	
	MenuBarLocators menuBarLocators = null;
			
	public MenuBarActions() {
		this.menuBarLocators = new MenuBarLocators();
		PageFactory.initElements(TestBase.getDriver(), menuBarLocators);
	}
	
	
	public void navigateToThePage(String pageName) {
		CommonUtil.clickEle(menuBarLocators.menuBar.get(0));
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), menuBarLocators.byMenuOption);

		for(int pName=0; pName<menuBarLocators.menuOption.size(); pName++) {
			String pageVal = CommonUtil.getTextOfEle(menuBarLocators.menuOption.get(pName));
			
			if(pageVal.contains(pageName)) {
				CommonUtil.clickEle(menuBarLocators.menuOption.get(pName));
				TestBase.test.log(LogStatus.INFO, "Client has navigated to '"+pageName+"'");
				Log.info("Client has navigated to '"+pageName+"'");
				break;
			}
		}
	}
	


	
}
