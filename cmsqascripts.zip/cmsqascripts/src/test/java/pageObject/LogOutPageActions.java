package pageObject;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import pageModel.LogOutPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;

public class LogOutPageActions {
	
	public LogOutPageLocators logOutPageLocators = null;
	
	public LogOutPageActions() {
		logOutPageLocators = new LogOutPageLocators();
		PageFactory.initElements(TestBase.getDriver(), logOutPageLocators);
	}
	
	public void clickMenuIcon() {
		CommonUtil.clickEle(logOutPageLocators.menuIcon.get(0));
	}
	public void clickLogOutBtn() {
//		CommonUtil.scrollIntoView(TestBase.getDriver(), logOutPageLocators.logOutBtn.get(logOutPageLocators.logOutBtn.size()));
		CommonUtil.clickEle(logOutPageLocators.logOutBtn.get(logOutPageLocators.logOutBtn.size()-1));
		Assert.assertTrue(logOutPageLocators.logOutToastMsg.isDisplayed(), "LogOut toast message is not displayed");
	}
	

}
