package pageObject.CAModule;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CAModule.CAReAssignCasePageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CAReAssignCasePageActions {

	public static CAReAssignCasePageLocators cAReAssignCasePageLocators = null;
	public static String RAC_nameToValidate = null;
	public static String RAC_caseNumberToValidate = null;
	public static String RAC_appointmentType = null;
	public static String RAC_CheckInDate = null;
	public static String RAC_CMSUser = null;

	public static String RAC_caseWorkerAssigned = null;
	public static String RAC_caseWorkerReAssigned = null;
	public static String RAC_caseWorkerDeAssigned = null;

	public static String RAC_Status = null;
	public static String RAC_StatusBeforeReAssign = null;
	public static String RAC_StatusAfterReAssign = null;

	public static int RAC_currentCaseLoad = 0;
	public static int RAC_futureCaseLoad = 0;
	public static int RAC_currentCaseLoadForNewCMSUser = 0;
	public static int RAC_futureCaseLoadForNewCMSUser = 0;
	public static int RAC_count = 0;
	public static int index = 0;

	CACaseAssignmentsCommonActions CA_Common = new CACaseAssignmentsCommonActions();

	public CAReAssignCasePageActions() {

		CAReAssignCasePageActions.cAReAssignCasePageLocators = new CAReAssignCasePageLocators();
		PageFactory.initElements(TestBase.getDriver(), cAReAssignCasePageLocators);

	} 

	public void getUserDetails() {

		RAC_nameToValidate = CACaseAssignmentsCommonActions.common_ClientName;
		RAC_caseNumberToValidate = CACaseAssignmentsCommonActions.common_CaseNumber;
		RAC_appointmentType = CACaseAssignmentsCommonActions.common_AppointmentType;
		RAC_CheckInDate = CACaseAssignmentsCommonActions.common_CheckInDate;
		RAC_CMSUser = CACaseAssignmentsCommonActions.common_CMSUser;
		RAC_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;

	}
 
	public void reassignUser() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAReAssignCasePageLocators.leftChevron);

		if (RAC_nameToValidate == null || CACaseAssignmentsCommonActions.common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO,"No checked in records. Cannot re-assign a CMS User");
			Log.info("No checked in records. Cannot re-assign a CMS User");
		} else {
 
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cAReAssignCasePageLocators.reAssign);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.reAssign);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
					cAReAssignCasePageLocators.header_caseWorkerName);

//			for (int Action = 0; Action <cAReAssignCasePageLocators.caseWorkerNameToAssign.size(); Action ++) {
//				
//				if(cAReAssignCasePageLocators.caseWorkerNameToAssign.get(Action).getText().contains(RAC_caseWorkerAssigned)) {
//					continue;
//				}
//				else {
//					RAC_caseWorkerReAssigned = cAReAssignCasePageLocators.caseWorkerNameToAssign.get(Action).getText();
//					
//					CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.header_timeelapsed);
//					
//					CommonUtil.clickEleJsExec(TestBase.getDriver(),
//							cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(Action));
//					
//					CommonUtil.sleep(2000);
//					break;
//					
//				}
//				
//			}
			
			if(cAReAssignCasePageLocators.caseWorkerNameToAssign.get(1).getText().contains(RAC_caseWorkerAssigned)) {
				RAC_caseWorkerReAssigned = cAReAssignCasePageLocators.caseWorkerNameToAssign.get(2).getText();
				index =2;
			}
			else {
				RAC_caseWorkerReAssigned = cAReAssignCasePageLocators.caseWorkerNameToAssign.get(1).getText();
				index =1;
			}
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.header_timeelapsed);

			if(cAReAssignCasePageLocators.caseWorkerNameToAssign.get(1).getText().contains(RAC_caseWorkerAssigned)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(2));
			}
			else {
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(1));
			}

			CommonUtil.scrollIntoView(TestBase.getDriver(), cAReAssignCasePageLocators.boxPrimaryCaseManager);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
					cAReAssignCasePageLocators.boxPrimaryCaseManager);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.boxPrimaryCaseManager);

			Select primaryCaseManagerValue = new Select(cAReAssignCasePageLocators.boxPrimaryCaseManager);
			primaryCaseManagerValue.selectByIndex(1);

			CommonUtil.scrollIntoView(TestBase.getDriver(), cAReAssignCasePageLocators.button_reassign);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.button_reassign);
//
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cAReAssignCasePageLocators.label_reassignCase);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.label_reassignCase);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cAReAssignCasePageLocators.CA_all_buttons.get(1));

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.CA_all_buttons.get(1));
			TestBase.test.log(LogStatus.INFO, "Case is re-assigned successfully to " + RAC_caseWorkerReAssigned);
			Log.info("Case is re-assigned successfully to " + RAC_caseWorkerReAssigned);

		}

	}
	
	public void reassignUserFromTimeline() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAReAssignCasePageLocators.leftChevron);

		if (RAC_nameToValidate == null || CACaseAssignmentsCommonActions.common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO,"No checked in records. Cannot re-assign a CMS User");
			Log.info("No checked in records. Cannot re-assign a CMS User");
		} else {
 
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cAReAssignCasePageLocators.reAssign);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.reAssign);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
					cAReAssignCasePageLocators.header_caseWorkerName);

			for (int Action = 0; Action <cAReAssignCasePageLocators.caseWorkerNameToAssign.size(); Action ++) {
				
				if(cAReAssignCasePageLocators.caseWorkerNameToAssign.get(Action).getText().contains(RAC_caseWorkerReAssigned)) {
					continue;
				}
				else {
					RAC_caseWorkerReAssigned = cAReAssignCasePageLocators.caseWorkerNameToAssign.get(Action).getText();
					
					CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.header_timeelapsed);
					
					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(Action));
					break;
					
				}
				
			}
			
//			if(cAReAssignCasePageLocators.caseWorkerNameToAssign.get(1).getText().contains(RAC_caseWorkerAssigned)) {
//				RAC_caseWorkerReAssigned = cAReAssignCasePageLocators.caseWorkerNameToAssign.get(2).getText();
//				index =2;
//			}
//			else {
//				RAC_caseWorkerReAssigned = cAReAssignCasePageLocators.caseWorkerNameToAssign.get(1).getText();
//				index =1;
//			}
//				
//			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.header_timeelapsed);
//
//			if(cAReAssignCasePageLocators.caseWorkerNameToAssign.get(1).getText().contains(RAC_caseWorkerAssigned)) {
//				CommonUtil.clickEleJsExec(TestBase.getDriver(),
//						cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(2));
//			}
//			else {
//				CommonUtil.clickEleJsExec(TestBase.getDriver(),
//						cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(1));
//			}

			CommonUtil.scrollIntoView(TestBase.getDriver(), cAReAssignCasePageLocators.boxPrimaryCaseManager);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
					cAReAssignCasePageLocators.boxPrimaryCaseManager);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.boxPrimaryCaseManager);

			Select primaryCaseManagerValue = new Select(cAReAssignCasePageLocators.boxPrimaryCaseManager);
			primaryCaseManagerValue.selectByIndex(1);

			CommonUtil.scrollIntoView(TestBase.getDriver(), cAReAssignCasePageLocators.button_reassign);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.button_reassign);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cAReAssignCasePageLocators.label_reassignCase);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.label_reassignCase);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cAReAssignCasePageLocators.CA_all_buttons.get(1));

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.CA_all_buttons.get(1));
			TestBase.test.log(LogStatus.INFO, "Case is re-assigned successfully to " + RAC_caseWorkerReAssigned);
			Log.info("Case is re-assigned successfully to " + RAC_caseWorkerReAssigned);

		}

	}
	
	public void validate_ReAssignModal() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAReAssignCasePageLocators.reAssign);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.reAssign);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAReAssignCasePageLocators.header_caseWorkerName);

		Assert.assertFalse(cAReAssignCasePageLocators.textbox_CurrentlyAssigned.isEnabled());
		TestBase.test.log(LogStatus.INFO, "Currently Assigned To text box is disabled as expected");
		Log.info("Currently Assigned To text box is disabled as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.textbox_AssignTo.getText().contains(""));
		TestBase.test.log(LogStatus.INFO, "Assign To text box is empty as expected");
		Log.info("Assign To text box is empty as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.text_CaseDetails.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Selected Cases option is displayed as expected");
		Log.info("Selected Cases option is displayed as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.value_CaseNumber.getText().contains(RAC_caseNumberToValidate));
		TestBase.test.log(LogStatus.INFO, "Case Number is displayed under selected cases as expected");
		Log.info("Case Number is displayed under selected cases as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.value_ClientName.getText().contains(RAC_nameToValidate));
		TestBase.test.log(LogStatus.INFO, "Client Name is displayed under selected cases as expected");
		Log.info("Client Name is displayed under selected cases as expected");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.checkbox_caseWorkerAssign.get(1));
		TestBase.test.log(LogStatus.INFO, "Checkbox for the case worker is selected as expected");
		Log.info("Checkbox for the case worker is selected as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.assignModal_CaseWorkerName.get(1).isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Case Worker name is displayed as expected");
		Log.info("Case Worker name is displayed as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.assignModal_CaseLoad.get(1).isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Case Load is displayed as expected");
		Log.info("Case Load is displayed as expected");

		Assert.assertTrue(cAReAssignCasePageLocators.assignModal_ApptPerDay.get(1).isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Today's appointments is displayed as expected");
		Log.info("Today's appointments is displayed as expected");

	}

	public void cancel_ReAssignModal() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAReAssignCasePageLocators.header_caseWorkerName);

		CommonUtil.scrollIntoView(TestBase.getDriver(), cAReAssignCasePageLocators.cancelButton);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAReAssignCasePageLocators.cancelButton);
		TestBase.test.log(LogStatus.INFO, "Cancel button in Assign Modal is clicked successfully");
		Log.info("Cancel button in Assign Modal is clicked successfully");

		CommonUtil.sleep(1000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAReAssignCasePageLocators.leftChevron);
		TestBase.test.log(LogStatus.INFO, "User is in Case Assignments page");
		Log.info("User is in Case Assignments page");

	}

}
