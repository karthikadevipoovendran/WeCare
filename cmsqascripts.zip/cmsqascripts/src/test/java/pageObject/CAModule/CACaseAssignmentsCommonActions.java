package pageObject.CAModule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CAModule.CACaseAssignmentsCommonLocators;
import pageObject.CICOModule.CICOCheckInCheckOutCommonActions;
import pageObject.MAModule.MAPageCommonActions;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;

public class CACaseAssignmentsCommonActions {

	public static CACaseAssignmentsCommonLocators cACaseAssignmentsCommonLocators = null;
	public static String common_ClientName = null;
	public static String common_CheckInDate = null;
	public static String common_CMSUser = null;
	public static String common_AppointmentType = null;
	public static String common_CaseNumber = null;
	public static boolean common_checkInSuccessfull = false;

	public static int common_currentCaseLoad = 0;
	public static int common_futureCaseLoad = 0;
	public static int common_currentCaseLoadForNewCMSUser = 0;
	public static int common_futureCaseLoadForNewCMSUser = 0;
	public static int common_count = 0;

	public static int common_currentAppointmentPerDay = 0;
	public static int common_futureAppointmentPerDay = 0;
	public static int common_currentAppointmentPerDayForNewCMSUser = 0;
	public static int common_futureAppointmentPerDayForNewCMSUser = 0;

	public static String common_caseWorkerAssigned = null;
	public static String common_caseWorkerToReassign = null;
	public static String common_caseWorkerReAssigned = null;
	public static String common_caseWorkerDeAssigned = null;

	public static String common_Status = null;
	public static String common_StatusBeforeAssign = null;
	public static String common_StatusAfterAssign = null;
	public static String common_StatusBeforeDeAssign = null;
	public static String common_StatusAfterDeAssign = null;
	public static String common_StatusBeforeReAssign = null;
	public static String common_StatusAfterReAssign = null;

	public static String common_StatusBeforeOpen = null;
	public static String common_StatusAfterOpen = null;

	public static int selectionCount = 0;
	public static int TimelineCount = 0;
	public static int AppointmentPerDay = 0;

	public static List<String> clientName = new ArrayList<String>();
	public static List<String> AppointmentType = new ArrayList<String>();
	public static List<String> apptDateTime_Base = new ArrayList<String>();
	public static List<String> apptDateTime_Timeline = new ArrayList<String>();
	public static List<String> CA_AppointmentType = Arrays.asList("Clinical Assessment", "Clinical Re-Assessment", "Medical Assessment", "Psychiatric Evaluation", "Wellness Initiation", "Child Care Return", "WeCARE Follow-up", "Wellness Follow-up", "VRS Initiation", "SSI Initiation");

	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public CACaseAssignmentsCommonActions() {

		CACaseAssignmentsCommonActions.cACaseAssignmentsCommonLocators = new CACaseAssignmentsCommonLocators();
		PageFactory.initElements(TestBase.getDriver(), cACaseAssignmentsCommonLocators);

	}

	/* Get details from CICO Check-In */

	public void getDetailsFromCICOCheckIn() {

		common_ClientName = CICOCheckInCheckOutCommonActions.common_ClientName;
		common_CheckInDate = CICOCheckInCheckOutCommonActions.common_CheckInDate;
		common_CMSUser = CICOCheckInCheckOutCommonActions.common_CMSUser;
		common_AppointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
		common_CaseNumber = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		common_checkInSuccessfull = CICOCheckInCheckOutCommonActions.common_checkInSuccessfull;
	}

	/* Get User Details from MA Module */

	public void getDetailsFromMA() {
		common_ClientName = MAPageCommonActions.MAC_nameToValidate;
		common_CheckInDate = MAPageCommonActions.MAC_CheckInDate;
		common_CMSUser = MAPageCommonActions.MAC_CMSUser;
		common_AppointmentType = MAPageCommonActions.MAC_appointmentType;
		common_CaseNumber = MAPageCommonActions.MAC_caseNumberToValidate;
		common_caseWorkerAssigned = MAPageCommonActions.MAC_caseWorkerAssigned;
		common_StatusBeforeOpen = MAPageCommonActions.MAC_StatusBeforeOpen;
	}

	public void getDetailsFromAssignCase() {
		common_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;
		common_caseWorkerToReassign = CAAssignCasePageActions.AC_caseWorkerToReassign;
	}

	/* Navigate to Case Assignments and Click on the appointment type */

	public void navigateToCA() {

		CommonUtil.sleep(2000);

		// Khaled -> Adding object of CAssignmentPage
		TestBase.cAPageActions = TestBase.cAPageActionsObject();

		CommonUtil.navigateTo(TestBase.driver, "http://dev.ewweb.prutechlab.com/cms/#/assignments");
		TestBase.test.log(LogStatus.INFO, "User has navigated to Case Assignments Page");
		Log.info("User has navigated to Case Assignments Page");

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
				cACaseAssignmentsCommonLocators.caseAssignmentsPageHeader);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
				cACaseAssignmentsCommonLocators.category1_ClinicalorReassessment);

		/* Select a category */

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			Log.info("No checked in records. Cannot proceed with assigning user");
		} else {

				
			for (int Action = 0; Action < cACaseAssignmentsCommonLocators.CaseAsignments_SideMenu.size(); Action++) {
				if (CA_AppointmentType.contains(common_AppointmentType)) {
					 
					if(cACaseAssignmentsCommonLocators.CaseAssignments_SideMenuText.get(Action).getText().contains(common_AppointmentType)) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.CaseAsignments_SideMenu.get(Action));
					TestBase.test.log(LogStatus.INFO,
							"Category - "
									+ cACaseAssignmentsCommonLocators.CaseAssignments_SideMenuText.get(Action).getText()
									+ " is selected");
					Log.info("Category - "
							+ cACaseAssignmentsCommonLocators.CaseAssignments_SideMenuText.get(Action).getText()
							+ " is selected");
					
					break;
					}
				}
			}

		}

	}

	public void navigateToCaseAssignmentsAndSelectAppointmentType(String configFileURL, String endPoint) {

		CommonUtil.sleep(2000);

		TestBase.cAPageActions = TestBase.cAPageActionsObject();

		//CommonUtil.navigateTo(TestBase.driver, "http://dev.ewweb.prutechlab.com/cms/#/assignments");
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);
		TestBase.test.log(LogStatus.INFO, "User has navigated to Case Assignments Page");
		Log.info("User has navigated to Case Assignments Page");

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
				cACaseAssignmentsCommonLocators.caseAssignmentsPageHeader);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
				cACaseAssignmentsCommonLocators.category1_ClinicalorReassessment);

		/* Select a category */

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			Log.info("No checked in records. Cannot proceed with assigning user");
		} else {

			outerloop: for (WebElement categories : cACaseAssignmentsCommonLocators.caseAssignmentsCategories) {

				switch (common_AppointmentType) {

				case "Clinical Assessment":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category1_ClinicalorReassessment);
					TestBase.test.log(LogStatus.INFO, "Category - Clinical / Re-assessment is selected");
					Log.info("Category - Clinical / Re-assessment is selected");

					break outerloop;

				case "Clinical Re-Assessment":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category1_ClinicalorReassessment);
					TestBase.test.log(LogStatus.INFO, "Category - Clinical / Re-assessment is selected");
					Log.info("Category - Clinical / Re-assessment is selected");

					break outerloop;

				case "Medical Assessment":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category2_RevieworMedical);
					TestBase.test.log(LogStatus.INFO, "Category - Medical is selected");
					Log.info("Category - Medical is selected");

					break outerloop;

				case "Psychiatric Evaluation":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category3_PsychiatricEvaluation);
					TestBase.test.log(LogStatus.INFO, "Category - Psychiatric Evaluation is selected");
					Log.info("Category - Psychiatric Evaluation is selected");

					break outerloop;

				case "Wellness Initiation":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category4_WellnessServiceInitiation);
					TestBase.test.log(LogStatus.INFO, "Category - Wellness Initiation is selected");
					Log.info("Category - Wellness Initiation is selected");

					break outerloop;

				case "Child Care Return":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category8_ChildCareReturn);
					TestBase.test.log(LogStatus.INFO, "Category - WeCare Return is selected");
					Log.info("Category - WeCare Return is selected");

					break outerloop;

				case "WeCARE Follow-up":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category1_ClinicalorReassessment);
					TestBase.test.log(LogStatus.INFO, "Category - Clinical / Re-assessment is selected");
					Log.info("Category - Clinical / Re-assessment is selected for the type WeCare Follow-up");

					break outerloop;

				case "Wellness Follow-up":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category7_WellnessFollowUp);
					TestBase.test.log(LogStatus.INFO, "Category - WeCARE Follow-up is selected");
					Log.info("Category - Wellness Follow-up is selected");

					break outerloop;

				case "VRS Initiation":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category6_VRSServiceInitiation);
					TestBase.test.log(LogStatus.INFO, "Category - VRS Initiation is selected");
					Log.info("Category - VRS Initiation is selected");

					break outerloop;

				case "SSI Initiation":

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.category5_SSIServiceInitiation);
					TestBase.test.log(LogStatus.INFO, "Category - SSI Initiation is selected");
					Log.info("Category - SSI Initiation is selected");

					break outerloop;

				}

			}

		}

	}

	public void increasePageSize_CaseAssignments() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		CommonUtil.sleep(3000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.dropdown_PageSize);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.dropdown_options.get(5));

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

	}

	/* Assign Case related scripts */

	public void validateCaseLoadBeforeAssign_AnyQHP() {

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot Validate");
			Log.info("No checked in records. Cannot Validate");
		} else {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.leftChevron);

			CommonUtil.sleep(1000);

			common_currentCaseLoad = Integer.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current Case Load for the CMS User to whom the client will be assigned is "
							+ common_currentCaseLoad);
			Log.info("Current Case Load for the CMS User to whom the client will be assigned is "
					+ common_currentCaseLoad);
		}
	}

	public void validateAppointmentPerDayBeforeAssign_AnyQHP() {

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot Validate");
			Log.info("No checked in records. Cannot Validate");
		} else {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.leftChevron);

			CommonUtil.sleep(2000);

			common_currentAppointmentPerDay = Integer
					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current no of appointments for the CMS User to whom the client will be assigned is "
							+ common_currentAppointmentPerDay);
			Log.info("Current no of appointments for the CMS User to whom the client will be assigned is "
					+ common_currentAppointmentPerDay);
		}
	}

	public void viewStatus() {
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Columns);
		
		CommonUtil.sleep(1000);
		
		if(cACaseAssignmentsCommonLocators.checkbox_menu_columns.size()==9) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_menu_columns.get(5));
			
			CommonUtil.sleep(1000);
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_menu_columns.get(7));
		}
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Columns);
		Log.info("Status column will now be displayed");
		
	}
	
	public void viewStatus_Updated() {
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Columns);
		
		CommonUtil.sleep(1000);
		
		if(cACaseAssignmentsCommonLocators.checkbox_menu_columns.size()==9) {
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_menu_columns.get(5));
			
			CommonUtil.sleep(1000);
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_menu_columns.get(4));
		}
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Columns);
		Log.info("Status column will now be displayed");
		
	}
	
	public void viewAssignedTo() {
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Columns);
		
		CommonUtil.sleep(1000);
		
		if(cACaseAssignmentsCommonLocators.checkbox_menu_columns.size()==9) {
	
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_menu_columns.get(1));
			
			CommonUtil.sleep(1000);
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_menu_columns.get(2));
			
			CommonUtil.sleep(1000);
			
			
		}
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Columns);
		Log.info("Assigned To column will now be displayed");
		
	}
	public void validateCaseLoadAfterAssign_AnyQHP() {

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot Validate");
			Log.info("No checked in records. Cannot Validate");
		} else {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.leftChevron);

			CommonUtil.sleep(3000);

			this.increasePageSize_CaseAssignments();

			common_futureCaseLoad = Integer.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Future Case Load for the CMS User to whom the client is assigned is " + common_futureCaseLoad);
			Log.info("Future Case Load for the CMS User to whom the client is assigned is " + common_futureCaseLoad);

			if (common_AppointmentType.contains("Clinical") || common_AppointmentType.contains("Medical")
					|| common_AppointmentType.contains("Psychiatric")) {

				Assert.assertTrue(common_futureCaseLoad == 0);
				TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
				Log.info("Case load is validated and is as expected");

			} else {

				if (common_AppointmentType.contains("Wellness Follow-up")) {
					Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				} else {
					Assert.assertTrue(common_futureCaseLoad > common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				}

			}
		}
	}

	public void validateAppointmentPerDayAfterAssign_AnyQHP() {

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot Validate");
			Log.info("No checked in records. Cannot Validate");
		} else {

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.leftChevron);

			CommonUtil.sleep(3000);

			this.increasePageSize_CaseAssignments();

			common_futureAppointmentPerDay = Integer
					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current Appointment per day for the CMS User to whom the client is assigned is "
							+ common_futureAppointmentPerDay);
			Log.info("Current Appointment per day for the CMS User to whom the client is assigned is "
					+ common_futureAppointmentPerDay);

			Assert.assertTrue(common_futureAppointmentPerDay > common_currentAppointmentPerDay);
			TestBase.test.log(LogStatus.INFO, "Appointment Per Day is validated and is as expected");
			Log.info("Appointment Per Day is validated and is as expected");

		}
	}

	public void selectActionsTabToAssign_AnyQHP() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot assign a CMS User");
			Log.info("No checked in records. Cannot assign a CMS User");
		} else {

			//System.out.println(common_ClientName);
			
			CommonUtil.sleep(2000);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.CA_list_clientName.get(0));

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {
				
				//System.out.println("Inside for loop");

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {
					
					//System.out.println("Inside if");

					viewStatus();
					
					common_StatusBeforeAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
							.getText();
					
					//System.out.println(cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText());
					
					TestBase.test.log(LogStatus.INFO, "Status before Assigning is " + common_StatusBeforeAssign);
					Log.info("Status before Assigning is " + common_StatusBeforeAssign);

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.sleep(1000);
					
					CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.assignButton);
					TestBase.test.log(LogStatus.INFO, "Assign Modal is displayed as expected");
					Log.info("Assign Modal is displayed as expected");

					break;
				}
			}

			
		}

		TestBase.CADeassignCasesPageActions = TestBase.cADeassignAllCasesActionsObject();

	}

	public void validateCaseLoadBeforeAssign(String CMS_User) {

		CommonUtil.sleep(1000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		CommonUtil.sleep(2000);

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate case load before assign");
			Log.info("No checked in records. Cannot validate case load before assign");
		} else {

			for (int caseM = 0; caseM < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseM++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseM).getText().contains(CMS_User)) {

					common_currentCaseLoad = Integer
							.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(caseM).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current Case Load for the CMS User to whom the client is assigned is "
									+ common_currentCaseLoad);
					Log.info("Current Case Load for the CMS User to whom the client is assigned is "
							+ common_currentCaseLoad);
					break;
				}

			}

		}

		TestBase.CAAssignCasePageActions = TestBase.cAAssignCaseAndValidateActionsObject();
	}

	public void validateCaseLoadAfterAssign(String CMS_User) {

		CommonUtil.sleep(3000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate case load after assign");
			Log.info("No checked in records. Cannot validate case load after assign");
		} else {

			CommonUtil.sleep(1000);

			for (int caseMF = 0; caseMF < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseMF++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseMF).getText().contains(CMS_User)) {

					common_futureCaseLoad = Integer
							.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(caseMF).getText());
					TestBase.test.log(LogStatus.INFO,
							"Future Case Load for the CMS User to whom the client is assigned is "
									+ common_futureCaseLoad);
					Log.info("Future Case Load for the CMS User to whom the client is assigned is "
							+ common_futureCaseLoad);
					break;
				}

			}

			if (common_AppointmentType.contains("Clinical") || common_AppointmentType.contains("Medical")
					|| common_AppointmentType.contains("Psychiatric")) {

				if (common_currentCaseLoad == 0) {
					Assert.assertTrue(common_futureCaseLoad == 0);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				} else if (common_currentCaseLoad > 0) {
					Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				}

			} else {

				if (common_AppointmentType.contains("Wellness Follow-up")) {
					Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				} else {
					Assert.assertTrue(common_futureCaseLoad > common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				}
			}

		}

	}

	public void validateAppointmentPerDayBeforeAssign(String CMS_User) {

		CommonUtil.sleep(1000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		CommonUtil.sleep(2000);

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate case load before assign");
			Log.info("No checked in records. Cannot validate case load before assign");
		} else {

			for (int caseM = 0; caseM < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseM++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseM).getText().contains(CMS_User)) {

					common_currentAppointmentPerDay = Integer
							.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(caseM).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current no of appoinments for the CMS User to whom the client is assigned is "
									+ common_currentAppointmentPerDay);
					Log.info("Current no of appoinments for the CMS User to whom the client is assigned is "
							+ common_currentAppointmentPerDay);
					break;
				}

			}

		}

	}

	public void validateAppointmentPerDayAfterAssign(String CMS_User) {

		CommonUtil.sleep(2000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate case load after assign");
			Log.info("No checked in records. Cannot validate case load after assign");
		} else {

			for (int caseMF = 0; caseMF < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseMF++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseMF).getText().contains(CMS_User)) {

					common_futureAppointmentPerDay = Integer
							.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(caseMF).getText());
					TestBase.test.log(LogStatus.INFO,
							"Future no of appoinments for the CMS User to whom the client is assigned is "
									+ common_futureAppointmentPerDay);
					Log.info("Future no of appoinments for the CMS User to whom the client is assigned is "
							+ common_futureAppointmentPerDay);
					break;
				}

			}

			Assert.assertTrue(common_futureAppointmentPerDay > common_currentAppointmentPerDay);
			TestBase.test.log(LogStatus.INFO, "Appointment per day is validated and is as expected");
			Log.info("Appointment per day is validated and is as expected");

		}

	}

	public void selectActionsTabToAssign(String CMS_User) {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		CommonUtil.sleep(2000);

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot select any user");
			Log.info("No checked in records. Cannot select any user");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {
				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {			
					
					viewStatus();
					
					common_StatusBeforeAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText();
					TestBase.test.log(LogStatus.INFO, "Status before Assigning is " + common_StatusBeforeAssign);
					Log.info("Status before Assigning is " + common_StatusBeforeAssign);

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					break;
				}
			}

			CommonUtil.sleep(2000);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.assignButton);
			TestBase.test.log(LogStatus.INFO, "Assign Modal is displayed as expected");
			Log.info("Assign Modal is displayed as expected");

		}

	}
	
public void selectActionsTab(String CMS_User) {
		
		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		CommonUtil.sleep(2000);

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot select any user");
			Log.info("No checked in records. Cannot select any user");
		} else {

			for (int Action = 0; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {
				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {
					
					CommonUtil.scrollIntoView(TestBase.getDriver(), cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action));

					common_StatusBeforeAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action + 1)
							.getText();
					TestBase.test.log(LogStatus.INFO, "Status before Assigning is " + common_StatusBeforeAssign);
					Log.info("Status before Assigning is " + common_StatusBeforeAssign);

//					CommonUtil.scrollIntoView(TestBase.getDriver(),
//							cACaseAssignmentsCommonLocators.list_actions_New.get(Action));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions_New.get(Action));

					break;
				}
			}

			CommonUtil.sleep(2000);

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.assignButton);
			TestBase.test.log(LogStatus.INFO, "Assign Modal is displayed as expected");
			Log.info("Assign Modal is displayed as expected");

		}

	}

	public void validateCaseAssignmentsPageAfterAssign() {

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate Case Assignments Page");
			Log.info("No checked in records. Cannot validate Case Assignments Page");
		} else {

			common_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;

			CommonUtil.sleep(2000);

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {
					
					viewStatus_Updated();
					
					common_Status = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText();
					TestBase.test.log(LogStatus.INFO,
							common_Status + " is displayed for the user " + common_ClientName + " as expected");
					Log.info(common_Status + " is displayed for the user " + common_ClientName + " as expected");

					common_StatusAfterAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
							.getText();
					
					Assert.assertFalse(
							cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText().isEmpty());
					TestBase.test.log(LogStatus.INFO, "Status is displayed as expected");
					Log.info("Status is displayed as expected");

					if (common_StatusAfterAssign.contains("Assigned")) {
						TestBase.test.log(LogStatus.INFO, "Status for the user has changed from "
								+ common_StatusBeforeAssign + " to " + common_StatusAfterAssign);
						Log.info("Status for the user has changed from " + common_StatusBeforeAssign + " to "
								+ common_StatusAfterAssign);
					}

					else {
						TestBase.test.log(LogStatus.INFO, "Status for the user has not changed");
						Log.info("Status for the user has not changed");
					}
					
					viewAssignedTo();

					String caseWorkerName = CommonUtil.getJSTextOfEle(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.CA_column_CMSUser.get(Action));

					if (caseWorkerName.contains(common_caseWorkerAssigned)
							&& cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText()
									.contains("Assigned")) {

						TestBase.test.log(LogStatus.INFO, common_caseWorkerAssigned + " is displayed for the user "
								+ common_ClientName + " as expected");
						Log.info(common_caseWorkerAssigned + " is displayed for the user " + common_ClientName
								+ " as expected");

						Assert.assertFalse(caseWorkerName.isEmpty());
						TestBase.test.log(LogStatus.INFO, "CMS User name is displayed as expected");
						Log.info("CMS User name is displayed as expected");

						break;

					} else {
						continue;
					}

				} else {
					continue;
				}
			}

		}

	}

	public void validateActionTabOnCaseAssignmentsPageAfterAssign() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));
					break;
				}

			}

			CommonUtil.sleep(2000);
			
			Assert.assertTrue(cACaseAssignmentsCommonLocators.icon_ReassignAndDesign_List.get(0).isDisplayed());
			TestBase.test.log(LogStatus.INFO, "Re-assign option is displayed as expected");
			Log.info("Re-assign option is displayed as expected");

			Assert.assertTrue(cACaseAssignmentsCommonLocators.icon_ReassignAndDesign_List.get(0).isDisplayed());
			TestBase.test.log(LogStatus.INFO, "De-assign option is displayed as expected");
			Log.info("De-assign option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Appointment_Letter));
			TestBase.test.log(LogStatus.INFO, "Appointment Letter option is displayed as expected");
			Log.info("Appointment Letter option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Client_Services_Screen));
			TestBase.test.log(LogStatus.INFO, "Client Services Screen option is displayed as expected");
			Log.info("Client Services Screen option is displayed as expected");

		}
	}

	public void validateLogViewForAssignedCase() {

		CICO_Common.increasePageSize("baseURL", "/checkin");

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.clientName.get(Action).getText().contains(common_ClientName)) {

					if (cACaseAssignmentsCommonLocators.caseAssignment_CaseNumber.get(Action).getText()
							.contains(common_CaseNumber)) {

						if (cACaseAssignmentsCommonLocators.List_AppointmentType.get(Action).getText()
								.contains(common_AppointmentType)) {

							if (cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText()
									.contains(common_caseWorkerAssigned)) {

								CommonUtil.scrollIntoView(TestBase.getDriver(),
										cACaseAssignmentsCommonLocators.clientName.get(Action));

								CommonUtil.clickEleJsExec(TestBase.getDriver(),
										cACaseAssignmentsCommonLocators.clientName.get(Action));
								TestBase.test.log(LogStatus.INFO,
										"Client who was recently assigned is clicked successfully");
								Log.info("Client who was recently assigned is clicked successfully");

								CommonUtil.sleep(2000);

								Assert.assertFalse(cACaseAssignmentsCommonLocators.List_CheckIn_DateTime.get(Action)
										.getText().isEmpty());
								TestBase.test.log(LogStatus.INFO,
										"Check-In Date field is validated and is not empty as expected");
								Log.info("Check-In Date field is validated and is not empty as expected");

								Assert.assertFalse(
										cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText().isEmpty());
								TestBase.test.log(LogStatus.INFO,
										"CMS User field is validated and is not empty as expected");
								Log.info("CMS User field is validated and is not empty as expected");

								Assert.assertTrue(cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText()
										.contains(common_caseWorkerAssigned));
								TestBase.test.log(LogStatus.INFO,
										"Assigned case worker's name is displayed as expected");
								Log.info("Assigned case worker's name is displayed as expected");

								break;
							}
						}
					}

				}
			}

		}

	}

	/* De-assign Case Scripts */

	public void validateCaseLoadBeforeDeassignAllCases() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		common_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.bycaseLoad_CMS_User);

			for (int CMS_Username = 0; CMS_Username < cACaseAssignmentsCommonLocators.caseLoad_CMS_User
					.size(); CMS_Username++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(CMS_Username).getText()
						.contains(common_caseWorkerAssigned)) {

					common_currentCaseLoad = Integer
							.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(CMS_Username).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current Case Load for the CMS User to whom the client is assigned is "
									+ common_currentCaseLoad);
					Log.info("Current Case Load for the CMS User to whom the client is assigned is "
							+ common_currentCaseLoad);
					break;
				}

			}
		}

	}

	public void validateAppointmentPerDayBeforeDeassignAllCases() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		common_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.bycaseLoad_CMS_User);

			for (int CMS_Username = 0; CMS_Username < cACaseAssignmentsCommonLocators.caseLoad_CMS_User
					.size(); CMS_Username++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(CMS_Username).getText()
						.contains(common_caseWorkerAssigned)) {

					common_currentAppointmentPerDay = Integer
							.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(CMS_Username).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current no of appointments for the CMS User to whom the client is assigned is "
									+ common_currentAppointmentPerDay);
					Log.info("Current no of appointments for the CMS User to whom the client is assigned is "
							+ common_currentAppointmentPerDay);
					break;
				}

			}
		}

	}

	public void validateCaseLoadAfterDeassignAllCases() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate ");
		} else {

			CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.bycaseLoad_CMS_User);

			common_caseWorkerDeAssigned = CADeassignCasesPageActions.DA_caseWorkerDeAssigned;

			for (int CMS_Username = 0; CMS_Username < cACaseAssignmentsCommonLocators.caseLoad_CMS_User
					.size(); CMS_Username++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(CMS_Username).getText()
						.contains(common_caseWorkerDeAssigned)) {

					common_futureCaseLoad = Integer
							.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(CMS_Username).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current Case Load for the CMS User from whom the client is de-assigned is  "
									+ common_futureCaseLoad);
					Log.info("Current Case Load for the CMS User from whom the client is de-assigned is "
							+ common_futureCaseLoad);
					break;

				}

			}

			Assert.assertTrue(common_futureCaseLoad == 0);
			TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
			Log.info("Case load is validated and is as expected");

		}
	}

	public void validateAppointmentPerDayAfterDeassignAllCases() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate ");
		} else {

			CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.bycaseLoad_CMS_User);

			common_caseWorkerDeAssigned = CADeassignCasesPageActions.DA_caseWorkerDeAssigned;

			for (int CMS_Username = 0; CMS_Username < cACaseAssignmentsCommonLocators.caseLoad_CMS_User
					.size(); CMS_Username++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(CMS_Username).getText()
						.contains(common_caseWorkerDeAssigned)) {

					common_futureAppointmentPerDay = Integer
							.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(CMS_Username).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current no of appointments for the CMS User from whom the client is de-assigned is  "
									+ common_futureAppointmentPerDay);
					Log.info("Current no of appointments for the CMS User from whom the client is de-assigned is "
							+ common_futureAppointmentPerDay);
					break;

				}

			}

			Assert.assertTrue(common_futureAppointmentPerDay == 0);
			TestBase.test.log(LogStatus.INFO, "Appointment per day is validated and is as expected");
			Log.info("Appointment per day is validated and is as expected");

		}
	}

	public void validateCaseLoadBeforeDeassignSpecificCase(String CMS_User ) {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {
			
			for (int caseM = 0; caseM < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseM++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseM).getText().contains(CMS_User)) {

					common_currentCaseLoad = Integer
							.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(caseM).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current Case Load for the CMS User to whom the client is assigned is "
									+ common_currentCaseLoad);
					Log.info("Current Case Load for the CMS User to whom the client is assigned is "
							+ common_currentCaseLoad);
					break;
				}

			}

//			common_currentCaseLoad = Integer.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(0).getText());
//			TestBase.test.log(LogStatus.INFO,
//					"Current Case Load for the CMS User to whom the client is assigned is " + common_currentCaseLoad);
//			Log.info("Current Case Load for the CMS User to whom the client is assigned is " + common_currentCaseLoad);
		}

	}

	public void validateAppointmentPerDayBeforeDeassignSpecificCase(String CMS_User) {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {
			
			for (int caseM = 0; caseM < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseM++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseM).getText().contains(CMS_User)) {

					common_currentAppointmentPerDay = 0;
					
					common_currentAppointmentPerDay = Integer
							.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(caseM).getText());
					TestBase.test.log(LogStatus.INFO,
							"Current no of appoinments for the CMS User to whom the client is assigned is "
									+ common_currentAppointmentPerDay);
					Log.info("Current no of appoinments for the CMS User to whom the client is assigned is "
							+ common_currentAppointmentPerDay);
					break;
				}

			}

//			common_currentAppointmentPerDay = Integer
//					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(0).getText());
//			TestBase.test.log(LogStatus.INFO,
//					"Current no of appointments for the CMS User to whom the client is assigned is "
//							+ common_currentAppointmentPerDay);
//			Log.info("Current no of appointments for the CMS User to whom the client is assigned is "
//					+ common_currentAppointmentPerDay);
		}

	}

	public void validateCaseLoadAfterDeassignSpecificCase(String CMS_User) {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {
			
			for (int caseMF = 0; caseMF < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseMF++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseMF).getText().contains(CMS_User)) {

					common_futureCaseLoad = Integer
							.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(caseMF).getText());
					TestBase.test.log(LogStatus.INFO,
							"Future Case Load for the CMS User to whom the client is assigned is "
									+ common_futureCaseLoad);
					Log.info("Future Case Load for the CMS User to whom the client is assigned is "
							+ common_futureCaseLoad);
					break;
				}
			}

			/*common_futureCaseLoad = Integer.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current Case Load for the CMS User from whom the client was de-assigned is "
							+ common_futureCaseLoad);
			Log.info("Current Case Load for the CMS User from whom the client was de-assigned is "
					+ common_futureCaseLoad);*/

			if (common_AppointmentType.contains("Clinical") || common_AppointmentType.contains("Medical")
					|| common_AppointmentType.contains("Psychiatric")) {

				if (common_currentCaseLoad == 0) {
					Assert.assertTrue(common_futureCaseLoad == 0);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				} else if (common_currentCaseLoad > 0) {
					Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				}

			} else {

				if (common_AppointmentType.contains("Wellness Follow-up")) {
					Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				} else {
					Assert.assertTrue(common_futureCaseLoad < common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO, "Case load is validated and is as expected");
					Log.info("Case load is validated and is as expected");
				}

			}

		}

	}

	public void validateAppointmentPerDayAfterDeassignSpecificCase(String CMS_User) {

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			
			for (int caseMF = 0; caseMF < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); caseMF++) {

				if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(caseMF).getText().contains(CMS_User)) {

					common_futureAppointmentPerDay = Integer
							.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(caseMF).getText());
					TestBase.test.log(LogStatus.INFO,
							"Future no of appoinments for the CMS User to whom the client is assigned is "
									+ common_futureAppointmentPerDay);
					Log.info("Future no of appoinments for the CMS User to whom the client is assigned is "
							+ common_futureAppointmentPerDay);
					break;
				}

			}
			
//			common_futureAppointmentPerDay = Integer
//					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(0).getText());
//			TestBase.test.log(LogStatus.INFO,
//					"Current no of appointments for the CMS User from whom the client was de-assigned is "
//							+ common_futureAppointmentPerDay);
//			Log.info("Current no of appointments for the CMS User from whom the client was de-assigned is "
//					+ common_futureAppointmentPerDay);

			Assert.assertTrue(common_futureAppointmentPerDay < common_currentAppointmentPerDay);
			TestBase.test.log(LogStatus.INFO,
					"Appointments Per Day is validated and is as expected for the CMS user from whom the client was de-assigned");
			Log.info(
					"Appointments Per Day is validated and is as expected for the CMS user from whom the client was de-assigned");

		}

	}

	public void selectActionsTabToDeassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		common_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;

		if (common_ClientName == null) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot de-assign a CMS User");
			Log.info("No checked in records. Cannot de-assign a CMS User");
		} else {

			for (WebElement caseWorkerNameToDeAssign : cACaseAssignmentsCommonLocators.caseLoad_CMS_User) {

				if (caseWorkerNameToDeAssign.getText().contains(common_caseWorkerAssigned)) {
					common_caseWorkerDeAssigned = caseWorkerNameToDeAssign.getText();
					break;
				}
			}

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {
				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					viewStatus();
					
					common_StatusBeforeDeAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
							.getText();
					TestBase.test.log(LogStatus.INFO, "Status before De-Assigning is " + common_StatusBeforeDeAssign);
					Log.info("Status before De-Assigning is " + common_StatusBeforeDeAssign);

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));
					break;
				}
			}

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.deAssign);
			TestBase.test.log(LogStatus.INFO, "Deassign Modal is dispalyed as expected");
			Log.info("Deassign Modal is displayed as expected");

		}

	}

	public void validateCaseAssignmentsPageAfterDeassign() {
		
		CommonUtil.sleep(2000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);
		
		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		common_caseWorkerDeAssigned = CADeassignCasesPageActions.DA_caseWorkerDeAssigned;

		CommonUtil.sleep(2000);

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action =1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.sleep(2000);
					
					viewStatus_Updated();
					
					viewAssignedTo();

					String caseWorkerName = CommonUtil.getJSTextOfEle(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.CA_column_CMSUser.get(Action));

					if (caseWorkerName.isEmpty() && cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
							.getText().contains("Pending")) {

						TestBase.test.log(LogStatus.INFO, common_caseWorkerDeAssigned
								+ " is not displayed for the user " + common_ClientName + " as expected");
						Log.info(common_caseWorkerDeAssigned + " is not displayed for the user " + common_ClientName
								+ " as expected");

						Assert.assertTrue(caseWorkerName.isEmpty());
						TestBase.test.log(LogStatus.INFO, "CMS User name is not displayed as expected");
						Log.info("CMS User name is not  displayed as expected");

						common_Status = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText();
						TestBase.test.log(LogStatus.INFO,
								common_Status + " is displayed for the user " + common_ClientName + " as expected");
						Log.info(common_Status + " is displayed for the user " + common_ClientName + " as expected");

						common_StatusAfterDeAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
								.getText();

						Assert.assertFalse(
								cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText().isEmpty());
						TestBase.test.log(LogStatus.INFO, "Status is displayed as expected");
						Log.info("Status is displayed as expected");

						if (common_StatusAfterDeAssign.contains("Pending")) {
							TestBase.test.log(LogStatus.INFO, "Status for the user changed from "
									+ common_StatusBeforeDeAssign + " to " + common_StatusAfterDeAssign);
							Log.info("Status for the user changed from " + common_StatusBeforeDeAssign + " to "
									+ common_StatusAfterDeAssign);
						}

						else {
							TestBase.test.log(LogStatus.INFO, "Status for the user has not changed");
							Log.info("Status for the user has not changed");
						}

						break;

					} else {
						continue;
					}

				} else {
					continue;
				}
			}

		}

	}

	public void validateActionTabOnCaseAssignmentsPageAfterDeassign() {

		CommonUtil.sleep(1000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));
					break;
				}

			}

			Assert.assertTrue(
					CommonUtil.isElementPresent(TestBase.getDriver(), cACaseAssignmentsCommonLocators.byicon_Assign));
			TestBase.test.log(LogStatus.INFO, "Assign option is displayed as expected");
			Log.info("Assign option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Appointment_Letter));
			TestBase.test.log(LogStatus.INFO, "Appointment Letter option is displayed as expected");
			Log.info("Appointment Letter option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Client_Services_Screen));
			TestBase.test.log(LogStatus.INFO, "Client Services Screen option is displayed as expected");
			Log.info("Client Services Screen option is displayed as expected");

		}

	}

	public void validateLogViewForDeAssignedCase() {

		CICO_Common.increasePageSize("baseURL", "/checkin");

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.clientName.get(Action).getText().contains(common_ClientName)) {

					if (cACaseAssignmentsCommonLocators.caseAssignment_CaseNumber.get(Action).getText()
							.contains(common_CaseNumber)) {

						if (cACaseAssignmentsCommonLocators.List_AppointmentType.get(Action).getText()
								.contains(common_AppointmentType)) {

							CommonUtil.scrollIntoView(TestBase.getDriver(),
									cACaseAssignmentsCommonLocators.clientName.get(Action));

							CommonUtil.clickEleJsExec(TestBase.getDriver(),
									cACaseAssignmentsCommonLocators.clientName.get(Action));
							TestBase.test.log(LogStatus.INFO,
									"Client who was recently assigned is clicked successfully");
							Log.info("Client who was recently assigned is clicked successfully");

							CommonUtil.sleep(2000);

							Assert.assertFalse(cACaseAssignmentsCommonLocators.List_CheckIn_DateTime.get(Action)
									.getText().isEmpty());
							TestBase.test.log(LogStatus.INFO,
									"Check-In Date field is validated and is not empty as expected");
							Log.info("Check-In Date field is validated and is not empty as expected");

							Assert.assertTrue(
									cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText().isEmpty());
							TestBase.test.log(LogStatus.INFO, "CMS User field is validated and is empty as expected");
							Log.info("CMS User field is validated and is empty as expected");

							break;

						}
					}

				}
			}

		}

	}

	/* Re-assign Case Scripts */

	public void validateCaseLoadBeforeReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		common_currentCaseLoad = Integer.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(0).getText());
		TestBase.test.log(LogStatus.INFO,
				"Current Case Load for the CMS User to whom the client is assigned is " + common_currentCaseLoad);
		Log.info("Current Case Load for the CMS User to whom the client is assigned is " + common_currentCaseLoad);

		common_currentCaseLoadForNewCMSUser = Integer
				.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(1).getText());
		TestBase.test.log(LogStatus.INFO,
				"Current Case Load for the CMS User to whom the client will be re-assigned is "
						+ common_currentCaseLoadForNewCMSUser);
		Log.info("Current Case Load for the CMS User to whom the client will be re-assigned is "
				+ common_currentCaseLoadForNewCMSUser);
	}

	public void validateAppointmentPerDayBeforeReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			common_currentAppointmentPerDay = Integer
					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current no of appointments for the CMS User to whom the client is assigned is "
							+ common_currentAppointmentPerDay);
			Log.info("Current no of appointments for the CMS User to whom the client is assigned is "
					+ common_currentAppointmentPerDay);

			common_currentAppointmentPerDayForNewCMSUser = Integer
					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(1).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current no of appointments for the CMS User to whom the client will be re-assigned is "
							+ common_currentAppointmentPerDayForNewCMSUser);
			Log.info("Current no of appointments for the CMS User to whom the client will be re-assigned is "
					+ common_currentAppointmentPerDayForNewCMSUser);
		}

	}

	public void validateCaseLoadAfterReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			CommonUtil.sleep(2000);

			common_futureCaseLoad = Integer.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current Case Load for the CMS User to whom the client was previously assigned is "
							+ common_futureCaseLoad);
			Log.info("Current Case Load for the CMS User to whom the client was previously assigned is "
					+ common_futureCaseLoad);

			if (common_AppointmentType.contains("Clinical") || common_AppointmentType.contains("Medical")
					|| common_AppointmentType.contains("Psychiatric")) {

				Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
				TestBase.test.log(LogStatus.INFO,
						"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
				Log.info(
						"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
			} else {

				if (common_AppointmentType.contains("Wellness Follow-up")) {
					Assert.assertTrue(common_futureCaseLoad == common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO,
							"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
					Log.info(
							"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
				} else {
					Assert.assertTrue(common_futureCaseLoad < common_currentCaseLoad);
					TestBase.test.log(LogStatus.INFO,
							"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
					Log.info(
							"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
				}

			}

			common_futureCaseLoadForNewCMSUser = Integer
					.valueOf(cACaseAssignmentsCommonLocators.caseLoad.get(1).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current Case Load for the CMS User to whom the client is currently assigned is "
							+ common_futureCaseLoadForNewCMSUser);
			Log.info("Current Case Load for the CMS User to whom the client is currently assigned is "
					+ common_futureCaseLoadForNewCMSUser);

			if (common_AppointmentType.contains("Clinical") || common_AppointmentType.contains("Medical")
					|| common_AppointmentType.contains("Psychiatric")) {

				Assert.assertTrue(common_futureCaseLoadForNewCMSUser == common_currentCaseLoadForNewCMSUser);
				TestBase.test.log(LogStatus.INFO,
						"Case load is validated and is as expected for the CMS user to whom the client is currently assigned");
				Log.info(
						"Case load is validated and is as expected for the CMS user to whom the client is currently assigned");
			} else {

				if (common_AppointmentType.contains("Wellness Follow-up")) {
					Assert.assertTrue(common_futureCaseLoadForNewCMSUser == common_currentCaseLoadForNewCMSUser);
					TestBase.test.log(LogStatus.INFO,
							"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
					Log.info(
							"Case load is validated and is as expected for the CMS user to whom the client was previously re-assigned");
				} else {
					Assert.assertTrue(common_futureCaseLoadForNewCMSUser > common_currentCaseLoadForNewCMSUser);
					TestBase.test.log(LogStatus.INFO,
							"Case load is validated and is as expected for the CMS user to whom the client is currently assigned");
					Log.info(
							"Case load is validated and is as expected for the CMS user to whom the client is currently assigned");
				}

			}
		}

	}

	public void validateAppointmentPerDayAfterReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			CommonUtil.sleep(2000);

			common_futureAppointmentPerDay = Integer
					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(0).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current no of appointments for the CMS User to whom the client was previously assigned is "
							+ common_futureAppointmentPerDay);
			Log.info("Current no of appointment for the CMS User to whom the client was previously assigned is "
					+ common_futureAppointmentPerDay);

			Assert.assertTrue(common_futureAppointmentPerDay < common_currentAppointmentPerDay);
			TestBase.test.log(LogStatus.INFO,
					"Appointment Per Day is validated and is as expected for the CMS user to whom the client was previously re-assigned");
			Log.info(
					"Appointment Per Day is validated and is as expected for the CMS user to whom the client was previously re-assigned");

			common_futureCaseLoadForNewCMSUser = Integer
					.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(1).getText());
			TestBase.test.log(LogStatus.INFO,
					"Current no of appointments for the CMS User to whom the client is currently assigned is "
							+ common_futureCaseLoadForNewCMSUser);
			Log.info("Current no of appointments for the CMS User to whom the client is currently assigned is "
					+ common_futureCaseLoadForNewCMSUser);

			Assert.assertTrue(common_futureCaseLoadForNewCMSUser > common_currentCaseLoadForNewCMSUser);
			TestBase.test.log(LogStatus.INFO,
					"Appointment Per Day is validated and is as expected for the CMS user to whom the client is currently assigned");
			Log.info(
					"Appointment Per Day is validated and is as expected for the CMS user to whom the client is currently assigned");
		}

	}

	public void selectActionsTabToReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot re-assign a CMS User");
			Log.info("No checked in records. Cannot re-assign a CMS User");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {
				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					viewStatus_Updated();
					
					common_StatusBeforeReAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
							.getText();
					TestBase.test.log(LogStatus.INFO, "Status before Re-Assigning is " + common_StatusBeforeReAssign);
					Log.info("Status before Re-Assigning is " + common_StatusBeforeReAssign);

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));
					break;
				}
			}

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.reAssign);
			TestBase.test.log(LogStatus.INFO, "Re-Assign Modal is displayed as expected");
			Log.info("Re-Assign Modal is displayed as expected");

		}

	}

	public void validateCaseAssignmentsPageAfterReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			common_caseWorkerReAssigned = CAReAssignCasePageActions.RAC_caseWorkerReAssigned;

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.sleep(2000);

					viewStatus_Updated();
					
					viewAssignedTo();
					
					String caseWorkerName = CommonUtil.getJSTextOfEle(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.CA_column_CMSUser.get(Action));

					if (caseWorkerName.contains(common_caseWorkerReAssigned)
							&& cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText()
									.contains("Assigned")) {

						TestBase.test.log(LogStatus.INFO, common_caseWorkerReAssigned + " is displayed for the user "
								+ common_ClientName + " as expected");
						Log.info(common_caseWorkerReAssigned + " is displayed for the user " + common_ClientName
								+ " as expected");

						Assert.assertFalse(caseWorkerName.isEmpty());
						TestBase.test.log(LogStatus.INFO, "CMS User name is displayed as expected");
						Log.info("CMS User name is displayed as expected");

						common_Status = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText();
						TestBase.test.log(LogStatus.INFO,
								common_Status + " is displayed for the user " + common_ClientName + " as expected");
						Log.info(common_Status + " is displayed for the user " + common_ClientName + " as expected");

						common_StatusAfterReAssign = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
								.getText();

						Assert.assertFalse(
								cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText().isEmpty());
						TestBase.test.log(LogStatus.INFO, "Status is displayed as expected");
						Log.info("Status is displayed as expected");

						if (common_StatusAfterReAssign.contentEquals(common_StatusBeforeReAssign)
								&& common_StatusAfterReAssign.contains("Assigned")) {
							TestBase.test.log(LogStatus.INFO,
									"Status for the user remains as " + common_StatusBeforeReAssign
											+ " before re-assigning and " + common_StatusAfterReAssign
											+ " after re-assigning");
							Log.info("Status for the user remains as " + common_StatusBeforeReAssign
									+ " before re-assigning and " + common_StatusAfterReAssign + " after re-assigning");
						}

						else {
							TestBase.test.log(LogStatus.INFO, "Status has not changed");
							Log.info("Status has not changed");
						}

						break;

					} else {
						continue;
					}

				} else {
					continue;
				}
			}

		}

	}

	public void validateActionTabOnCaseAssignmentsPageAfterReassign() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));
					break;
				}

			}

			CommonUtil.sleep(2000);
			
			Assert.assertTrue(cACaseAssignmentsCommonLocators.icon_ReassignAndDesign_List.get(0).isDisplayed());
			TestBase.test.log(LogStatus.INFO, "Re-assign option is displayed as expected");
			Log.info("Re-assign option is displayed as expected");

			Assert.assertTrue(cACaseAssignmentsCommonLocators.icon_ReassignAndDesign_List.get(0).isDisplayed());
			TestBase.test.log(LogStatus.INFO, "De-assign option is displayed as expected");
			Log.info("De-assign option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Appointment_Letter));
			TestBase.test.log(LogStatus.INFO, "Appointment Letter option is displayed as expected");
			Log.info("Appointment Letter option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Client_Services_Screen));
			TestBase.test.log(LogStatus.INFO, "Client Services Screen option is displayed as expected");
			Log.info("Client Services Screen option is displayed as expected");

		}

	}

	public void validateLogViewForReAssignedCase() {

		CICO_Common.increasePageSize("baseURL", "/checkin");

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate the log view");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.clientName.get(Action).getText().contains(common_ClientName)) {

					if (cACaseAssignmentsCommonLocators.caseAssignment_CaseNumber.get(Action).getText()
							.contains(common_CaseNumber)) {

						if (cACaseAssignmentsCommonLocators.List_AppointmentType.get(Action).getText()
								.contains(common_AppointmentType)) {

							if (cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText()
									.contains(CAReAssignCasePageActions.RAC_caseWorkerReAssigned)) {

								CommonUtil.scrollIntoView(TestBase.getDriver(),
										cACaseAssignmentsCommonLocators.clientName.get(Action));

								CommonUtil.clickEleJsExec(TestBase.getDriver(),
										cACaseAssignmentsCommonLocators.clientName.get(Action));
								TestBase.test.log(LogStatus.INFO,
										"Client who was recently assigned is clicked successfully");
								Log.info("Client who was recently assigned is clicked successfully");

								CommonUtil.sleep(2000);

								Assert.assertFalse(cACaseAssignmentsCommonLocators.List_CheckIn_DateTime.get(Action)
										.getText().isEmpty());
								TestBase.test.log(LogStatus.INFO,
										"Check-In Date field is validated and is not empty as expected");
								Log.info("Check-In Date field is validated and is not empty as expected");

								Assert.assertFalse(
										cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText().isEmpty());
								TestBase.test.log(LogStatus.INFO,
										"CMS User field is validated and is not empty as expected");
								Log.info("CMS User field is validated and is not empty as expected");

								Assert.assertTrue(cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText()
										.contains(common_caseWorkerReAssigned));
								TestBase.test.log(LogStatus.INFO,
										"Reassigned case worker's name is displayed as expected");
								Log.info("Reassigned case worker's name is displayed as expected");

								break;
							}
						}
					}

				}
			}

		}

	}

	/* Scripts for validation after opening a case in My Assignments */

	public void validateCaseAssignmentsPageAfterOpen() {

		CommonUtil.sleep(2000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Refresh);

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.sleep(2000);
					
					viewStatus_Updated();
					
					common_Status = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText();

					TestBase.test.log(LogStatus.INFO,
							common_Status + " is displayed for the user " + common_ClientName + " as expected");
					Log.info(common_Status + " is displayed for the user " + common_ClientName + " as expected");

					common_StatusAfterOpen = cACaseAssignmentsCommonLocators.CA_column_Status.get(Action)
							.getText();

					Assert.assertFalse(
							cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText().isEmpty());
					TestBase.test.log(LogStatus.INFO, "Status is displayed as expected");
					Log.info("Status is displayed as expected");

					if (common_StatusAfterOpen.contains("In Progress")) {
						TestBase.test.log(LogStatus.INFO, "Status for the user has changed from "
								+ common_StatusBeforeOpen + " to " + common_StatusAfterOpen);
						Log.info("Status for the user has changed from " + common_StatusBeforeOpen + " to "
								+ common_StatusAfterOpen);
					}

					else {
						TestBase.test.log(LogStatus.INFO, "Status for the user has not changed");
						Log.info("Status for the user has not changed");
					}
					
					
					viewAssignedTo();
					
					String caseWorkerName = CommonUtil.getJSTextOfEle(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.CA_column_CMSUser.get(Action));

					if (caseWorkerName.contains(common_caseWorkerAssigned)
							&& cACaseAssignmentsCommonLocators.CA_column_Status.get(Action).getText()
									.contains("In Progress")) {

						TestBase.test.log(LogStatus.INFO, common_caseWorkerAssigned + " is displayed for the user "
								+ common_ClientName + " as expected");
						Log.info(common_caseWorkerAssigned + " is displayed for the user " + common_ClientName
								+ " as expected");

						Assert.assertFalse(caseWorkerName.isEmpty());
						TestBase.test.log(LogStatus.INFO, "CMS User name is displayed as expected");
						Log.info("CMS User name is displayed as expected");

					

						break;

					} else {
						continue;
					}

				} else {
					continue;
				}
			}

		}

	}

	public void validateActionTabOnCaseAssignmentsPageAfterOpen() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.leftChevron);

		this.increasePageSize_CaseAssignments();

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate");
			Log.info("No checked in records. Cannot validate");
		} else {

			for (int Action = 0; Action < cACaseAssignmentsCommonLocators.CA_list_clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action).getText()
						.contains(common_ClientName)) {

					CommonUtil.scrollIntoView(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.CA_list_clientName.get(Action));

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.list_actions.get(Action-1));
					break;
				}

			}

			CommonUtil.sleep(2000);

			try {

				Assert.assertTrue(cACaseAssignmentsCommonLocators.icon_ReassignAndDesign_List.get(0).isDisplayed());
				TestBase.test.log(LogStatus.INFO, "Re-assign option is displayed as expected");
				Log.info("Re-assign option is displayed as expected");

				Assert.assertTrue(cACaseAssignmentsCommonLocators.icon_ReassignAndDesign_List.get(0).isDisplayed());
				TestBase.test.log(LogStatus.INFO, "De-assign option is displayed as expected");
				Log.info("De-assign option is displayed as expected");
			} catch (IndexOutOfBoundsException e) {

				Assert.assertFalse(false);
				TestBase.test.log(LogStatus.INFO, "Re-assign and de-assign option are not displayed");
				Log.info("Re-assign and de-assign option are not displayed");

			}

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Appointment_Letter));
			TestBase.test.log(LogStatus.INFO, "Appointment Letter option is displayed as expected");
			Log.info("Appointment Letter option is displayed as expected");

			Assert.assertTrue(CommonUtil.isElementPresent(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.byicon_Client_Services_Screen));
			TestBase.test.log(LogStatus.INFO, "Client Services Screen option is displayed as expected");
			Log.info("Client Services Screen option is displayed as expected");

		}

	}

	public void validateLogViewForInProgressCaseAfterOpen() {

		CICO_Common.increasePageSize("baseURL", "/checkin");

		if (common_ClientName == null || common_checkInSuccessfull == false) {
			TestBase.test.log(LogStatus.INFO, "No checked in records. Cannot validate the log view");
			Log.info("No checked in records. Cannot validate the log view");
		} else {

			for (int Action = 1; Action < cACaseAssignmentsCommonLocators.clientName.size(); Action++) {

				if (cACaseAssignmentsCommonLocators.clientName.get(Action).getText().contains(common_ClientName)) {

					if (cACaseAssignmentsCommonLocators.caseAssignment_CaseNumber.get(Action).getText()
							.contains(common_CaseNumber)) {

						if (cACaseAssignmentsCommonLocators.List_AppointmentType.get(Action).getText()
								.contains(common_AppointmentType)) {

							if (cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText()
									.contains(common_caseWorkerAssigned)) {

								CommonUtil.scrollIntoView(TestBase.getDriver(),
										cACaseAssignmentsCommonLocators.clientName.get(Action));

								CommonUtil.clickEleJsExec(TestBase.getDriver(),
										cACaseAssignmentsCommonLocators.clientName.get(Action));
								TestBase.test.log(LogStatus.INFO,
										"Client whose case was recently opened is clicked successfully");
								Log.info("Client whose case was recently opened is clicked successfully");

								CommonUtil.sleep(2000);

								Assert.assertFalse(cACaseAssignmentsCommonLocators.List_CheckIn_DateTime.get(Action)
										.getText().isEmpty());
								TestBase.test.log(LogStatus.INFO,
										"Check-In Date field is validated and is not empty as expected");
								Log.info("Check-In Date field is validated and is not empty as expected");

								Assert.assertFalse(
										cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText().isEmpty());
								TestBase.test.log(LogStatus.INFO,
										"CMS User field is validated and is not empty as expected");
								Log.info("CMS User field is validated and is not empty as expected");

								Assert.assertTrue(cACaseAssignmentsCommonLocators.List_CMSUser.get(Action).getText()
										.contains(common_caseWorkerAssigned));
								TestBase.test.log(LogStatus.INFO,
										"Assigned case worker's name is displayed as expected");
								Log.info("Assigned case worker's name is displayed as expected");

								break;
							}
						}
					}

				}
			}

		}

	}

	/* Bulk assignment scripts */

	public void navigateToCaseAssignmentsPage(String configFileURL, String endPoint) {

		//CommonUtil.navigateTo(TestBase.driver, "http://dev.ewweb.prutechlab.com/cms/#/assignments");
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);
		TestBase.test.log(LogStatus.INFO, "User has navigated to Case Assignments Page");
		Log.info("User has navigated to Case Assignments Page");

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
				cACaseAssignmentsCommonLocators.caseAssignmentsPageHeader);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver,
				cACaseAssignmentsCommonLocators.category1_ClinicalorReassessment);

	}

	public void validation_SelectAndDeselectCheckBox() {

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
				cACaseAssignmentsCommonLocators.bycaseassignments_AllCategories);

		Outerloop: for (int caseTab = 0; caseTab < cACaseAssignmentsCommonLocators.caseassignments_AllCategories
				.size(); caseTab++) {

			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.caseassignments_AllCategories.get(caseTab));

			CommonUtil.sleep(2000);

			try {
				if (cACaseAssignmentsCommonLocators.text_noActivities.isDisplayed()) {

					TestBase.test.log(LogStatus.INFO, "No records available");
					Log.info("No records available");

					continue Outerloop;
				}
			} catch (NoSuchElementException noActivity) {

				TestBase.test.log(LogStatus.INFO, "Records available");
				Log.info("Records available");
			}

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.leftChevron);

			CommonUtil.sleep(1000);

			this.increasePageSize_CaseAssignments();

			String appointmentType = cACaseAssignmentsCommonLocators.caseassignments_AllCategories.get(caseTab)
					.getText();
			
			viewStatus_Updated();
			
			CommonUtil.sleep(1000);

			if (appointmentType.contains("Clinical") || appointmentType.contains("Psychiatric")) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Filter.get(4));

				CommonUtil.sleep(2000);

			} else if (appointmentType.contains("Review") || appointmentType.contains("Medical")) {
				// CommonUtil.clickEleJsExec(TestBase.getDriver(),
				// cACaseAssignmentsCommonLocators.Menu_Filter.get(8));
				continue Outerloop;
			} else {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Filter.get(6));
				CommonUtil.sleep(2000);
			}

		
			
			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.filterTab);

			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_All_Filter_checked.get(0));

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.checkbox_All_Filter_unchecked.get(0));

			CommonUtil.sleep(2000);

			Innerloop: for (int filterOpt = 0; filterOpt < cACaseAssignmentsCommonLocators.options_FilterTab
					.size(); filterOpt++) {

				if (cACaseAssignmentsCommonLocators.options_FilterTab.get(filterOpt).getText().contains("Pending")) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.checkBox_FilterTab.get(filterOpt));
					
					CommonUtil.sleep(1000);
					
					CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Apply);
					TestBase.test.log(LogStatus.INFO, "Pending cases are filtered");
					Log.info("Pending cases are filtered");

					CommonUtil.sleep(2000);

					CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.filterTab);

					CommonUtil.sleep(2000);

					break Innerloop;

				}

			} // innerloop ends here

			if (cACaseAssignmentsCommonLocators.all_CheckBox.size() > 1) {

				if (CommonUtil.isElementPresent(TestBase.getDriver(),
						cACaseAssignmentsCommonLocators.bycheckbox_SelectAll)) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_SelectAll);
					TestBase.test.log(LogStatus.INFO, "Select All check box is clicked");
					Log.info("Select All check box is clicked");

					CommonUtil.sleep(1000);
				}

				if (CommonUtil.isElementPresent(TestBase.getDriver(),
						cACaseAssignmentsCommonLocators.bycheckbox_UnSelectAll)) {
					TestBase.test.log(LogStatus.INFO, "All Pending cases are selected");
					Log.info("All Pending cases are selected");

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.checkbox_UnSelectAll);
					TestBase.test.log(LogStatus.INFO, "De-Select All checkbox is clicked");
					Log.info("De-Select All checkbox is clicked");

					if (CommonUtil.isElementPresent(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.bycheckbox_SelectAll)) {
						TestBase.test.log(LogStatus.INFO, "All Pending cases are successfully un-selected");
						Log.info("All Pending cases are successfully un-selected");
					}

				}

				break Outerloop;
			} else {
				continue Outerloop;
			}

		}

	}

	public void filterPendingCasesAndSelectCheckboxForBulkAssignment() {

		String currentVal = null;
		String currentVal1 = null;

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
				cACaseAssignmentsCommonLocators.bycaseassignments_AllCategories);

		Outerloop: for (int caseTab = 0; caseTab < cACaseAssignmentsCommonLocators.caseassignments_AllCategories
				.size(); caseTab++) {

			CommonUtil.clickEleJsExec(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.caseassignments_AllCategories.get(caseTab));

			CommonUtil.sleep(2000);

			try {
				if (cACaseAssignmentsCommonLocators.text_noActivities.isDisplayed()) {

					TestBase.test.log(LogStatus.INFO, "No records available");
					Log.info("No records available");

					continue Outerloop;
				}
			} catch (NoSuchElementException noActivity) {

				TestBase.test.log(LogStatus.INFO, "Records available");
				Log.info("Records available");
			}

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.leftChevron);

			CommonUtil.sleep(1000);

			this.increasePageSize_CaseAssignments();

			String appointmentType = cACaseAssignmentsCommonLocators.caseassignments_AllCategories.get(caseTab).getText();
			
			
			
			CommonUtil.sleep(1000);
//			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Filter.get(4));

			if (appointmentType.contains("Clinical") || appointmentType.contains("Psychiatric")) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Filter.get(6));

				CommonUtil.sleep(2000);	
			}else if (appointmentType.contains("Review") || appointmentType.contains("Medical")) {
				// CommonUtil.clickEleJsExec(TestBase.getDriver(),
				// cACaseAssignmentsCommonLocators.Menu_Filter.get(8));
				continue Outerloop;
			} else {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.Menu_Filter.get(6));
				CommonUtil.sleep(2000);
			}

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.filterTab);

//			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_SelectAll_checked);
//
//			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
//					cACaseAssignmentsCommonLocators.checkbox_SelectAll_unchecked);
			
			CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.checkbox_All_Filter_checked.get(0));

			CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
					cACaseAssignmentsCommonLocators.checkbox_All_Filter_unchecked.get(0));

			CommonUtil.sleep(2000);

			Innerloop: for (int filterOpt = 0; filterOpt < cACaseAssignmentsCommonLocators.options_FilterTab
					.size(); filterOpt++) {

				if (cACaseAssignmentsCommonLocators.options_FilterTab.get(filterOpt).getText().contains("Pending")) {

					CommonUtil.clickEleJsExec(TestBase.getDriver(),
							cACaseAssignmentsCommonLocators.checkBox_FilterTab.get(filterOpt));
					
					CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.button_Apply);
					TestBase.test.log(LogStatus.INFO, "Pending cases are filtered");
					Log.info("Pending cases are filtered");

					CommonUtil.sleep(2000);

					CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.filterTab);

					CommonUtil.sleep(2000);

					break Innerloop;

				}

			} // innerloop ends here

			CommonUtil.sleep(3000);

			if (cACaseAssignmentsCommonLocators.all_CheckBox.size() > 1) {

				Innermostloop:
				// for(int record = cACaseAssignmentsCommonLocators.all_CheckBox.size()-1;
				// record >=0 ;record-- ) {
				for (int record = 0; record <= cACaseAssignmentsCommonLocators.all_CheckBox.size(); record++) {
					if (cACaseAssignmentsCommonLocators.raCode.isEmpty()) {
						continue Outerloop;
					} else {

						CommonUtil.clickEleJsExec(TestBase.getDriver(),
								cACaseAssignmentsCommonLocators.all_CheckBox.get(0));

						selectionCount = selectionCount + 1;

						currentVal = cACaseAssignmentsCommonLocators.row_ClientName.get(record).getText();
						clientName.add(currentVal);

						currentVal1 = cACaseAssignmentsCommonLocators.row_ApptDateTime.get(record).getText();
						AppointmentType.add(currentVal1);

						Date ApptDate = new Date();
						try {
							ApptDate = new SimpleDateFormat("MM/dd/yyyy h:mm a").parse(AppointmentType.get(record));

						} catch (ParseException e) {
							TestBase.test.log(LogStatus.INFO, "Appointment Date and Time is empty");
							Log.info("Empty AppointmentDateTime - " + e.getMessage());
							
							Assert.assertTrue(false, "Appointment Date is not available");
						}

						SimpleDateFormat apptDateTime = new SimpleDateFormat("MMM dd, h:mm a");
						apptDateTime_Base.add(apptDateTime.format(ApptDate));

						if (selectionCount == 2) {
							break Innermostloop;
						} else {
							continue Innermostloop;
						}

					}

				} // Innermostloop ends here

				break Outerloop;

			}

			else {
				continue Outerloop;
			}

		} // Outerloop ends here

	}

	public void clickTimelineToReassign(String CMS_User) {
		
		CommonUtil.sleep(2000);

		CommonUtil.scrollIntoView(TestBase.getDriver(), cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(0));

		CommonUtil.sleep(2000);

		for (int cmsUser = 0; cmsUser < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); cmsUser++) {

			if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(cmsUser).getText().contains(CMS_User)) {

				CommonUtil.scrollIntoView(TestBase.getDriver(), cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(cmsUser));
				
				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(cmsUser));

				CommonUtil.sleep(2000);
				
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cACaseAssignmentsCommonLocators.case_FromTimeline);
				TestBase.test.log(LogStatus.INFO, "Case from timeline is selected");
				Log.info("Case from timeline is selected");
				
				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cACaseAssignmentsCommonLocators.action_Headers.get(0));
				
				break;
			}
				
			}
		}



	public void validate_Timeline(String CMS_User) {
		
		CommonUtil.sleep(2000);

		CommonUtil.scrollIntoView(TestBase.getDriver(), cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(0));

		CommonUtil.sleep(2000);

		for (int cmsUser = 0; cmsUser < cACaseAssignmentsCommonLocators.caseLoad_CMS_User.size(); cmsUser++) {

			if (cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(cmsUser).getText().contains(CMS_User)) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cACaseAssignmentsCommonLocators.caseLoad_CMS_User.get(cmsUser));

				CommonUtil.sleep(2000);

				AppointmentPerDay = Integer
						.valueOf(cACaseAssignmentsCommonLocators.appointmentPerDay.get(cmsUser).getText());
				TestBase.test.log(LogStatus.INFO, "Appointment Per Day is " + AppointmentPerDay);
				Log.info("Appointment Per Day is " + AppointmentPerDay);

				for (int appt = 0; appt < AppointmentPerDay; appt++) {

					if (cACaseAssignmentsCommonLocators.timeline_Cases.get(appt).isDisplayed()) {

						TimelineCount = TimelineCount + 1;

						apptDateTime_Timeline.add(cACaseAssignmentsCommonLocators.timeline_Cases.get(appt).getText());

					}

				}

				TestBase.test.log(LogStatus.INFO, "No of timelines displayed is " + TimelineCount);
				Log.info("No of timelines displayed is " + TimelineCount);

				Assert.assertTrue(AppointmentPerDay == TimelineCount);
				TestBase.test.log(LogStatus.INFO, "No of appointments and timeline matches");
				Log.info("No of appointments and timeline matches");

				for (int Action = apptDateTime_Base.size() - 1; Action >= 0; Action--) {

					if (AppointmentPerDay == 2) {

						if (apptDateTime_Timeline.get(Action).contains(apptDateTime_Base.get(Action))) {
							Assert.assertTrue(
									apptDateTime_Timeline.get(Action).contains(apptDateTime_Base.get(Action)));
							TestBase.test.log(LogStatus.INFO,
									"Appointment Date & Time is as expected in the timeline for client "
											+ clientName.get(Action));
							Log.info("Appointment Date & Time is as expected in the timeline for client "
									+ clientName.get(Action));
						}
					}
				}
				break;
			}

		}

	}

}
