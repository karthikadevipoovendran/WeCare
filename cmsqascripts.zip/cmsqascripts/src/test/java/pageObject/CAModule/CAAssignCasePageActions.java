package pageObject.CAModule;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CAModule.CAAssignCasePageLocators;
import pageObject.CICOModule.CICOCheckInCheckOutCommonActions;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CAAssignCasePageActions {

	public static CAAssignCasePageLocators cAAssignCasePageLocators = null;
	public static String AC_nameToValidate = null;
	public static String AC_caseNumberToValidate = null;
	public static String AC_appointmentType = null;
	public static String AC_CheckInDate = null;
	public static String AC_CMSUser = null;

	public static String AC_caseWorkerAssigned = null;
	public static String AC_caseWorkerToReassign = null;
	public static String AC_caseWorkerReAssigned = null;
	public static String AC_caseWorkerDeAssigned = null;

	public static String AC_Status = null;
	public static String AC_StatusBeforeAssign = null;
	public static String AC_StatusAfterAssign = null;

	public static String AC_CMSUserBeforeAssign = null;
	public static String AC_CMSUserAfterAssign = null;

	public static int AC_currentCaseLoad = 0;
	public static int AC_futureCaseLoad = 0;
	public static int AC_currentCaseLoadForNewCMSUser = 0;
	public static int AC_futureCaseLoadForNewCMSUser = 0;
	public static int AC_count = 0;

	CACaseAssignmentsCommonActions CA_Common = new CACaseAssignmentsCommonActions();
	CICOCheckInCheckOutCommonActions CICO_Common = new CICOCheckInCheckOutCommonActions();

	public CAAssignCasePageActions() {

		CAAssignCasePageActions.cAAssignCasePageLocators = new CAAssignCasePageLocators();
		PageFactory.initElements(TestBase.getDriver(), cAAssignCasePageLocators);

	}

	public void getUserDetails() {

		AC_nameToValidate = CACaseAssignmentsCommonActions.common_ClientName;
		AC_caseNumberToValidate = CACaseAssignmentsCommonActions.common_CaseNumber;
		AC_appointmentType = CACaseAssignmentsCommonActions.common_AppointmentType;
		AC_CheckInDate = CACaseAssignmentsCommonActions.common_CheckInDate;
		AC_CMSUser = CACaseAssignmentsCommonActions.common_CMSUser;

	}

	public void getUserDetailsfromCICO() {
		AC_nameToValidate = CICOCheckInCheckOutCommonActions.common_ClientName;
		AC_caseNumberToValidate = CICOCheckInCheckOutCommonActions.common_CaseNumber;
		AC_appointmentType = CICOCheckInCheckOutCommonActions.common_AppointmentType;
		AC_CheckInDate = CICOCheckInCheckOutCommonActions.common_CheckInDate;
		AC_CMSUser = CICOCheckInCheckOutCommonActions.common_CMSUser;
	}

	public void assignToparticularQHP(String CMS_User) {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAAssignCasePageLocators.assignButton);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.assignButton);
		
		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.header_caseWorkerName);

		//System.out.println("CMS User is " +CMS_User);
		
		for (int CMS_UserName = 0; CMS_UserName < cAAssignCasePageLocators.caseWorkerNameToAssign
				.size(); CMS_UserName++) {

			if (cAAssignCasePageLocators.caseWorkerNameToAssign.get(CMS_UserName).getText().contains(CMS_User)) {
				AC_caseWorkerAssigned = cAAssignCasePageLocators.caseWorkerNameToAssign.get(CMS_UserName).getText();

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cAAssignCasePageLocators.checkbox_caseWorkerAssign.get(CMS_UserName));
				
				if(CMS_UserName<=2) {
					
					AC_caseWorkerToReassign = cAAssignCasePageLocators.caseWorkerNameToAssign.get(CMS_UserName + 1).getText();
					
				}else {
					AC_caseWorkerToReassign = cAAssignCasePageLocators.caseWorkerNameToAssign.get(CMS_UserName - 1).getText();
				}

				break;
			}

		}

		CommonUtil.scrollIntoView(TestBase.getDriver(), cAAssignCasePageLocators.boxPrimaryCaseManager);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.boxPrimaryCaseManager);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.boxPrimaryCaseManager);

		Select primaryCaseManagerValue = new Select(cAAssignCasePageLocators.boxPrimaryCaseManager);
		List<WebElement> allOptions_CaseManager = primaryCaseManagerValue.getOptions();

		for (int caseManager = 0; caseManager < allOptions_CaseManager.size(); caseManager++) {
			if (allOptions_CaseManager.get(caseManager).getText().contains(CMS_User)) {

				CommonUtil.clickEleJsExec(TestBase.getDriver(), allOptions_CaseManager.get(caseManager));

			}
		}

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.assignPopUp_AssignButton);
		TestBase.test.log(LogStatus.INFO, "Case is assigned successfully to " + AC_caseWorkerAssigned);
		Log.info("Case is assigned successfully to " + AC_caseWorkerAssigned);

	}

	public void assignToAnyQHP() {

		CommonUtil.sleep(3000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAAssignCasePageLocators.assignButton);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.assignButton);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.header_caseWorkerName);

		for (WebElement caseWorkerNameToAssign : cAAssignCasePageLocators.caseWorkerNameToAssign) {

			AC_caseWorkerAssigned = caseWorkerNameToAssign.getText();
			break;
		}

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.checkbox_caseWorkerAssign.get(0));

		CommonUtil.scrollIntoView(TestBase.getDriver(), cAAssignCasePageLocators.boxPrimaryCaseManager);
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.boxPrimaryCaseManager);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.boxPrimaryCaseManager);

		Select primaryCaseManagerValue = new Select(cAAssignCasePageLocators.boxPrimaryCaseManager);
		primaryCaseManagerValue.selectByIndex(1);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.assignPopUp_AssignButton);
		TestBase.test.log(LogStatus.INFO, "Case is assigned successfully to " + AC_caseWorkerAssigned);
		Log.info("Case is assigned successfully to " + AC_caseWorkerAssigned);

	}

	public void validate_AssignModal() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAAssignCasePageLocators.assignButton);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.assignButton);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.header_caseWorkerName);

		Assert.assertFalse(cAAssignCasePageLocators.textbox_CurrentlyAssigned.isEnabled());
		TestBase.test.log(LogStatus.INFO, "Currently Assigned To text box is disabled as expected");
		Log.info("Currently Assigned To text box is disabled as expected");

		Assert.assertTrue(cAAssignCasePageLocators.textbox_AssignTo.getText().contains(""));
		TestBase.test.log(LogStatus.INFO, "Assign To text box is empty as expected");
		Log.info("Assign To text box is empty as expected");

		Assert.assertTrue(cAAssignCasePageLocators.text_CaseDetails.isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Selected Cases option is displayed as expected");
		Log.info("Selected Cases option is displayed as expected");

		Assert.assertTrue(cAAssignCasePageLocators.value_CaseNumber.getText().contains(AC_caseNumberToValidate));
		TestBase.test.log(LogStatus.INFO, "Case Number is displayed under selected cases as expected");
		Log.info("Case Number is displayed under selected cases as expected");

		Assert.assertTrue(cAAssignCasePageLocators.value_ClientName.getText().contains(AC_nameToValidate));
		TestBase.test.log(LogStatus.INFO, "Client Name is displayed under selected cases as expected");
		Log.info("Client Name is displayed under selected cases as expected");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.checkbox_caseWorkerAssign.get(0));
		TestBase.test.log(LogStatus.INFO, "Checkbox for the case worker is selected as expected");
		Log.info("Checkbox for the case worker is selected as expected");

		Assert.assertTrue(cAAssignCasePageLocators.assignModal_CaseWorkerName.get(0).isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Case Worker name is displayed as expected");
		Log.info("Case Worker name is displayed as expected");

		Assert.assertTrue(cAAssignCasePageLocators.assignModal_CaseLoad.get(0).isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Case Load is displayed as expected");
		Log.info("Case Load is displayed as expected");

		Assert.assertTrue(cAAssignCasePageLocators.assignModal_ApptPerDay.get(0).isDisplayed());
		TestBase.test.log(LogStatus.INFO, "Today's appointments is displayed as expected");
		Log.info("Today's appointments is displayed as expected");

	}

	public void cancel_AssignModal() {

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.header_caseWorkerName);

		CommonUtil.scrollIntoView(TestBase.getDriver(), cAAssignCasePageLocators.assignPopUp_CancelButton);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.assignPopUp_CancelButton);
		TestBase.test.log(LogStatus.INFO, "Cancel button in Assign Modal is clicked successfully");
		Log.info("Cancel button in Assign Modal is clicked successfully");

		CommonUtil.sleep(1000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAAssignCasePageLocators.leftChevron);
		TestBase.test.log(LogStatus.INFO, "User is in Case Assignments page");
		Log.info("User is in Case Assignments page");

	}
	
	public void clickAssign() {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAAssignCasePageLocators.button_Assign);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.button_Assign);
	}
	
	public void assign(String CMS_User) {
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.header_caseWorkerName);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.textbox_AssignTo);
		
		CommonUtil.inputKeysToEle(cAAssignCasePageLocators.textbox_AssignTo, CMS_User);
		
		CommonUtil.sleep(1000);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.checkbox_CaseWorker);

		CommonUtil.scrollIntoView(TestBase.getDriver(), cAAssignCasePageLocators.boxPrimaryCaseManager);
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.driver, cAAssignCasePageLocators.boxPrimaryCaseManager);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.boxPrimaryCaseManager);

		Select primaryCaseManagerValue = new Select(cAAssignCasePageLocators.boxPrimaryCaseManager);
		primaryCaseManagerValue.selectByIndex(1);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAAssignCasePageLocators.button_second_Assign);
		TestBase.test.log(LogStatus.INFO, "Case is assigned successfully to " + CMS_User);
		Log.info("Case is assigned successfully to " + CMS_User);
		
	}

}
