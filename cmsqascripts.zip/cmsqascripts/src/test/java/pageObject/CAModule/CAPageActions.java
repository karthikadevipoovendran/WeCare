package pageObject.CAModule;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.formula.functions.LogicalFunction;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CAModule.CAPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;
import testUtil.Utility;

public class CAPageActions {
	
	CAPageLocators cAssignmentPageLocators = null;
	
	public CAPageActions() {
		this.cAssignmentPageLocators = new CAPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cAssignmentPageLocators);
	}
	
	public void increasePageSize() {
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.dropDown);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.dropDownOpt.get(cAssignmentPageLocators.dropDownOpt.size()-1));
		TestBase.test.log(LogStatus.INFO, "Page size is increased");
		Log.info("Page size is increased");
	}
	
	public void clickAssignActionOption() {
		String actionButtonText = "Assign";
		boolean bool = false;

		for (int row = 1; row < cAssignmentPageLocators.caAptCol.size(); row++) {
			String assignVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caAssignToCol.get(row));

			if (!assignVal.equals("")) {
				CommonUtil.clickEle(cAssignmentPageLocators.actBtn.get(row - 1)); // Action btn doesn't have any Header

				for (int actVal = 0; actVal < cAssignmentPageLocators.actOpt.size(); actVal++) {
					String actOptVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.actOptTxt.get(actVal));

					if (actOptVal.contains(actionButtonText)) {
						CommonUtil.clickEle(cAssignmentPageLocators.actOpt.get(actVal));
						bool = true;
						break;
					}
				}
			} else {
				if (row == cAssignmentPageLocators.caAptCol.size() - 1) {
					TestBase.test.log(LogStatus.INFO, "No '" + actionButtonText + "' option available");
					Log.info("No '" + actionButtonText + "' option available");
				}
				continue;
			}

			if (bool == true) {
				break;
			}
		}
	}

	public void clickReAssignActionOption() {
		String actionButtonText = "ReAssign";
		boolean bool = false;

		for (int row = 1; row < cAssignmentPageLocators.caAptCol.size(); row++) {
			String assignVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caAssignToCol.get(row));

			if (assignVal.equals("")) {
				CommonUtil.clickEle(cAssignmentPageLocators.actBtn.get(row - 1)); // Action Btn doesn't have any Header

				for (int actVal = 0; actVal < cAssignmentPageLocators.actOpt.size(); actVal++) {
					String actOptVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.actOptTxt.get(actVal));

					if (actOptVal.contains(actionButtonText)) {
						CommonUtil.clickEle(cAssignmentPageLocators.actOpt.get(actVal));
						bool = true;
						break;
					}
				}
			} else {
				if (row == cAssignmentPageLocators.caAptCol.size() - 1) {
					TestBase.test.log(LogStatus.INFO, "No '" + actionButtonText + "' option available");
					Log.info("No '" + actionButtonText + "' option available");
				}
				continue;
			}

			if (bool == true) {
				break;
			}
		}
	}

	public void clickDeAssignActionOption() {
		String actionButtonText = "DeAssign";
		boolean bool = false;

		for (int row = 1; row < cAssignmentPageLocators.caAptCol.size(); row++) {
			String assignVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caAssignToCol.get(row));

			if (assignVal.equals("")) {
				CommonUtil.clickEle(cAssignmentPageLocators.actBtn.get(row - 1)); // Action Btn doesn't have any Header

				for (int actVal = 0; actVal < cAssignmentPageLocators.actOpt.size(); actVal++) {
					String actOptVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.actOptTxt.get(actVal));

					if (actOptVal.contains(actionButtonText)) {
						CommonUtil.clickEle(cAssignmentPageLocators.actOpt.get(actVal));
						bool = true;
						break;
					}
				}
			} else {
				if (row == cAssignmentPageLocators.caAptCol.size() - 1) {
					TestBase.test.log(LogStatus.INFO, "No '" + actionButtonText + "' option available");
					Log.info("No '" + actionButtonText + "' option available");
				}
				continue;
			}

			if (bool == true) {
				break;
			}
		}
	}

	public void verifyDateColAndPendingStatusCount(String configFileURL, String endPoint) {
		
		List<String> sideMenuList = new ArrayList<String>();
		sideMenuList.add("Clinical Assessment/Re-assessment");
		sideMenuList.add("Psychiatric Evaluation");
		
		
		CommonUtil.navigateTo(TestBase.getDriver(), Utility.propertiesFile(Utility.PropFilePath).getProperty(configFileURL) + endPoint);

		String statVal = "Pending";
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.dateGrid);//clinicalorReassessment
			
		for(int count = 0; count < cAssignmentPageLocators.sideMenuPendCnt.size(); count++) {
			String val = CommonUtil.getTextOfEle(cAssignmentPageLocators.sideMenuPendCnt.get(count));
			String txtVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.sideMenuTxt.get(count));
					
			if(!val.equalsIgnoreCase("0") && sideMenuList.contains(txtVal)) {
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.sideMenu.get(count));
				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.leftChevron);

				this.increasePageSize();
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.allCasesChkBox);
				CommonUtil.sleep(2000);// use dynamic wait
				
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilter);
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilterOpt.get(2));
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilterOpt.get(3));
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilter);
				
				CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.statFilter);
				CommonUtil.sleep(1000);

				for(int stat = 0; stat < cAssignmentPageLocators.statListChkBox.size(); stat++) {
					String chkVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.statChkBoxTxt.get(stat));

					if(!statVal.equalsIgnoreCase(chkVal)) {
						String cls = cAssignmentPageLocators.statListChkBox.get(stat).getAttribute("class");

						if(cls.contains("ag-icon-checkbox-checked")) {
							CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.statListChkBox.get(stat));
							CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.filterApplyBtn);
						}
					}
				}
				
				CommonUtil.sleep(2000);
				String recordCount = CommonUtil.getTextOfEle(cAssignmentPageLocators.recordCount);

				if(!(Integer.parseInt(val) == Integer.parseInt(recordCount))) {
					Assert.assertTrue(Integer.parseInt(val) == Integer.parseInt(recordCount), "Pending status count doesn't match");
				}
				break;
			}
			else {
				continue;
			}
		}
		TestBase.test.log(LogStatus.INFO, "Pending status count is verified");
		Log.info("Pending status count is verified");

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.selectAllChkBox);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.allCasesChkBox);
		TestBase.test.log(LogStatus.INFO, "All Cases checkbox is selected");
		Log.info("All Cases checkbox is selected");		
	}

	public void caLogScreenValidation() {
		int statIndex = 0;
		
		List<String> status = new ArrayList<String>();
		status.add("Pending");
		status.add("Assigned");
		status.add("In Progress");
		status.add("Complete");
		status.add("FTC");
		
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.dateGrid);// clinicalorReassessment
		String currVal = null;
		int totalErr = cAssignmentPageLocators.raRedCode.size() + cAssignmentPageLocators.raOrangeCode.size();
		List<String> list = new ArrayList<String>();

		if (cAssignmentPageLocators.raRedCode.size() > 0) {

			for (int red = 0; red < cAssignmentPageLocators.raRedCode.size(); red++) {
				String val = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(red+1));
				
				if(status.contains(val) && red > 0) {
					Assert.assertTrue(statIndex < status.indexOf(val), "Status index is smaller than first status index");
				}

				if (red == 0) {
					currVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(red+1));
					list.add(currVal);
					statIndex = status.indexOf(val);
				}
				if (!currVal.equalsIgnoreCase(val)) {
					Assert.assertFalse(list.contains(val), "List contains the current val: "
							+ CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(red+1)));
					currVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(red+1));
					list.add(currVal);
				}
				
				// Red code should be more than one and red should be one less than raRedCode size
				if(cAssignmentPageLocators.raRedCode.size() > 1 && red < cAssignmentPageLocators.raRedCode.size() - 1) {
					
					// Status value mathces for current and next row
					if(CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(red)).equals(CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(red + 1)))) {
						Date dOne = null;
						Date dTwo = null;
						String txtOne = null;
						String txtTwo = null;
						
						List<WebElement> listOfDate = cAssignmentPageLocators.chkInDateCol;
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
						
						txtOne = CommonUtil.getTextOfEle(listOfDate.get(red));
						txtTwo = CommonUtil.getTextOfEle(listOfDate.get(red + 1));
						try {
							dOne = sdf.parse(txtOne);
							dTwo = sdf.parse(txtTwo);
						} 
						catch (ParseException e) {
							Log.info("Empty CheckIn - " + e.getMessage());
							Assert.assertTrue(false, "No CheckIn date is available");
						}

						if(dOne.compareTo(dTwo) == 0 || dOne.compareTo(dTwo) == -1) {
							continue;
						}
						else {
							Assert.assertTrue(false, "CheckIn dates are not in chronological order");
							break;
						}
					}
				}
			}
			list.clear();
		}
		if (cAssignmentPageLocators.raOrangeCode.size() > 0) {
			currVal = null;

			for (int orange = cAssignmentPageLocators.raRedCode.size(); orange < totalErr; orange++) {
				String val = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(orange));

				if (orange == cAssignmentPageLocators.raRedCode.size()) {
					currVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(orange));
					list.add(currVal);
				}
				if (!currVal.equalsIgnoreCase(val)) {
					Assert.assertFalse(list.contains(val), "list contains the current val: "
							+ CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(orange)));
					currVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(orange));
					list.add(currVal);
				}
				
				// Orange code should be more than one and orange should be one less than raRedCode size
				if(cAssignmentPageLocators.raOrangeCode.size() > 1 && orange < totalErr - 1) {
					
					// Status value mathces for current and next row
					if(CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(orange)).equals(CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(orange + 1)))) {
						Date dOne = null;
						Date dTwo = null;
						String txtOne = null;
						String txtTwo = null;
						
						List<WebElement> listOfDate = cAssignmentPageLocators.chkInDateCol;
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
						
						txtOne = CommonUtil.getTextOfEle(listOfDate.get(orange));
						txtTwo = CommonUtil.getTextOfEle(listOfDate.get(orange + 1));
						try {
							dOne = sdf.parse(txtOne);
							dTwo = sdf.parse(txtTwo);
						} 
						catch (ParseException e) {
							e.printStackTrace();
							Assert.assertTrue(false, "No CheckIn date is available");
						}

						if(dOne.compareTo(dTwo) == 0 || dOne.compareTo(dTwo) == -1) {
							continue;
						}
						else {
							Assert.assertTrue(false, "CheckIn dates are not in chronological order");
							break;
						}
					}
				}
			}
			list.clear();
		}
		if (totalErr < cAssignmentPageLocators.caStatusCol.size()) {
			currVal = null;
			
			for (int row = totalErr; row < cAssignmentPageLocators.caStatusCol.size()-1; row++) {
				String val = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(row));

				if (row == totalErr) {
					currVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(row));
				}
				if (!currVal.equalsIgnoreCase(val)) {
					Assert.assertFalse(list.contains(val), "list contains the current val: "
							+ CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(row)));
					currVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(row));
					list.add(currVal);
				}
				
				// Red code should be more than one and red should be one less than raRedCode size
				if(cAssignmentPageLocators.caStatusCol.size() > 1 && row < cAssignmentPageLocators.caStatusCol.size() - 1) {
					
					// Status value mathces for current and next row
					if(CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(row)).equals(CommonUtil.getTextOfEle(cAssignmentPageLocators.caStatusCol.get(row + 1)))) {
						Date dOne = null;
						Date dTwo = null;
						String txtOne = null; 
						String txtTwo = null;
						
						List<WebElement> listOfDate = cAssignmentPageLocators.chkInDateCol;
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
						
						txtOne = CommonUtil.getTextOfEle(listOfDate.get(row));
						txtTwo = CommonUtil.getTextOfEle(listOfDate.get(row + 1));
						try {
							dOne = sdf.parse(txtOne);
							dTwo = sdf.parse(txtTwo);
						} 
						catch (ParseException e) {
							e.printStackTrace();
							Assert.assertTrue(false, "No CheckIn date is available");
						}

						if(dOne.compareTo(dTwo) == 0 || dOne.compareTo(dTwo) == -1) {
							continue;
						}
						else {
							Assert.assertTrue(false, "CheckIn dates are not in chronological order");
							break;
						}
					}
				}
			}
			list.clear();
		}
		TestBase.test.log(LogStatus.INFO, "CheckIn date order is verified");
		Log.info("CheckIn date order is verified");
	}

	public void verifyInProgressStatusCount() {
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.dateGrid);// Clinical AssessmentorReassessment

		String progVal= "In Progress";
		
		this.increasePageSize();

		String[] val = CommonUtil.getTextOfEle(cAssignmentPageLocators.selectedDate.get(1)).split(" ");
		String appVal = val[0];
		
		CommonUtil.sleep(2000);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilter);
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilterOpt.get(2));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilterOpt.get(3));
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.colFilter);
		CommonUtil.sleep(2000);
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.statFilter);
		CommonUtil.sleep(2000);

		for (int stat = 0; stat < cAssignmentPageLocators.statListChkBox.size(); stat++) {
			String chkVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.statChkBoxTxt.get(stat));

			if (!progVal.equalsIgnoreCase(chkVal)) {
				String cls = cAssignmentPageLocators.statListChkBox.get(stat).getAttribute("class");

				if (cls.contains("ag-icon-checkbox-checked")) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.statListChkBox.get(stat));
					CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.filterApplyBtn);
					
				}
			}
		}
		
		

		CommonUtil.sleep(2000);
		String recordCount = CommonUtil.getTextOfEle(cAssignmentPageLocators.recordCount);
		
		Assert.assertTrue(!(Integer.parseInt(appVal) == Integer.parseInt(recordCount)), "Assigned and In Progress count don't match row count");
			
		TestBase.test.log(LogStatus.INFO, "Assigned and In Progress count is matched");
		Log.info("Assigned and In Progress count is matched");
		
//		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.selectAllChkBox);
	}

	public void verifyCurrentDateSelected() {
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.dateGrid); // clinicalorReassessment
		String dateVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.selectedDate.get(0));
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("EEE, MMM dd");
		String sysDate = sdf.format(currDate).toUpperCase();

		if (!sysDate.equals(dateVal)) {
			Assert.assertTrue(false, "Sysdate doesn't match selected date");
		}
		TestBase.test.log(LogStatus.INFO, "Sysdate matches selected date");
		Log.info("Sysdate matches selected date");
	}

	public void verifyAppOrCheckInDate() {
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.dateGrid);// clinicalorReassessment
		// Getting Appointments Type
		String appType = CommonUtil.getTextOfEle(cAssignmentPageLocators.appointmentType.get(1));

		if (appType.contains("Clinical") || appType.contains("Psychiatric")) {
			String chkInVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.chkInDateCol.get(1));
			String[] dateVal = chkInVal.split(" ");
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

			Assert.assertEquals(sdf.format(date), dateVal[0], "Check-In date should match selected date");
			TestBase.test.log(LogStatus.INFO, "CheckIn date matches with selected date");
			Log.info("CheckIn date matches with selected date");

			TestBase.test.log(LogStatus.INFO, appType + " Type");
			Log.info(appType + " Type");
		} 
		else if (appType.contains("Wellness") || appType.contains("SSI") || appType.contains("VRS")
				|| appType.contains("Return")) {
			String apptVal = CommonUtil.getTextOfEle(cAssignmentPageLocators.caAptCol.get(1));
			String[] dateVal = apptVal.split(" ");
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

			Assert.assertEquals(sdf.format(date), dateVal[0], "Appointment date should match selected date");
			TestBase.test.log(LogStatus.INFO, "Appointment date matches with selected date");
			Log.info("Appointment date matches with selected date");

			TestBase.test.log(LogStatus.INFO, appType + " Type");
			Log.info(appType + " Type");
		} 
		else {
			Log.info(appType + " Type is not available in the conditions above");
		}

	}

	public void verifyAllCasesOption() {
		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cAssignmentPageLocators.dateGrid); // clinicalorReassessment
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.allCasesChkBox);
		TestBase.test.log(LogStatus.INFO, "All Cases checkbox is selected");
		Log.info("All Cases checkbox is selected");

		try {
			String val = cAssignmentPageLocators.sideMenuBar.get(0).getAttribute("class");
			Assert.assertTrue(val.contains("panelWidthZero"), "Side menu bar should be collapsed");
			TestBase.test.log(LogStatus.INFO, "Side menu bar is collapsed");
			Log.info("Side menu bar is collapsed");
			
			Assert.assertTrue(!cAssignmentPageLocators.selectedDate.get(0).isDisplayed(), "Date row should not be displayed");
			TestBase.test.log(LogStatus.INFO, "Date row is not displayed");
			Log.info("Date row is not displayed");

			Assert.assertTrue(!cAssignmentPageLocators.scheBorder.isDisplayed(), "Scheduler Border should not be displayed");
			TestBase.test.log(LogStatus.INFO, "Scheduler Border is not displayed");
			Log.info("Scheduler Border is not displayed");

		} catch (IndexOutOfBoundsException e) {
			Log.info("Selected Date / Scheduler Border is not displayed: " + e.getMessage());
		}
		
		CommonUtil.clickEleJsExec(TestBase.getDriver(), cAssignmentPageLocators.allCasesChkBox);
		TestBase.test.log(LogStatus.INFO, "All Cases checkbox is selected");
		Log.info("All Cases checkbox is selected");
	}
		

}
