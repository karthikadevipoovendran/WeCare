package pageObject.CAModule;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.CAModule.CAAssignCasePageLocators;
import pageModel.CAModule.CADeassignCasesPageLocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;

public class CADeassignCasesPageActions {

	public static CADeassignCasesPageLocators cADeassignCasesPageLocators = null;

	public static String DA_caseWorkerAssigned = null;
	public static String DA_caseWorkerDeAssigned = null;

	CACaseAssignmentsCommonActions CA_Common_Case = new CACaseAssignmentsCommonActions();
	CAAssignCasePageLocators CA_Assign_Case = new CAAssignCasePageLocators();

	public CADeassignCasesPageActions() {

		CADeassignCasesPageActions.cADeassignCasesPageLocators = new CADeassignCasesPageLocators();
		PageFactory.initElements(TestBase.getDriver(), cADeassignCasesPageLocators);

	}

	public void getUserDetails() {

		DA_caseWorkerAssigned = CAAssignCasePageActions.AC_caseWorkerAssigned;
	}

	public void deassignAllCases() {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cADeassignCasesPageLocators.bycaseLoad_CMS_User);

		for (int CMS_Username = 0; CMS_Username < cADeassignCasesPageLocators.caseLoad_CMS_User
				.size(); CMS_Username++) {

			if (cADeassignCasesPageLocators.caseLoad_CMS_User.get(CMS_Username).getText()
					.contains(DA_caseWorkerAssigned)) {

				DA_caseWorkerDeAssigned = DA_caseWorkerAssigned;

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cADeassignCasesPageLocators.list_grid_actions.get(CMS_Username));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cADeassignCasesPageLocators.list_grid_actions.get(CMS_Username));
				TestBase.test.log(LogStatus.INFO, "Action button is clicked");
				Log.info("Action button is clicked");

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cADeassignCasesPageLocators.header_Actions);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.button_DeAssignAll);

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cADeassignCasesPageLocators.header_DeAssign);

				CommonUtil.sleep(1000);

				CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
						cADeassignCasesPageLocators.byDeassign_buttons);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.Deassign_buttons.get(0));
				TestBase.test.log(LogStatus.INFO, "All Cases have been successfully de-assigned");
				Log.info("All Cases have been successfully de-assigned");
				break;

			}

		}

	}
	
	public void deassignAllCases_ForParticularQHP(String CMS_User) {

		CommonUtil.sleep(2000);

		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), cADeassignCasesPageLocators.bycaseLoad_CMS_User);

		for (int CMS_Username = 0; CMS_Username < cADeassignCasesPageLocators.caseLoad_CMS_User
				.size(); CMS_Username++) {

			if (cADeassignCasesPageLocators.caseLoad_CMS_User.get(CMS_Username).getText()
					.contains(CMS_User)) {

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cADeassignCasesPageLocators.list_grid_actions.get(CMS_Username));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cADeassignCasesPageLocators.list_grid_actions.get(CMS_Username));
				TestBase.test.log(LogStatus.INFO, "Action button is clicked");
				Log.info("Action button is clicked");

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cADeassignCasesPageLocators.header_Actions);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.button_DeAssignAll);

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cADeassignCasesPageLocators.header_DeAssign);

				CommonUtil.sleep(1000);

				CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(),
						cADeassignCasesPageLocators.byDeassign_buttons);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.Deassign_buttons.get(0));
				TestBase.test.log(LogStatus.INFO, "All Cases have been successfully de-assigned");
				Log.info("All Cases have been successfully de-assigned");
				break;

			}

		}

	}

	public void validatePopUpAfterDeAssign() {

		CommonUtil.sleep(2000);

		for (int CMS_UserNameText = 0; CMS_UserNameText < cADeassignCasesPageLocators.caseLoad_CMS_User
				.size(); CMS_UserNameText++) {

			if (cADeassignCasesPageLocators.caseLoad_CMS_User.get(CMS_UserNameText).getText()
					.contains(DA_caseWorkerAssigned)) {

				CommonUtil.scrollIntoView(TestBase.getDriver(),
						cADeassignCasesPageLocators.list_grid_actions.get(CMS_UserNameText));

				CommonUtil.clickEleJsExec(TestBase.getDriver(),
						cADeassignCasesPageLocators.list_grid_actions.get(CMS_UserNameText));
				TestBase.test.log(LogStatus.INFO, "Action button is clicked");
				Log.info("Action button is clicked");

				CommonUtil.sleep(2000);
				
				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cADeassignCasesPageLocators.header_Actions);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.button_DeAssignAll);

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
						cADeassignCasesPageLocators.header_DeAssign);

				CommonUtil.sleep(1000);

				Assert.assertTrue(cADeassignCasesPageLocators.text_NoCases_Deassign.isDisplayed());
				TestBase.test.log(LogStatus.INFO, "There are no cases to deassign text is displayed as expected");
				Log.info("There are no cases to deassign text is displayed as expected");

				CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cADeassignCasesPageLocators.button_OK);

				CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.button_OK);
				TestBase.test.log(LogStatus.INFO, "No more cases to de-assign");
				Log.info("No more cases to de-assign");
				break;

			}

		}

	}

	public void deassignSpecificCase() {

		DA_caseWorkerDeAssigned = DA_caseWorkerAssigned;

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cADeassignCasesPageLocators.deAssign);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.deAssign);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(),
				cADeassignCasesPageLocators.label_deassignCase);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.label_deassignCase);

		CommonUtil.sleep(1000);

		CommonUtil.waitDriverUntilElementIsVisible(TestBase.getDriver(), cADeassignCasesPageLocators.CA_all_buttons);

		CommonUtil.clickEleJsExec(TestBase.getDriver(), cADeassignCasesPageLocators.CA_all_buttons);
		TestBase.test.log(LogStatus.INFO, "Case is successfully de-assigned from " + DA_caseWorkerDeAssigned);
		Log.info("Case is successfully de-assigned from " + DA_caseWorkerDeAssigned);
	}

}
