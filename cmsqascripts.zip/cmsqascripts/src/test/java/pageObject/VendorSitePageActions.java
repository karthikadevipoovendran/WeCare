package pageObject;


import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageModel.VendorSiteLPageocators;
import pageTest.TestBase;
import testUtil.CommonUtil;
import testUtil.Log;


public class VendorSitePageActions {
	
	public VendorSiteLPageocators vendorSiteLocators = null;
	
	public VendorSitePageActions() {
		vendorSiteLocators = new VendorSiteLPageocators();
		PageFactory.initElements(TestBase.getDriver(), vendorSiteLocators);
	}

	
	public void clickVendorSiteBtn(String program, String provider, String site) {
		
		CommonUtil.waitDriverUntilNoOfElement(TestBase.getDriver(), vendorSiteLocators.byVendorSiteBtn);
		
		if(vendorSiteLocators.vendorSiteBtn.get(0).isDisplayed()) {
			Assert.assertTrue(vendorSiteLocators.vendorSiteBtn.get(0).isDisplayed(), "'Vendor Site' Screen is not available");
			TestBase.test.log(LogStatus.INFO, "User has landed on 'Vendor Site' Screen");
			Log.info("User has landed on 'Vendor Site' Screen");
			
			for(int progBtn=0; progBtn<vendorSiteLocators.progBtn.size(); progBtn++) {
				String programVal = CommonUtil.getTextOfEle(vendorSiteLocators.progBtn.get(progBtn));
		
				if(programVal.equalsIgnoreCase(program)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), vendorSiteLocators.progBtn.get(progBtn));
					TestBase.test.log(LogStatus.INFO, "User has chosen '"+programVal+"' program");
					Log.info("User has chosen '"+programVal+"' program");
					break;
				}
			}
			
			for(int provBtn=0; provBtn<vendorSiteLocators.provBtn.size(); provBtn++) {				
				String providerVal = CommonUtil.getTextOfEle(vendorSiteLocators.provBtn.get(provBtn));

				if(providerVal.equalsIgnoreCase(provider)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), vendorSiteLocators.provBtn.get(provBtn));
					TestBase.test.log(LogStatus.INFO, "User has chosen '"+providerVal+"' program");
					Log.info("User has chosen '"+providerVal+"' program");
					break;
				}
			}
						
			for(int siteBtn=0; siteBtn<vendorSiteLocators.siteBtn.size(); siteBtn++) {
				String siteVal = CommonUtil.getTextOfEle(vendorSiteLocators.siteBtn.get(siteBtn));
				
				if(siteVal.equalsIgnoreCase(site)) {
					CommonUtil.clickEleJsExec(TestBase.getDriver(), vendorSiteLocators.siteBtn.get(siteBtn));			
					TestBase.test.log(LogStatus.INFO, "User has chosen '"+siteVal+"' program");
					Log.info("User has chosen '"+siteVal+"' program");
					break;
				}
			}			
		}
		
		TestBase.cICOAppointmentLogPageActions = TestBase.cICOAppointmentLogPageActionsObject();
		TestBase.CICOCheckInCheckOutCommonActions = TestBase.cICOCheckInCheckOutCommonActionsObject();
		TestBase.CACaseAssignmentsCommonActions = TestBase.cACaseAssignmentsCommonActionsObject();

		/*Remove bottom two later*/
		
		TestBase.mAPageActions = TestBase.mAPageActionsObject();
		TestBase.MAPageCommonActions = TestBase.mAPageCommonActionsObject();
	}
	
}
