package testUtil;

import java.time.Duration;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import pageTest.TestBase;

public class CommonUtil {
	// ===================================
	// Keep all the common functionalities in this class as static
	// ===================================

	public static WebDriverWait wait = null;

	public static void inputKeysToEle(WebElement ele, String val) {
		ele.clear();
		ele.sendKeys(val);
	}

	public static void inputKeysWithEnterToEle(WebElement ele, String val) {
		ele.clear();
		ele.sendKeys(val + Keys.ENTER);
	}
	
	public static void clickEle(WebElement ele) {
		ele.click();
	}

	public static void clickEleJsExec(WebDriver driver, WebElement ele) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", ele);
	}

	public static void clickEleAction(WebDriver driver, WebElement ele) {
		Actions actions = new Actions(driver);
		actions.moveToElement(ele).click().build().perform();
	}

	public static void clickEleOffsetAction(WebDriver driver, int x, int y) {
		Actions actions = new Actions(driver);
		actions.moveByOffset(x, y).click().build().perform();
	}

	public static void submitEle(WebElement ele) {
		ele.submit();
	}

	public static Select selectEleFromDropDown(WebElement ele) {
		Select sel = new Select(ele);
		return sel;
	}

	public static String getTextOfEle(WebElement ele) {
		String val = ele.getText().trim();
		return val;
	}

	public static String getInnerHTMLOfEle(WebElement ele) {
		String val = ele.getAttribute("innerHTML").trim();
		return val;
	}

	public static String getJSHTMLOfEle(WebDriver driver, WebElement ele) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		String val = (String) jse.executeScript("return arguments[0].innerHTML", ele);
		return val;
	}

	public static String getJSTextOfEle(WebDriver driver, WebElement ele) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		String val = (String) jse.executeScript("return arguments[0].innerText", ele);
		return val;
	}

	public static String getAttributeOfEle(WebElement ele, String attrName) {
		String val = ele.getAttribute(attrName).trim();
		return val;
	}

	public static void sleep(long miliSec) {
		try {
			Thread.sleep(miliSec);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void waitDriverUntilElementIsVisible(WebDriver driver, WebElement element) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public static void waitDriverUntilElementIsClickable(WebDriver driver, WebElement element) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void waitDriverUntilNoOfElement(WebDriver driver, By locator) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(locator, 0));
	}

	public static void waitDriverUntilNoOfElement(WebDriver driver, By locator, int num) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(locator, num));
	}

	public static void waitDriverUntilAttrToBe(WebDriver driver, WebElement ele, String attrName, String attrValue) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.attributeToBe(ele, attrName, attrValue));
	}

	public static void waitDriverUntilElementIsInvisible(WebDriver driver, WebElement ele) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.invisibilityOf(ele));
	}

	public static void waitDriverUntilAttrValueOfElement(WebDriver driver, WebElement ele, String attrName,
			String attrVal) {
		wait = new WebDriverWait(driver, Utility.WAIT_TIME);
		wait.until(ExpectedConditions.attributeToBe(ele, attrName, attrVal));
	}

	public static WebElement waitDriverUsingFluent(WebDriver driver, By locator) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(Utility.WAIT_TIME))
				.pollingEvery(Duration.ofSeconds(Utility.POLL_TIME)).ignoring(NoSuchElementException.class);

		WebElement ele = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(locator);
			}
		});
		return ele;
	}

	public static void verifyPageHeader(String actualHeader, WebElement ele) {
		Assert.assertEquals(actualHeader, CommonUtil.getTextOfEle(ele),
				"'" + actualHeader + "' Title is not validated");
		TestBase.test.log(LogStatus.INFO, "Client has landed on '" + actualHeader + "' page");
		Log.info("Client has landed on '" + actualHeader + "' page");
	}

	public static void scrollIntoView(WebDriver driver, WebElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", ele);
	}

	public static void scrollToTheBottom(WebDriver driver, WebElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public static void navigateTo(WebDriver driver, String url) {
		
		if (!driver.getCurrentUrl().equals(url)) {
			driver.navigate().to(url);
			TestBase.test.log(LogStatus.INFO, "Navigated to " + url);
			Log.info("Navigated to " + url);
		} 
		else {
			Log.info("Current URL is equal to provided URL");
		}		
	}

	public static String getURL(WebDriver driver) {
		return driver.getCurrentUrl();
	}

	public static boolean isElementPresent(WebDriver driver, By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public boolean startsWith(String fullStr, String str) {
		boolean bool = false;
		int len = str.length();
		String startTxt = fullStr.substring(0, len);

		if (startTxt.equalsIgnoreCase(str)) {
			bool = true;
		} else {
			bool = false;
		}
		return bool;
	}

	public boolean endsWith(String fullStr, String str) {
		boolean bool = false;
		int len = str.length();
		String endTxt = fullStr.substring(fullStr.length() - len);

		if (endTxt.equalsIgnoreCase(str)) {
			bool = true;
		} else {
			bool = false;
		}
		return bool;
	}

}
