package testUtil;import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;public class LocatorGenerator {    //div[@class='button'], loginBtn, Ele
    //div[contains(@class,'input')], loginInput, List
    // Don't use space after comma in xpath method as we are splitting based on ", "
    
    public static void main(String ... args) throws IOException {
        LocatorGenerator lg = new LocatorGenerator();
        lg.locatorMethod();
    }
    
    public void locatorMethod() throws IOException {        File file = new File(System.getProperty("user.dir")+"/locator.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));        String st;
        while ((st = br.readLine()) != null) {
            String[] s = st.split(", ");
            
            if(!st.startsWith("/")) {
                System.out.println(st);
                continue;
            }
            if(s[2].equalsIgnoreCase("Ele")) {
                System.out.println("@FindBy(xpath=\"" + s[0].trim() + "\")");
                System.out.println("public WebElement " + s[1].trim() + ";");
            }else if(s[2].equalsIgnoreCase("List")) {
                System.out.println("@FindBy(xpath=\"" + s[0].trim() + "\")");
                System.out.println("public List<WebElement> " + s[1].trim() + ";");
            }
        }
    }
}
